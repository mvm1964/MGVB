#ifndef ARRAYSEARCH_H
#define ARRAYSEARCH_H


// Struct to hold spectrum data.
typedef struct Mod_Pep {
    int pep_id;
    double mass;
    char sequence[4096];
    char prot_id[4096];
    int missed;
    int decoy;
    int contam;
} mod_pep;

// Count lines
int count_lines(FILE*);

// Import mod_pep from file and put it into sorted array in memory
int make_mod_pep(FILE*, int n_ptm, int, int mods[][n_ptm], mod_pep**);

// Search array, return index of the smallest element matching criteria
int find_min_match(mod_pep*, int, int, double, double);

#endif
