/* 
 * Efficient sorted array search algorithm
 *
 * Author: Metodi V. Metodiev
 * Ravna, Bulgaria, 20.12.2023
 *
 * Given two sorted array, find the elments of array 2 that are within 
 * +/- tolerance of the elements of array 1.
 *
 * In this particular case I am using it to match LC-MS/MS spectra to 
 * peptide sequences. The elements of array 1 are the masses from the spectrum.
 * Array 2 holds the peptide fragment masses.
 *
 * Spectra will be sorted in order of precursor mass (array 1) and will be matched 
 * to an array of peptide masses (array 2). A version of th einterval_search function
 * will be used to return all precursors matching the search interval. 
 *
 * Should refactor to put xcorr in a separate file and be able to call it from here. 
 *
 * It os also worth considering using this instead of Sqlite. This will work like this:
 *
 * 1. Each thread will collect spectra from mms file into an array os structs sorted
 *    by precursor mass.
 * 2. A sorted mod_pep struct array will be kept in memory by each thread. These structs
 *    will have mass (by which they are sorted), pep_id, sequence, ptm array as fields.
 *    It will be perhaps easiest to have separate arrays instead of a struct.
 * 3. Search will go as for xcorr: start with the smallest mass in the mod_pep array
 *    and search until the first mass matching query is found, selelct until the last one
 *    matching is found and keep the index of the next mod_pep element to start with it 
 *    the search for the next spectrum in the sorted spec array.
 *    NB: to speadup the first search, I can implement a binary search step at the beginning. 
 *  
 *    27.12.2023: Will actually implement the second idea firts to relace Sqlite for precursor 
 *    searches.
 *
 *    29.12.2023: So far so good. It all worked at small scale but when tried on ceres, could 
 *    not allocate memory for the arrays. Now going back to "normalised" arrays implementation.
 *    Will keep in pep_mod only the pep_id and mass. Will put in a separate peptides array
 *    sequence, and prot_id, missed, decoy and contam. The trick is, peptides array is sorted
 *    by design and pep_id from mod_pep corresponds to the index of peptides. Should only remember
 *    that the index starts at 1, not 0!
 */

#include <math.h>
#include <stdio.h>
#include "arraySearch2023.h"
#include <stdlib.h>
#include <string.h>

// count lines
int count_lines(FILE* file) {
    char buf[65536];
    int counter = 0;
    for(;;) {
    
        size_t res = fread(buf, 1, 65536, file);
        if (ferror(file))
            return -1;

        int i;
        for(i = 0; i < res; i++)
            if (buf[i] == '\n')
                counter++;

        if (feof(file))
            break;
    }

    return counter;
}

/*
 *  Import mod_pep_array and mods from file and put them into arrays in memory
 *
 *  arguments:
 *  1. file pointer for file holding mod_pep data. This contains pep_id, mass and PTMs
 *  2. file pointer for file holding peptide data: sequence, prot_id, missed, decoy, contam
 *  3. number of columns for 2d mods array
 *  4. number of rows for the 2d mods array
 *  5. mods array
 *  6. address of mod_pep_array: will only hold pep_id and mass in element structures
 *  7. address of peptide array: will only hold missed, decoy, and contam flags
 *  8. address of array of strings to hold sequences
 *  9. address of array of strings to hold prot_id
 *
 *  Will put sequences and prot_id in separate arrays instead of the peptide array
 *  to avoid problems with memory allocation. They will be allocated in main like mods.
 */
int make_arrays(FILE *mod_pep_file, FILE *pep_file, int cols, int rows, int rows1, 
		int mods[rows][cols], mod_pep **mod_pep_array, pep_info **pep_array, 
		char **sequences, char **prot_id) {
    // read file, allocate array, and populate array
    char mod_pep_Str[8192];

    // allocate mod_pep and pep arrays
    *mod_pep_array = malloc(rows*sizeof(mod_pep));
    if (!(*mod_pep_array)) {
        printf("Cannot allocate memory for mod_pep_array!\n");
        exit(1);
    }

    *pep_array = malloc(rows1*sizeof(pep_info));
    if (!(*pep_array)) {
        printf("Cannot allocate memory for pep_array!\n");
        exit(1);
    }

    char *pch;
    
    // read the files and populate the arrays
    int ctr = 0;
    while (fgets(mod_pep_Str, sizeof(mod_pep_Str), mod_pep_file) != NULL) {
	
	// debug 
	//printf("%s\n", mod_pep_Str);

        pch = strtok(mod_pep_Str, "\t");
        (*mod_pep_array)[ctr].pep_id = atoi(pch);  	    
        pch = strtok(NULL, "\t");
	(*mod_pep_array)[ctr].mass = atof(pch);
	
	for (int j = 0; j < cols; j++) {

            // debug
            //printf("pch is %s\n", pch);

            pch = strtok (NULL, "\t");
            mods[ctr][j] = atoi(pch);
        }
	
	/*pch = strtok(NULL, "\t");
        strcpy((*mod_pep_array)[ctr].sequence, pch);
	pch = strtok(NULL, "\t");
        strcpy((*mod_pep_array)[ctr].prot_id, pch);
        pch = strtok(NULL, "\t");
	(*mod_pep_array)[ctr].missed = atoi(pch);
        pch = strtok(NULL, "\t");
	(*mod_pep_array)[ctr].decoy = atoi(pch);
        pch = strtok (NULL, "\t");
	(*mod_pep_array)[ctr].contam = atoi(pch);
        */
        // debug
	/*printf("%d, %lf, %s\n", (*mod_pep_array)[ctr].pep_id, 
			(*mod_pep_array)[ctr].mass, 
			(*mod_pep_array)[ctr].sequence);
        */
        
	//printf("ctr is %d\n", ctr);
        
        // debug
	//if (ctr == 2) return ctr;

        ctr++;	
    }
    ctr = 0;
    while (fgets(mod_pep_Str, sizeof(mod_pep_Str), pep_file) != NULL) {
        pch = strtok(mod_pep_Str, "\t");
        strcpy(sequences[ctr], pch);
	pch = strtok(NULL, "\t");
	strcpy(prot_id[ctr], "?");
	pch = strtok(NULL, "\t");
	(*pep_array)[ctr].missed = atoi(pch);
        pch = strtok(NULL, "\t");
        (*pep_array)[ctr].decoy = atoi(pch);
        pch = strtok (NULL, "\t");
        (*pep_array)[ctr].contam = atoi(pch);
        ctr++;
    }
    
    // debug: test arrays
    /*for (int i = 0; i < 5; i++) {
        printf("%s, %lf\n", mod_pep_array[i].sequence, mod_pep_array[i].mass);
    }*/

    return ctr;
}

// Search array, return index of the smallest element matching criteria
/*int find_min_match(mod_pep *arr, int start, int end, double tol, double target) {
    if (start >= end) return -1;
    int mid = start + (end - start + 1)/2;
    //printf("Mid is %d\n", mid);
    int ind = 0;
    int index = 0;
    if (arr[mid].mass > target + tol) return find_min_match(arr, 0, mid - 1, tol, target);
    else if  (arr[mid].mass < target - tol) return find_min_match(arr, mid + 1, end, tol, target);
    else {
        ind = mid;
	while (arr[ind].mass >= target - tol) {
            index = ind;
	    ind--;
        }
        return index;            
    }
}*/

// alternative non recursive search (modified from G4G) since the recursive one above is incorrect
int find_min_match(mod_pep *arr, int start, int end, double tol, double target) {
    
    int res = -1;
    double key_low = target - tol;
    double key_high = target + tol;

    while (start <= end) {
      
	int mid = start + (end - start + 1)/2;
        double midVal = arr[mid].mass;    
	
        if (midVal < key_low) {
            start = mid + 1;
	}
	else if (midVal > key_high) {
	    end = mid - 1;            
	}
	else {
	    res = mid;	
	    end = mid - 1;
	}
    }
    return res;
}

/*
 * Once we find the first element xcorr is called in a while loop
 */

// lets test with a separate test file
