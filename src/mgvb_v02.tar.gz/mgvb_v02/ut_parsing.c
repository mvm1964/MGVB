// Unit test for parsing spectra with variable q

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "pepMass.h"
#include "parse_spectrum.h"

int main(int argc, char **argv) {
    double masses[] = {123.1, 123.2, 130.2, 133.1, 135.3,
                     143.1, 143.2, 150.2, 153.1, 155.3,
                     163.1, 163.2, 170.2, 173.1, 185.3,
                     223.1, 223.2, 230.2, 233.1, 235.3,
                     243.1, 243.2, 250.2, 253.1, 255.3,
                     263.1, 263.2, 270.2, 273.1, 285.3,
	             323.1, 323.2, 330.2, 333.1, 335.3,
                     343.1, 343.2, 350.2, 353.1, 355.3,
                     363.1, 363.2, 370.2, 373.1, 385.3,		     
                     423.1, 423.2, 430.2, 433.1, 435.3,
                     443.1, 443.2, 450.2, 453.1, 455.3,
                     463.1, 463.2, 470.2, 473.1, 485.3,
                     523.1, 523.2, 530.2, 533.1, 535.3,
                     543.1, 543.2, 550.2, 553.1, 555.3,
                     563.1, 563.2, 570.2, 573.1, 585.3,
                     623.1, 623.2, 630.2, 633.1, 635.3,
                     643.1, 643.2, 650.2, 653.1, 655.3,
                     663.1, 663.2, 670.2, 673.1, 685.3
                     };
    double intensities[] = {10.0, 11.0, 5.2, 9.2, 22.3,
                          3.2, 12.3, 231.1, 1.3, 7.5,
	                  123.4, 1.3, 12.4, 22.1, 8.3, 
                          10.0, 11.0, 5.2, 9.2, 22.3,
                          3.2, 12.3, 231.1, 1.3, 7.5,
                          123.4, 1.3, 12.4, 22.1, 8.3,
			  10.0, 11.0, 5.2, 9.2, 22.3,
                          3.2, 12.3, 231.1, 1.3, 7.5,
                          123.4, 1.3, 12.4, 22.1, 8.3,
			  10.0, 11.0, 5.2, 9.2, 22.3,
                          3.2, 12.3, 231.1, 1.3, 7.5,
                          123.4, 1.3, 12.4, 22.1, 8.3,
			  10.0, 11.0, 5.2, 9.2, 22.3,
                          3.2, 12.3, 231.1, 1.3, 7.5,
                          123.4, 1.3, 12.4, 22.1, 8.3,
			  10.0, 11.0, 5.2, 9.2, 22.3,
                          3.2, 12.3, 231.1, 1.3, 7.5,
                          123.4, 1.3, 12.4, 22.1, 8.3,
                        };
    spectrum spec;
    spectrum empty = {0};

    int i[21];
    for (int j = 1; j <= 21; j++) i[j] = 0;
    int q1 = atoi(argv[1]);   
    double mass;
    double intensity;
    int interval = 0;

    // Innitialize empty.
    for (int j = 0; j < maxSize; j++){
        empty.fragMass[j] = 0;
        empty.fragInt[j] = 0;
    }
    spec = empty;

    // now use the arrays above to create spectra with various q
    for (int t = 0; t < 90; t++) {
        mass = masses[t];
	intensity = intensities[t];
        // Fill intervals here.
        if (mass > 2000) interval = 21;
        else interval = ceil(mass/100);
        intervalFill(mass, intensity, &spec, i, interval, q1);
        i[interval]++;
    }
    sort_masses(&spec);
    remove_0(&spec);
    // print spectrum
    printf("Spectrum has %d fragments\n", spec.actual_size);
    for (int t = 0; t < spec.actual_size; t++) {
        printf("%lf\t%lf\n", spec.fragMass[t], spec.fragInt[t]);
    }
    return 0;
}



