/*
  A short program that parses MS2 files 
  to matchMS (mms) format. Implements 100Th interval 
  limit of the allowed number of peaks.
  Usage: parseMS <ms2 file>
                            
  Metodi V. Metodiev, 2019, Colchester, UK 

  Update 06.08.2020: Need to change the algorithm to accept q from config file.
  Should do something about the reordering..

  Update 11.09.2022: will remove zeros from the frmz array to allow binary search 
  of masses

*/

#include <stdio.h>
#include <stdlib.h> // for the exit() function
#include <string.h>
#include <ctype.h> // for isdigit() function
#include <math.h>


#define bufSize 1024
#define q 10 
#define maxSize 210 // This will depend on q. For examle for q = 10 maxSze is 20xq - q = 190.

/*
  Update 05.08.2021: will refactor to optimize speed. Now it considers mass range of up to 6000. 
  This is wasteful as very few fragments are larger than 2000. Will change code to assume 21 
  intervals. Then, if a mass is > 2000, it goes to interval 21. Else it goes to the appropriate
  lower interval.


  Update 13.09.2022
  Need to remove zeros and reorder by m/z
*/

//Struct to hold spectrum data.
// changing now to delete zeroes 11.09.2022
typedef struct Spectrum {
    int scan; // For a unique scan number (relative for now).
    int scanNum; // This turns out ot be precursor scan.
    int charge;
    double retTime;
    double precMass;
    double fragMass[maxSize]; 
    double fragInt[maxSize];
    int actual_size; 
} spectrum;

// An empty spectrum.
spectrum empty = {0};

int intervalFill(double mass, double intensity, spectrum *spec, int *i, int interval) {
    double minInt = 0;
    int sorted = 0; // Need to change it somehow to avoid always sorting the array. Either make sorted global or return its value.
 
    if (i[interval] < q) {
        spec->fragMass[(interval - 1)*q + i[interval]] = mass;
        spec->fragInt [(interval - 1)*q + i[interval]] = intensity;
        //printf("%lf\n", spec->fragMass[(interval - 1)*q + i[interval]]);
        return 0;
    }
    else {
        
        int c = 0;
        int d = 0;
        double p = 0;
        double r = 0;

        // Sort the interval now if not sorted. Needs to be fixed.
        if (sorted == 0){
            for (c = (interval - 1)*q; c < interval*q; c++) {
                d = c;
                while (d > (interval - 1)*q && spec->fragInt[d-1] > spec->fragInt[d]) {
                    p = spec->fragMass[d];
                    r = spec->fragInt[d];
                    spec->fragMass[d] = spec->fragMass[d - 1];
                    spec->fragInt[d] = spec->fragInt[d - 1];
                    spec->fragMass[d - 1] = p;
                    spec->fragInt[d - 1] = r;
                    d--;
                }
            }
            sorted = 1;
            // Assign first element to minInt.
            minInt = spec->fragInt[(interval - 1)*q];
            // If new fragments have higher intensity replace first element with it.
            if (intensity > minInt) {
                spec->fragMass[(interval - 1)*q] = mass;
                spec->fragInt[(interval - 1)*q] = intensity;
                sorted = 0;
                return 0;
            }
        }
    } 
    return 0;      
} 

// final sort to make sure fragments are sorted in increasing mass order
void sort_masses(spectrum *spec) {
    int c = 0;
    int d = 0;
    double p = 0;
    double r = 0;
    for (c = 0; c < spec->actual_size; c++) {
        d = c;
	while (d > 0 && spec->fragMass[d-1] > spec->fragMass[d]) {
            p = spec->fragMass[d];
            r = spec->fragInt[d];
            spec->fragMass[d] = spec->fragMass[d - 1];
            spec->fragInt[d] = spec->fragInt[d - 1];
            spec->fragMass[d - 1] = p;
            spec->fragInt[d - 1] = r;
            d--;
       }



    }
}

int main(int argc, char **argv) {

    // Variable declarations.  
    spectrum spec;
    char str[bufSize];
    FILE *fptr;
    FILE *ofptr;

    // Update 04.08.2021: need to change to 60 because now files are high/high and mass range is 0 to 6000
    int i[21];
    for (int j = 1; j <= 21; j++) i[j] = 0;
    int count = 0;
    double mass;
    double intensity;    
    int interval = 0;
    
    // Innitialize empty.
    for (int j = 0; j < maxSize; j++){
        empty.fragMass[j] = 0;
        empty.fragInt[j] = 0;
    }
    spec = empty;
    // Open input and output files for reading/writing.
    if ((fptr = fopen(argv[1], "r")) == NULL) {       
        printf("Error opening input file!");
        exit(1);
    }

    char resFile[128] = {};
    strcat(resFile, argv[1]);
    strcat(resFile, ".mms");

    if ((ofptr = fopen(resFile, "wb")) == NULL) {
        printf("Error opening output file!");
        exit(1);
    }
    printf("Parsing spectra for %s. Please wait...\n", argv[1]); 

    // Read the input file line by line and parse it.
    while (fgets(str, sizeof(str), fptr) != NULL) {
        if (strstr(str, "I\tRetTime")) {
            sscanf(str, "I\tRetTime %lf", &spec.retTime);
        }
        else if (strstr(str, "I\tPrecursorScan")) {
            sscanf(str, "I\tPrecursorScan\t%d", &spec.scanNum);
        }
        else if (str[0] == 'Z') {
            sscanf(str, "Z\t%d\t%lf", &spec.charge, &spec.precMass); 
        }
        else if (isdigit(str[0])) {
            sscanf(str, "%lf %lf", &mass, &intensity); 
            
            // Fill intervals here.
            if (mass > 2000) interval = 21;
            else interval = ceil(mass/100);
            intervalFill(mass, intensity, &spec, i, interval);
            i[interval]++; 
	    // now remove zeroes
	    /*double tmp_mass[maxSize];
	    double tmp_int[maxSize];
	    for (int i = 0; i < maxSize; i++) {
	        tmp_mass[i] = spec.fragMass[i];
                tmp_int[i] = spec.fragInt[i];
	    }	    
            for (int i = 0; i < maxSize; i++) {
		spec.fragMass[i] = 0.0;
                spec.fragInt[i] = 0.0;		
	    }
            // now copy only non zero elements to spec.fragMass and spec.fragInt
	    int j = 0;
	    for (int i = 0; i < maxSize; i++) {
                if (tmp_mass[i] != 0) {
                    spec.fragMass[i] = tmp_mass[i];
		    spec.fragInt[i] = tmp_int[i];
		    j++;
	        }
            }
            spec.actual_size = j;*/
        } 
        else if (str[0] == 'S' && count == 0) count++;
        else if (str[0] == 'S' && count != 0) {
            spec.scan = count;
            // now remove zeroes
            double tmp_mass[maxSize];
            double tmp_int[maxSize];
            for (int i = 0; i < maxSize; i++) {
                tmp_mass[i] = spec.fragMass[i];
                tmp_int[i] = spec.fragInt[i];
            }
            for (int i = 0; i < maxSize; i++) {
                spec.fragMass[i] = 0.0;
                spec.fragInt[i] = 0.0;
            }
            // now copy only non zero elements to spec.fragMass and spec.fragInt
            int j = 0;
            for (int i = 0; i < maxSize; i++) {
                if (tmp_mass[i] != 0) {
                    spec.fragMass[j] = tmp_mass[i];
                    spec.fragInt[j] = tmp_int[i];
                    j++;
                }
            }
            spec.actual_size = j;
	    sort_masses(&spec);
            fwrite(&spec, sizeof(struct Spectrum), 1, ofptr);
            count++;
            for (int counter = 1; counter <= 21; counter++)  i[counter] = 0;
            spec = empty;
        } 
    }
    if (feof(fptr)) {
        spec.scan = count;
	// now remove zeroes
        double tmp_mass[maxSize];
        double tmp_int[maxSize];
        for (int i = 0; i < maxSize; i++) {
            tmp_mass[i] = spec.fragMass[i];
            tmp_int[i] = spec.fragInt[i];
        }
        for (int i = 0; i < maxSize; i++) {
            spec.fragMass[i] = 0.0;
            spec.fragInt[i] = 0.0;
        }
        // now copy only non zero elements to spec.fragMass and spec.fragInt
        int j = 0;
        for (int i = 0; i < maxSize; i++) {
            if (tmp_mass[i] != 0) {
                spec.fragMass[j] = tmp_mass[i];
                spec.fragInt[j] = tmp_int[i];
                j++;
            }
        }
        spec.actual_size = j;
	sort_masses(&spec);
        fwrite(&spec, sizeof(struct Spectrum), 1, ofptr);
    } 
    fclose(fptr);
    fclose(ofptr);

    /*  
    // This is for checking the output file
    if ((ofptr = fopen(argv[2], "rb")) == NULL) {
        printf("Error opening binary file for reading.");
        exit(1);
    }

    spectrum spec1;
    while (fread(&spec1, sizeof(spectrum), 1, ofptr) == 1) {
        printf("Scan %d\nPrecMass %lf\nRetTime %lf\n", spec1.scanNum, 
            spec1.precMass, spec1.retTime); 
        for (int iter = 0; iter < sizeof(spec1.fragMass)/sizeof(double); iter++) {
            //if (spec.fragMass[iter] != 0) 
            printf("%lf\t%lf\n", spec1.fragMass[iter], spec1.fragInt[iter]);
        }
    }
    
    fclose(ofptr); 
    */

    printf("Parsed %d spectra.\n", count);
    return 0;

}
