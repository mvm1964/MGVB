/*
 *
 * Update 23.09.2021: the program runs and debugs but there are problems:
 * 1. Results on mac os and linux cluster differ
 * 2. Large arrays are declared automatic, which could cause stack overflow
 * 4. No way to know that messages are recvd or send before corresponding
 * data is used
 * Should consider:
 * 1. Allocating the spectra and results array on the heap in each process
 * 2. Change to non-blocking communications
 * 3. Write some rest to make sure slave processes are copying the database
 *    properly
 *
 *
 * Update 30.01.2022: there is still the problem with overlapping specificities. 
 * The mod_comb table contains a lot of these. The algorithm does not handle
 * this and the probgram is not functional for now. Should either try to fix
 * it or publish without the open search for combinatorial search first.
 *
 * Update 16.02.2022: tests are promissing but there are certain things
 * that need addresssing:
 * 1. The error tolerance for mod_comb is too large and sulfonation and
 *    phosphorylation are equally selected. Will change it to 10ppm
 * 2. Need to correct scorer_omp to save fragment masses and then 
 *    correct select_by_prob to process the new format. As of now
 *    it does not process socrer_mpi output. In fact it writes huge
 *    files that can fill the storage quickly. This is a bug to carefully
 *    analyse and make sure it is corrected.
 * 3. change the code to determine number of spectra as in scorer_omp.
 */


#include <stdio.h>
#include <mpi.h>
#include <stdlib.h>
#include <string.h>
#include "sqlite3.h"
#include <math.h>
#include <gmp.h>
#include <mpfr.h>
#include "pepMass.h"
#include "Item.h"
#include "bst.h"
#include "compute_site_prob_open_optimized.h"


// Struct to hold the results. Will allocate two for each spectrum to hold top 2 scorers
typedef struct Results {
    int Total;
    int Matched;
    char mod1_probs[2048];
    char mod2_probs[2048];
    char mod3_probs[2048];
    char Fragments[4096];
    char Masses[4096];
    int Scan;
    int PrecScan;
    double RetTime;
    char Sequence[1024];
    int Charge;
    double PrecMass;
    double Score;
    char Proteins[4096];
    char mod1[1024];
    char mod2[1024];
    char mod3[1024];
    int nMod;
    int Missed;
    int Decoy;
    int Contam;
} results;


// This function reverses strings (copied it from the web).
/*char *strrev(char *str) {
      char *p1, *p2;

      if (! str || ! *str)
            return str;
      for (p1 = str, p2 = str + strlen(str) - 1; p2 > p1; ++p1, --p2)
      {
            *p1 ^= *p2;
            *p2 ^= *p1;
            *p1 ^= *p2;
      }
      return str;
}*/


// Parser function for parsing run parameters
int parse_params(char *config_file, int *prTol, double *frTol, char fasta[5][2048], int *maxMod) {

    FILE *cnfg;
    char str[1028];
    int fasta_ctr = 0;
    //int ptm_ctr = 0;

    // Open config file for reading
    if ((cnfg = fopen(config_file, "r")) == NULL) {
        printf("Error opening config file!");
        exit(1);
    }

    // Read the config file line by line and parse it.
    while (fgets(str, sizeof(str), cnfg) != NULL) {
        if (strstr(str, "_precTol")) {
            sscanf(str, "_precTol\t%d", prTol);
        }
        else if (strstr(str, "_tol")) {
            sscanf(str, "_tol\t%lf", frTol);
        }
            /*else if (strstr(str, "_q")) {
                sscanf(str, "_q\t%d", fr_q);
            }
            else if (strstr(str, "_maxSize")) {
                sscanf(str, "_maxSize\t%d", fr_maxSize);
            }*/
        else if (strstr(str, "_fasta")) {
            sscanf(str, "_fasta\t%s", fasta[fasta_ctr]); // fasta should be crated in main with sufficient size
            fasta_ctr++;
        }
        else if (strstr(str, "_maxMod")) {
            sscanf(str, "_maxMod\t%d", maxMod);
        }

        /* Having second thought about ptm. No need to rewrite so much code.
           will just modify the code in main and other functions that read ptm
        */
    }
    fclose(cnfg);
    return fasta_ctr;
}

// A file pointer for the results. Declared here so it can be used by many functions.
FILE *res;
int precTol = 10;
double tol = 0.6;

/* A function to compute xcorr.

   Now it considers modifications (see update above). It should do something like:

   If there are modification:

   1. For each fragMass: look in the sequence and mod info and decide what masses
      to compare to the spectral data. Should generate combinations, test
      if corresponding masses match spectral peaks and update the counter.
      Combinations:
      - First, for each type of modification determine the total number of modifiable
        residues (N[], should be an array of size i).
      - For a specific y fragment determine the number of modifiable residues of given
        type (n1[j]).
      - Let the required number for a modification be n (from the data returned from mod-pep query).
      - Now:
            if (n1[j] = 0) no modifications for this fragment;
            else if (N[j] - n1[j] < n) combine from n - (N[j] - n1)[j] to n1[j];
            else combine from 0 to n1[j];
            cognate fragment masses are computed as usual:
                pepMass - fragMass + Pr + Pr;
   2. Keep account of what peptide is top scorer.

   If top scorer is modified peptide:

   3. Estimate localisation probabilities for the top scorer.

   If top scorer is unmodified proceed as previously.

   Update 09.09.2019

      It might be simpler to go to individual combinations as geenrated by comb_kN.c and
      then sum up the matches to allow for isoforms. Given that com_kN is already implemented
      this will speed up development and will also allow easier computation of individual scores for
      isoforms.

      to do this we will need code that uses

   Update May 2020: now we use a bst function which generates a search tree for all possible combinations
   of modifications positions and corresponding y and b fragments. scorer_mod now needs to use this tree to
   check each spectrum peak for matching and output the corresponding data to a file. It also needs to use the
   Bayesian network function to compute site probabilities.


   Update 02.08.2021: need to refactor xcorr and calback to be able to only write results rows with score > of certain limit

*/
double xcorr(char *seq, double *frmz, double *frint, int charge, double prec, int n, int *counts, int numMod, Item item, Item item1, mod_ind *mod, results *results1, results *results2, int specNo, char *proteins, int missed, int decoy, int contam, int N_mod) {
    //int n1 = strlen(seq);
    int n2 = 0; // for counting matched masses
    //int n4 = 2*n1 - 2;
    //double xcr = 0;
    double res123 = 0;

    /* Update 15.07.2020: create item_array and n_item vars. Should not forget to free(item_array)
       because interval_search() realloc memory to it.
    */
    Item *item_array = NULL; //(Item *)malloc(0);
    int n_item = 0;

    // Update 27.08.2021: need to add information about mod counts
    char probabilities[2048];
    char mod_count[32];


    // for sprinf of integers and chars later
    char str22[2048];

    // Variables for computing binomial coefficient and probabilities
    mpf_t p;
    mpf_t p1;
    mpz_t comb;
    mpf_t prob1;
    mpf_t prob2;
    mpf_t prob;
    mpf_t comb1;
    mpfr_t score;
    mpz_init_set_ui(comb, 0);
    mpf_init_set_d(prob1, 0);
    mpf_init_set_d(prob2, 0);
    mpf_init_set_d(prob, 0);

    // Update 19.07.2021: p should be a function of fragment mass tolerance and the number of peaks in the spectrum
    /*
       Notes on binomial probability rationale: we consider n4, the total number of fragment fragments to be the
       number of trials. It is as if each theoretical fragment is a trial, that is if its mass matches one of
       the spectrum peaks. The probability for such match at random depends on the number of peaks in the spectrum and
       on the mass tolerance. We admit only q peaks per 100Th interval so we can use this instead of n.

       Things to consider: we can turn the table— the trials could be the number of peaks in the spectrum, the successes
       remain n2. Now p should be dependent on n4. For example p = n4/(mass range/tol)
    */
    mpf_init_set_d(p, q/(100));
    mpf_init_set_d(p1, 1-q/(100));
    mpf_init_set_d(comb1, 0);
    mpfr_init(score);
    mpfr_set_d(score, 0, MPFR_RNDZ);
    mpfr_t cdf;
    mpfr_init_set_d(cdf, 0, MPFR_RNDZ);

    /* Update 22.05.2020: starting the new implementation with BST
       xcor should call bst with the sequence and the mod string and info.
       Once the bst is ready it should then interrogate each spectrum mass
       accounting for double charged fragments as below.
       Create the bst: we call bst passing the counts pointer, sequence string
       pinter, the string length, and the ptm ppointer. bst will build the tree
       and return a link pointer.
    */
    bst(counts, seq, n, item, item1, mod, numMod);
    int n4 = head->N;
    if (charge > 2) n4 = 2*n4 - 2;

    // for debugging
    /*printf("Printing BST for %s\n", seq);
    STprint(head);*/

    // Now use the tree to search for matches to the spectrum masses. Should account
    // for doubly charged fragments if precursor charge > 2.
    for (int i = 0; i < n; i++) {
        //if (frmz[i] == 0 || frint[i] == 0) continue;

        //xcr = xcr + frint[i];

        // Update 15.07.2020: changing to interval_search() function and implementing site probability scorin

        // For debugging
        //printf("Search mass and n are %lf, %d\n", frmz[i], n);

        n2 += interval_search(head, frmz[i] - tol, frmz[i] + tol, &item_array, &n_item, frmz, i, 0, tol);

        /*
         Update 18.07.2021: will start implementing water and amonia losses search
         for now in the scoring funcrion but later will do it in bst in a more inteligent way
        */

        // search for b-NH3 and y-NH3
        //if (strstr(seq, "N") || strstr(seq, "Q")) {
        //    n2 += interval_search(head, frmz[i] + (Nitrogen + 3*H) - tol, frmz[i] + (Nitrogen + 3*H) + tol, &item_array, &n_item);
        //}

        // search for y-H2O
        //if (strstr(seq, "D") || strstr(seq, "E") || strstr(seq, "S") || strstr(seq, "T")) {
        //    n2 += interval_search(head, frmz[i] + H2O - tol, frmz[i] + H2O + tol, &item_array, &n_item);
        //}
        if (charge > 2){
            n2 += interval_search(head, (frmz[i]*2 - Pr) - tol, (frmz[i]*2 - Pr) + tol, &item_array, &n_item, frmz, i, 1, tol);

            // search for b-NH3 and y-NH3
            //if (strstr(seq, "N") || strstr(seq, "Q") || strstr(seq, "H")) {
            //    n2 += interval_search(head, (frmz[i] + (Nitrogen + 3*H))*2 - Pr - tol, (frmz[i] + (Nitrogen + 3*H))*2 - Pr + tol, &item_array, &n_item);
            //}

            // search for y-H2O
            //n2 += interval_search(head, (frmz[i] + H2O)*2 - Pr - tol, (frmz[i] + H2O)*2 - Pr + tol, &item_array, &n_item);
        }


        //if (maxint < frint[i]) maxint = frint[i];
        //sumint += frint[i];
    }

    //n2 = n_item;

    // For debugging
    //printf("n2, n_item are %d, %d\n", n2, n_item);

    // Update 14.08.2020: there was an error in score calculation for modified peptides
    //int n4 = head->N;

    // for debugging
    //printf("old n4 is %d, new n4 is %d\n", 2*n1 - 2, n4);

    // Update 02.08.2021: need to calculate score here before computing localizaton probabilities
    if (n2 > 0 && n2 < n4){
        for (int i = n2; i <= n4; i++) {
            mpf_pow_ui(prob1, p, i);
            mpf_pow_ui(prob2, p1, n4-i);
            mpf_mul(prob, prob1, prob2);
            mpz_bin_uiui(comb, n4, i);
            mpf_set_z(comb1, comb);
            mpf_mul(prob, prob, comb1);
            mpfr_set_f(score, prob, MPFR_RNDZ);
            mpfr_add(cdf, cdf, score, MPFR_RNDZ);
        }

        mpfr_log10(cdf, cdf, MPFR_RNDZ);
        res123 = -10*mpfr_get_d(cdf, MPFR_RNDZ);
        mpz_clear(comb);
        mpf_clear(p);
        mpf_clear(p1);
        mpf_clear(prob1);
        mpf_clear(prob2);
        mpf_clear(prob);
        mpf_clear(comb1);
        mpfr_clear(score);
        mpfr_clear(cdf);
        //return res123;
    }
    else if (n2 > 0 && n2 >= n4)  {
        mpf_pow_ui(prob1, p, n4);
        mpfr_set_f(score, prob1, MPFR_RNDZ);
        mpfr_log10(score, score, MPFR_RNDZ);
        res123 = -10*mpfr_get_d(score, MPFR_RNDZ);
        mpz_clear(comb);
        mpf_clear(p);
        mpf_clear(p1);
        mpf_clear(prob1);
        mpf_clear(prob2);
        mpf_clear(prob);
        mpf_clear(comb1);
        mpfr_clear(score);
        mpfr_clear(cdf);
        //return res123;
    }
    else {
        mpz_clear(comb);
        mpf_clear(p);
        mpf_clear(p1);
        mpf_clear(prob1);
        mpf_clear(prob2);
        mpf_clear(prob);
        mpf_clear(comb1);
        mpfr_clear(score);
        mpfr_clear(cdf);
        res123 = 0;
    }



    // Update 16.08.2021: starting refactoring to use new results type
    if (res123 > results1[specNo].Score) {
        results1[specNo].Total = n4;
        results1[specNo].Matched = n2;
        results1[specNo].Score = res123;
        strcpy(results1[specNo].Proteins, proteins);
        strcpy(results1[specNo].Sequence, seq);
        results1[specNo].nMod = N_mod;
        results1[specNo].Missed = missed;
        results1[specNo].Decoy = decoy;
        results1[specNo].Contam = contam;



        if (counts[0] == 0) {
            strcpy(results1[specNo].mod1_probs, "NA");
            strcpy(results1[specNo].mod1, "NA");
        }

        else {
            strcpy(probabilities, "");
            compute_site_prob_open_optimized(probabilities, 0, counts[0], seq, item_array, n_item);
            strcpy(results1[specNo].mod1_probs, probabilities);
            strcpy(results1[specNo].mod1, ptm[0].name);
            sprintf(mod_count, "(%d)", counts[0]);
            strcat(results1[specNo].mod1, mod_count);
            strcpy(mod_count, "");
        }
        if (counts[1] == 0) {
            strcpy(results1[specNo].mod2_probs, "NA");
            strcpy(results1[specNo].mod2, "NA");
        }
        else {
            strcpy(probabilities, "");
            compute_site_prob_open_optimized(probabilities, 1, counts[1], seq, item_array, n_item);
            strcpy(results1[specNo].mod2_probs, probabilities);
            strcpy(results1[specNo].mod2, ptm[1].name);
            sprintf(mod_count, "(%d)", counts[1]);
            strcat(results1[specNo].mod2, mod_count);
            strcpy(mod_count, "");
        }
        if (counts[2] == 0) {
            strcpy(results1[specNo].mod3_probs, "NA");
            strcpy(results1[specNo].mod3, "NA");
        }
        else {
            strcpy(probabilities, "");
            compute_site_prob_open_optimized(probabilities, 2, counts[2], seq, item_array, n_item);
            strcpy(results1[specNo].mod3_probs, probabilities);
            strcpy(results1[specNo].mod3, ptm[2].name);
            sprintf(mod_count, "(%d)", counts[2]);
            strcat(results1[specNo].mod3, mod_count);
            strcpy(mod_count, "");
        }
        strcpy(results1[specNo].Fragments, "");
        strcpy(results1[specNo].Masses, "");
        for (int i = 0; i < n_item; i++) {
            //fprintf(res,"%c%d,", item_array[i]->fragType, item_array[i]->index);
            sprintf(str22, "%s,", item_array[i]->fragType);
            strcat(results1[specNo].Fragments, str22);
            //strcat(results1[specNo].Fragments, item_array[i]->fragType);
            //strcat(results1[specNo].Fragments, item_array[i]->index);
            //strcat(results1[specNo].Fragments, ",");
        }
        for (int i = 0; i < n_item; i++) {
            //fprintf(res,"%c%d,", item_array[i]->fragType, item_array[i]->index);
            sprintf(str22, "%lf,", *(item_array[i]->key));
            strcat(results1[specNo].Masses, str22);
            //strcat(results1[specNo].Masses, item_array[i]->key);
            //strcat(results1[specNo].Masses, ",");
        }
	// 11.09.2022: need to free  the items in item_array
        for (int i = 0; i < n_item; i++) {
            free(item_array[i]->key);
            free(item_array[i]);
        }
        free(item_array);
        STdestroy(head);
        return res123;
    }
    else if (res123 > results2[specNo].Score) {
        results2[specNo].Total = n4;
        results2[specNo].Matched = n2;
        results2[specNo].Score = res123;
        strcpy(results2[specNo].Proteins, proteins);
        strcpy(results2[specNo].Sequence, seq);
        results2[specNo].nMod = N_mod;
        results2[specNo].Missed = missed;
        results2[specNo].Decoy = decoy;
        results2[specNo].Contam = contam;

        if (counts[0] == 0) {
            strcpy(results2[specNo].mod1_probs, "NA");
            strcpy(results2[specNo].mod1, "NA");
        }
        else {
            strcpy(probabilities, "");
            compute_site_prob_open_optimized(probabilities, 0, counts[0], seq, item_array, n_item);
            strcpy(results2[specNo].mod1_probs, probabilities);
            strcpy(results2[specNo].mod1, ptm[0].name);
            sprintf(mod_count, "(%d)", counts[0]);
            strcat(results2[specNo].mod1, mod_count);
            strcpy(mod_count, "");
        }
        if (counts[1] == 0) {
            strcpy(results2[specNo].mod2_probs, "NA");
            strcpy(results2[specNo].mod2, "NA");
        }
        else {
            strcpy(probabilities, "");
            compute_site_prob_open_optimized(probabilities, 1, counts[1], seq, item_array, n_item);
            strcpy(results2[specNo].mod2_probs, probabilities);
            strcpy(results2[specNo].mod2, ptm[1].name);
            sprintf(mod_count, "(%d)", counts[1]);
            strcat(results2[specNo].mod2, mod_count);
            strcpy(mod_count, "");
        }
        if (counts[2] == 0) {
            strcpy(results2[specNo].mod3_probs, "NA");
            strcpy(results2[specNo].mod3, "NA");
        }
        else {
            strcpy(probabilities, "");
            compute_site_prob_open_optimized(probabilities, 2, counts[2], seq, item_array, n_item);
            strcpy(results2[specNo].mod3_probs, probabilities);
            strcpy(results2[specNo].mod3, ptm[2].name);
            sprintf(mod_count, "(%d)", counts[2]);
            strcat(results2[specNo].mod3, mod_count);
            strcpy(mod_count, "");
        }

        strcpy(results2[specNo].Fragments, "");
        strcpy(results2[specNo].Masses, "");
        for (int i = 0; i < n_item; i++) {

            sprintf(str22, "%s,", item_array[i]->fragType);
            strcat(results2[specNo].Fragments, str22);

            //fprintf(res,"%c%d,", item_array[i]->fragType, item_array[i]->index);
            //strcat(results2[specNo].Fragments, item_array[i]->fragType);
            //strcat(results2[specNo].Fragments, item_array[i]->index);
            //strcat(results2[specNo].Fragments, ",");
        }
        for (int i = 0; i < n_item; i++) {
            //fprintf(res,"%c%d,", item_array[i]->fragType, item_array[i]->index);
            //strcat(results2[specNo].Masses, item_array[i]->key);
            //strcat(results2[specNo].Masses, ",");
            sprintf(str22, "%lf,", *(item_array[i]->key));
            strcat(results2[specNo].Masses, str22);
        }

        for (int i = 0; i < n_item; i++) {
            free(item_array[i]->key);
            free(item_array[i]);
	}
	free(item_array);
        STdestroy(head);
        return res123;

    }
        /*if (res123 > 1) {
            // Update 23.07.2020: starting localisation probabilities code
            if (n2 > 0) {
                fprintf(res, "%d\t%d\t", n4, n2);
                for (int ctr = 0; ctr < 3; ctr++) {
                    if (counts[ctr] == 0) fprintf(res, "NA\t");
                    else compute_site_prob(res, ctr, counts[ctr], seq, item_array, n_item);
                }
            }

            // update 21.07.2021: will save fragments to results file
            for (int i = 0; i < n_item; i++) {
                fprintf(res,"%c%d,", item_array[i]->fragType, item_array[i]->index);
            }
            //fprintf(res, "\t");
            for (int i = 0; i < n_item; i++) {
                fprintf(res,"%lf,", *(item_array[i]->key));
            }


            //fprintf(res,"\t");

            free(item_array);
            STdestroy(head);
            return res123;
        }*/

    else {
	for (int i = 0; i < n_item; i++) {
	    free(item_array[i]->key);
	    free(item_array[i]);
	}
        free(item_array);
        STdestroy(head);
        return 0;
    }
    /* Things to consider: we can turn the table— the trials could be the number of peaks in the spectrum, the successes
       remain n2. Now p should be dependent on n4. For example p = n4/(mass range/tol)
       later same day: not giving good results
    */

    /*if (n4 > 0) {
        mpf_init_set_d(p, n4*tol/(q*60));
        mpf_init_set_d(p1, 1-n4*tol/(q*60));
    }*/


}

/* Callback function for sqlite3
   Need to include matched and total ion numbers in the results. Will have to modify the function
   to receive the score and the matched ion number as a pointer to array (18.07.2020).
*/
int callback(sqlite3 *db, char *sql_inst_1, int rowid, double mass, int *counts, int i, char *seq, void *dt, char *proteins, Item item, Item item1, mod_ind *mod, link head, link z, int missed, int decoy, int contam, results *results1, results *results2, int specNo) {
    //int i;

    // For debugging
    //for (int ctr = 0; ctr < i; ctr++) printf("%s is %d\n", ptm[ctr].name, ptm[ctr].count);

    spectrum *spec = (spectrum *) dt;
    //sqlite3 *db = (sqlite3 *) db1;
    int rc_1;
    double score = 0;
    int N_mod = 0;
    int numMod = 0;
    sqlite3_stmt *ppStmt_1;
    // these will be used to test if string is compatible with modifictions
    int nMod1 = 0;
    int nMod2 = 0;
    int nMod3 = 0;

    /* Update 11.08.2021: starting implementation of open search. Will change the function to accept the database connection
       and delta mass, then search the mod_comb table, populate the ptm array, create mod_ind etc and call xcorr.


       13.08.2021: Need to test if peptide is unmodified: delta mass is within the high-res precursor tol and if so compute score for unmodified       peptide and return
    */

    if (fabs(spec->precMass - mass) < 10*spec->precMass/1000000) {
        score = xcorr(seq, spec->fragMass, spec->fragInt, spec->charge, spec->precMass, sizeof(spec->fragMass)/sizeof(double), counts, numMod, item, item1, mod, results1, results2, specNo, proteins, missed, decoy, contam, N_mod);
        if (score > 0) {
            //fprintf(res, "\b \t%d\t%d\t%lf\t%s\t%d\t%lf\t%lf\t%s", spec->scan, spec->scanNum, spec->retTime, seq, spec->charge, spec->precMass, score, proteins);
            results1[specNo].Scan = spec->scan;
            results1[specNo].PrecScan = spec->scanNum;
            results1[specNo].RetTime = spec->retTime;
            results1[specNo].Charge = spec->charge;
            results1[specNo].PrecMass = spec->precMass;

            results2[specNo].Scan = spec->scan;
            results2[specNo].PrecScan = spec->scanNum;
            results2[specNo].RetTime = spec->retTime;
            results2[specNo].Charge = spec->charge;
            results2[specNo].PrecMass = spec->precMass;

            //for (int ctr = 0; ctr < 3; ctr++) fprintf(res, "\tNA");
            //fprintf(res, "\t%d\t%d\t%d\t%d\n", N_mod, missed, decoy, contam);
        }
        return 0;

    }
    // Update 31.01.2022: need to use fabs as above? Of course not, there are negative delta masses as well but need to reverse the equation..
    //sprintf(sql_inst_1, "select * from mod_comb where Delta_mass between %lf and %lf;", mass - spec->precMass - 0.02, mass - spec->precMass + 0.02);
    sprintf(sql_inst_1, "select * from mod_comb where Delta_mass between %lf and %lf;", spec->precMass - mass - 10*(fabs(spec->precMass - mass))/1000000, spec->precMass - mass + 10*(fabs(spec->precMass - mass))/1000000);
    //printf("%s\n", sql_inst_1);
    //exit(1);
    sqlite3_prepare_v2(db, sql_inst_1, -1, &ppStmt_1, 0);
    //exit(0);
    while ((rc_1 = sqlite3_step(ppStmt_1)) != 101) {
        if (rc_1 == 100) {
            // now populate ptm,  test if sequence is compatible with modification and call xcorr
            // for debugging
            //printf("ptm[0].delta_mass as it come from db is %lf\n", sqlite3_column_double(ppStmt_1, 1));
            ptm[0].delta_mass = sqlite3_column_double(ppStmt_1, 1);
            ptm[1].delta_mass = sqlite3_column_double(ppStmt_1, 2);
            ptm[2].delta_mass = sqlite3_column_double(ppStmt_1, 3);
            strcpy(ptm[0].name, (char *)sqlite3_column_text(ppStmt_1, 4));
            strcpy(ptm[1].name, (char *)sqlite3_column_text(ppStmt_1, 5));
            strcpy(ptm[2].name, (char *)sqlite3_column_text(ppStmt_1, 6));
            strcpy(ptm[0].site, (char *)sqlite3_column_text(ppStmt_1, 7));
            strcpy(ptm[1].site, (char *)sqlite3_column_text(ppStmt_1, 8));
            strcpy(ptm[2].site, (char *)sqlite3_column_text(ppStmt_1, 9));
            N_mod = sqlite3_column_int(ppStmt_1, 10);
            ptm[0].count = sqlite3_column_int(ppStmt_1, 11);
            ptm[1].count = sqlite3_column_int(ppStmt_1, 12);
            ptm[2].count = sqlite3_column_int(ppStmt_1, 13);

            // for debugging
            //printf("ptm[0].delta_mass in thread %d is %lf\n", omp_get_thread_num(), ptm[0].delta_mass);

            /* need to check if mod1,mod2,mod3 are different and reshape the mod array accordingly at some point so bst can work properly
               this will be easiest done by changing mod_comb table to contain counts for each mod
               ok, now it's done
            */
            // now check if seq is compatible with the modifications
            /*
               Update 13.08.2021:
               this is not trivial as modifications can have overlapping specificities. Thus we need to account for this by summing up
               somehow. For example:

               let ptm[0].site = "*KN"
                   ptm[1].site = "K"
                   ptm[2].site = "NQ"
               This means that the seq will be compatible only if it has K or N for ptm[0] plus extra K for ptm[1] plus extra N or Q for ptm[2]
               I need a function that will do this test efficiently and this will take some time to develop.
               Algorithm 1:
                 1. Encode the sequence with 0 for each residue.
                 2. For each ptm encode matching sites with corresponding numbers (1, 2 or 3). This will creates 3 strings (or arrays rather).
                 3. "Merge" the 3 arrays into a single final array:
                    for i from 1 to end of string -> if array1[i] is not 0 than final_array[i] = array1[i]; nMod1++;
                    for i from 1 to end of string -> if array2[i] is not 0 and final_array[i] is 0 than final_array[i] = array2[i]; nMod2++;
                    for i from 1 to end of string -> if array3[i] is not 0 and final_array[i] is 0 than final_array[i] = array3[i]; nMod3++;                     This covers the case where specificitites are not overlapping and we simply check as in the main code and proceed.
                    But the check might fail when specificities overlap so we continue
                    if (nMod2 < ptm[1].count) go over the final_aray again and re-encode 0 with 1. At each re-encoding keep track of nMod1,
                    nMod2 and nMod3. test if they became sufficient and if so proceed. If nMod1 or nMod2 become less than necessary
                    undo re-encoding
                    Now do this with ptm[2]....

                    Just realized that I have the algorithm already coded for mod_pep. Should just adapt it and use it here.
                    ... but the mod_pepalgorithm does not allow overlapping specificities so need to change it anyway

                    1. Step through the string and check if residue is in the specificity string of the 3 ptms (2 nested loops:
                       outern is over ptms and inner is over the string)
                       increment a counter variable. This is the length of the multiset. From the example specificities above
                       let seq is *LGGKNPPQQR and let counter is y then we have in the two loops:
                       for ptm[0]:  y becomes 3
                       for ptm[1]:  y becomes 4
                       for ptm[2]:  y becomes 7 so the multiset has 7 elements

                       now we step through the sequence first and through ptms in an inner loop and populate the multiset array:
                       0010222
                       Now sort it in lexicogrpahical order: 0001222 so the peptide has 3 potential ptm[0] sites, 1 ptm[1] site
                       and 3 ptm[2] sites but there is overlap and how should we deal with this? If the delta mass suggest 3 ptm[0]
                       modifications this means no ptm[1] is possible. Should change the algorithm to correct multiset for overlaps
                       but how?

                       Let's explore sets and algebra: if the set of ptm[i] sites and ptm[j] sites are overlaping then we neeed the
                       union to form multiset but the union. What the above does is not the union (it only generates the union for
                       non-overlapping specificities). It doubles the intersection so it is the union + intersection. Thus the proper
                       algorithm could either directly find the union, or, if it is more efficient, use the above, find the intersection
                       and subtract it from the multiset.


                       So. let's try a new algrithm:
                       Step over the seq and ecode three arrays for ptm1,2, and 3 (0 non-site, ptm[0] = 1 etc):
                       for ptm[0]: 10001100000 nMod1 = 3
                       for ptm[1]: 00002000000 nMod2 = 1
                       for ptm[2]: 00000300330 nMod3 = 3

                       now we make a union and encode the element that has overlaps with the number that has least counts
                       and correct the nMod accordingly:
                       union is: 10002(nMod1 becomes 2)1(nMod3 becomes2)00330 so this sequence can accomodate the up to 1 ptm[1] and
                       either 2 ptm[2] and 3 ptm[3] or 3 ptm[2] and 2 ptm[3] but how to implement the "either" part

                       the union is: 1000(1 or 2)(1 or 3)0030 we should then generate combinations perhaps and test if any combination
                       is compatible with the delta mass the combinations are:
                           {1,1,1,3,3} no ptm2
                           {1,1,2,3,3}
                           {1,1,3,3,3} no ptm2
                       so the algorithm should generate the combinations and test if there is at least one that is compatible with the
                       ptm array.

                       so the multiset should have 5 elements and we generate combinations and test if any satisfies the conditions:
                       we can modify the mod_pep multiset algorithm:
                       First we determine the smalest nMod and this is nMod2 = 1. If corresponding ptm[1].counter is not 0 we need to
                       take care for this first so we assign at least ptm[1].counter elements of the multiset to this ptm:
                       multiset = {2....} then we rucurr and find the next smallest and assign accordingly and so on until we fill the multiset

                       actually we should start with the smallest ptm[].count, that maks more sense then assign necessary elements if the
                       nMod allows, if not return without processing. If it does then proceed with the next in order

                       Update 30.01.2022: still not working with overlapping site specificities. Should give it couple of days and if not
                       fixed should write up and submit only scorer_omp and leave combinatorial search for next paper. Let's see...

                       could if else if work? Lets try to make a function:

                       it will take ptm array and sequence and return 1 if they are compatible and 0 if not.
                       If any two ptms have overlapping specificities what should the function do? Concatenate site strings? 
                       no, let's try something different:
                       
                       declare 3 new variable: overlap_12, overlap_13, and overlap_23. Initialise them to 0

                       1. Loop through seq and for each char in seq:
                          test if seq[w] matches ptm[0].site
                            If yes, test if it matches ptm[1].site
                              if not, test if it matches ptm[2].site
                                if no increment nMod1
                                if yes increment overlap_13 variable
                              if yes increment overlap_12
                            If not, test if it matches ptm[2].site
                              if yes test if it matches ptm[3].site
                                if not increment nMod2
                                if yes increment overlap_23
                              if not test if it matches ptm[3].site
                                if yes increment nMod3
                       2. At the end of the loop we have nMod and overlap variables with counts of available sites. 
                          we need to somehow use them to determine if seq and ptm are compatible: for example, 
                          for ptm[0] we will have total available sites nMod1 + overlap_12 + overlap_13
                          for ptm[1] we will have total available sites nMod2 + overlap_12 + overlap_23
                          for ptm[2] we will have total available sites nMod3 + overlap_13 + overlap_23

                          Now we need to test all possibilities:
                       
                          if nMod1 >= ptm[0].count then seq is compatible with ptm[0]
                            if not we test if nMod1 + overlap_12 + overlap_13 >= ptm[0].count
                              if yes then ptm[0] is compatible with seq but on condition that ptm[1] and ptm[2] do not need the overlaps
                                therefore we now test if nMod2 >= ptm[1].count
                                  if yes then ptm[1] and seq are compatible
                                    then we test if nMod3 >= ptm[2].count
                                      if yes ptm and seq are compatible and the function terminates with return value of 1
                                      if not we test if nMod3 + overlap_13 + overlap_23 >= ptm[2].count
                                        if not the function terminates and returns 0
                                        if yes ptm[0] and ptm[2] need to be considered together: we need to use set theory for this...
                                          will resume tomorrow 31.01.202
     
                                          after much thinking decided that for now it will only look for non-overlapping specificities
                                          will modify mod_DB1.c to make sure it does (today is 31.01.2022)
        
                                  if not we test if nMod2 + overlap_12 + overlap_23 >= ptm[1].count
                                    Now if yes we need to consider ptm[0] and ptm[1] together
                                      
                                    if not the function terminates and returns 0 
                              if not the function terminates and returns 0
                              
            */
            for (int w = 0; w < strlen(seq); w++) {
                if (strchr(ptm[0].site, seq[w])) nMod1++;
                if (strchr(ptm[1].site, seq[w])) nMod2++;
                if (strchr(ptm[2].site, seq[w])) nMod3++;
            }
            if (nMod1 >= ptm[0].count && nMod2 >= ptm[1].count && nMod3 >= ptm[2].count && strlen(seq) > 1) {
                for (int j = 0; j < i; j++) {
                    if (ptm[j].count > 0) numMod++;
                    counts[j] = ptm[j].count;
                }
                score = xcorr(seq, spec->fragMass, spec->fragInt, spec->charge, spec->precMass, sizeof(spec->fragMass)/sizeof(double), counts, numMod, item, item1, mod, results1, results2, specNo, proteins, missed, decoy, contam, N_mod);
                if (score > 0) {
                    //fprintf(res, "\b \t%d\t%d\t%lf\t%s\t%d\t%lf\t%lf\t%s", spec->scan, spec->scanNum, spec->retTime, seq, spec->charge, spec->precMass, score, proteins);
                    //for (int ctr = 0; ctr < 3; ctr++) fprintf(res, "\t%s", ptm[ctr].name);
                    //fprintf(res, "\t%d\t%d\t%d\t%d\n", N_mod, missed, decoy, contam);
                    results1[specNo].Scan = spec->scan;
                    results1[specNo].PrecScan = spec->scanNum;
                    results1[specNo].RetTime = spec->retTime;
                    results1[specNo].Charge = spec->charge;
                    results1[specNo].PrecMass = spec->precMass;

                    results2[specNo].Scan = spec->scan;
                    results2[specNo].PrecScan = spec->scanNum;
                    results2[specNo].RetTime = spec->retTime;
                    results2[specNo].Charge = spec->charge;
                    results2[specNo].PrecMass = spec->precMass;
                }
                // now need to reset the ptm array for the next candidate
                // update 15.08.2021: counts[] also need resetting for the unmodified peptide search to work
                for (int j = 0; j < 3; j++) {
                    ptm[j].count = 0;
                    counts[j] = 0;

                }
                numMod = 0;
            }
        }
    }
    sqlite3_finalize(ppStmt_1);

    /*
    if (strlen(seq) > 1) {
        //printf("Sequence is %s.\n", argv[0]);
        score = xcorr(seq, spec->fragMass, spec->fragInt, spec->charge, spec->precMass, spec->actual_size, counts, i, item, item1, mod);
        // For debugging
        //printf("Score is %lf\n", score);

        if (score > 0) {
            fprintf(res, "\b \t%d\t%d\t%lf\t%s\t%d\t%lf\t%lf\t%s", spec->scan, spec->scanNum, spec->retTime, seq, spec->charge, spec->precMass, score, proteins);
            for (int ctr = 0; ctr < i; ctr++) fprintf(res, "\t%d", counts[ctr]);
            fprintf(res, "\t%d\t%d\t%d\t%d\n", nMod, missed, decoy, contam);
        }
    }*/

    // Update 01.08.2020: Decoy analysis. Will generate a reverse sequence and analyse it as above.
    // not working so going back to original. Decoy sequences are now in db
    /*char revSeq[strlen(seq)];
    char s[strlen(seq)];
    strcpy(revSeq, seq);
    revSeq[strlen(seq)-1] = '\0';
    strcpy(s, strrev(revSeq));
    strcat(s, seq + strlen(seq) - 1); // this adds the C-terminal K or R

    // Now proceed with analysis of reverse sequence
    score = 0;

    char decoy[2048] = "decoy_:";

    strcat(decoy, proteins);
    score = xcorr(s, spec->fragMass, spec->fragInt, spec->charge, spec->precMass, sizeof(spec->fragMass)/sizeof(double), counts, i, item, item1, mod);

    if (score > 0) {
        fprintf(res, "%d\t%d\t%lf\t%s\t%d\t%lf\t%lf\t%s", spec->scan, spec->scanNum, spec->retTime, s, spec->charge, spec->precMass, score, decoy);
        for (int ctr = 0; ctr < i; ctr++) fprintf(res, "\t%d", counts[ctr]);
        fprintf(res, "\n");
    }

 */
    return 0;
}

int scorer(spectrum spec, results *results1, results *results2, int specNo, sqlite3 *db1, Item item, Item item1, PTM *ptm, double precTol, double tol) {

    // update 29.08.2021: need to declare and assign precTol and tol here or broadcast from master process
    // update 22.09.2021: now changing this to come from master in a broadcast
    //double precTol = 500;
    //double tol = 0.02;

    mod_ind *mod = NULL; // This works, definition with malloc does not.

    // Array to hold modification str.
    //char modStr[1024];
    char seq[1024];
    char proteins[4096]; // Had to increase it to 4096 as it was giving error running on mac os.
    //char *token;
    int i = 3; // now fixed to 3


    // Create counts[i] array to hold number of modifications of each type..
    // this should be passed to callback and populated there
    int counts[i];
    for (int w = 0; w < i; w++) counts[w] = 0;

    // Open sqlite database.

    sqlite3_stmt *ppStmt;
    //sqlite3_stmt *ppStmt_2 = NULL;

    //char *zErrMsg = 0; // Not used.
    int rc;

    double lower;
    double upper;
    int ct = 0;

    char sql_inst[1024];
    char sql_inst_1[1024];

    //Item item = NULL;
    //Item item1 = NULL;

    // now changing the while loop to parallel for



            // Create item pointers and allocate memory.
            /*item = malloc(sizeof(*item));  // This might need to go to scorer_mod.c and be passed as argument.
            if (!item) {
                printf("Error allocating memory for item!\n");
                exit(1);
            }

            // for debugging
            //printf("Created item in thread %d address is %x\n", omp_get_thread_num(), &item);

            item1 = malloc(sizeof(*item1)); // This might need to go to scorer_mod.c and be passed as argument.
            if (!item1) {
                printf("Error allocating memory for item!\n");
                exit(1);
            }

            // for debugging
            //printf("Created item1 in thread %d address is %x\n", omp_get_thread_num(), &item1);

            ptm = (PTM *) malloc(3 * sizeof(PTM));
            if (!ptm) {
                printf("Error allocating memory for ptm array!\n");
                exit(1);
            }*/

            //printf("Created ptm in thread %d address is %x\n", omp_get_thread_num()), &ptm;

            //fseek(mms_ptr, sizeof(spectrum) * specNo, SEEK_SET);
            //fread(&spec1, sizeof(spectrum), 1, mms_ptr);

            lower = spec.precMass - precTol;
            upper = spec.precMass + precTol;

            sprintf(sql_inst, "select * from peptides where mass between %lf and %lf;", lower, upper);
            //printf("Searching for %lf...\n", spec.precMass); // For troubleshooting only
            // Should use prepare/step instead of exec.
            // rc = sqlite3_exec(db, sql_inst, callback, &spec1, &zErrMsg);

            rc = sqlite3_prepare_v2(db1, sql_inst, -1, &ppStmt, 0);

            while ((rc = sqlite3_step(ppStmt)) != 101) {
                if (rc == 100) {

                    /* Read the sequence and modifications and call scoring function.
                       The columns that we need are:
                       0. Rowid (pept id), col 0;
                       1. Mass, col 1;
                       2. 2 to 2 + i - 1. Mod counts 0 to i - 1 (the number of elements in ptm array);
                       3. 2 + i. Sequence;

                    */
                    int rowid = sqlite3_column_int(ppStmt, 0);
                    double mass = sqlite3_column_double(ppStmt, 1); // This will be needed later when we use delat mass.
                    //int counts[i]; // This should only be created once outside the loop.
                    //for (int ctr = 0; ctr < i; ctr++) counts[ctr] = sqlite3_column_int(ppStmt, ctr + 2);

                    // This made me spend a day with valgrind because ptm[].count were not updated.
                    // Do I need counts—I can read the info from ptm.
                    //for (int ctr = 0; ctr < i; ctr++) ptm[ctr].count = sqlite3_column_int(ppStmt, ctr + 2);

                    strcpy(seq, (char *) sqlite3_column_text(ppStmt, 0));

                    // For debuging only
                    //printf("Sequence is %s\n", seq);

                    // Need to parse the string to numbers later when summarising results.
                    strcpy(proteins, (char *) sqlite3_column_text(ppStmt, 2));
                    int missed = sqlite3_column_int(ppStmt, 3);
                    int decoy = sqlite3_column_int(ppStmt, 4);
                    int contam = sqlite3_column_int(ppStmt, 5);

                    callback(db1, sql_inst_1, rowid, mass, counts, i, seq, &spec, proteins, item, item1, mod, head, z,
                             missed, decoy, contam, results1, results2, specNo);
                    // head and z are extern so they don't need to be passed to call back and xcorr. should fix this at some point

                    /*
                    int count_sum = 0;
                    for (int ctr = 0; ctr < i; ctr++) {
                        count_sum += counts[ctr];
                        //printf("%s is %d\n", ptm[ctr].name, ptm[ctr].count);
                    }
                    if (count_sum <= maxMod) { // Need to limit total number of modifications to be considered to avoid hanging the program.
                        callback(rowid, counts, i, seq, &spec1, proteins, item, item1, mod, head, z, missed, decoy, contam, count_sum); // deleted ptm for debugging
                    }*/
                    //else printf("Peptide is not modified.\n"); // For debugging only
                    //callback(rowid, counts, i, seq, &spec1, proteins, item, item1, mod, head, z); // deleted ptm for debugging
                } else {
                    printf("Error executing sql statement: %d.\n", rc);
                    exit(1);
                }
            }

            ct++;
            //ct1 += ct;
            sqlite3_finalize(ppStmt);




            //free(ptm);
            //free(item);
            //free(item1);

            /*
             * Update 17.09.2021: will move declaration of item, item1
             * and ptm to main and make them automatic variables to avoid
             * malloc and free
             */








    //sqlite3_finalize(ppStmt);
    //sqlite3_close(db);

    //free(ptm);
    //free(item);
    //free(item1);
    //free(results1);
    //free(results2);

    //free(mod);
    //free(z);
    // Test with madeup data.
    //double frmz[] = {499.2,823.2,1272.4,331.16, 234.1, 216.1, 762.37, 1117.5};
    //double frint[] = {2500.0,3250.0, 3250.0, 10275.0, 315.0, 1225.0, 4500.0, 2000.0};
    //double prec = pepMass(argv[1]);
    //int n_fr = sizeof(frmz)/sizeof(frmz[0]);
    //double score = xcorr(argv[1], frmz, frint, prec, n_fr);
    //printf("Score for %s is %lf.\n", argv[1], score);

    mpfr_free_cache(); // To prevent memory leaks

    // for debugging
    //printf("%s\n", results1[specNo].Sequence);

    return 0;
}


sqlite3 *db;

int main(int argc, char **argv) {

    MPI_Status status;
    spectrum spec1;
    //results result;
    int N_spectra = atoi(argv[4]);


    // mpi variables
    int my_id, num_procs, root_process, avg_spectra_per_process, an_id,
    start_spec, end_spec, num_spec_to_send, num_spec_to_receive;

    // make mpi data types for spectrum and results
    MPI_Datatype spectrum_type;
    MPI_Datatype type1[7] = {MPI_INT, MPI_INT, MPI_INT, MPI_DOUBLE, MPI_DOUBLE, MPI_DOUBLE, MPI_DOUBLE};
    int blocklen1[7] = {1, 1, 1, 1, 1, maxSize, maxSize};
    MPI_Aint disp1[7];

    MPI_Datatype results_type;
    MPI_Datatype type2[22] = {MPI_INT, MPI_INT, MPI_CHAR, MPI_CHAR, MPI_CHAR, MPI_CHAR,
                              MPI_CHAR, MPI_INT, MPI_INT, MPI_DOUBLE, MPI_CHAR,
                              MPI_INT, MPI_DOUBLE, MPI_DOUBLE, MPI_CHAR, MPI_CHAR, MPI_CHAR,
                              MPI_CHAR, MPI_INT, MPI_INT, MPI_INT, MPI_INT};
    int blocklen2[22] = {1, 1, 2048, 2048, 2048, 4096, 4096, 1, 1, 1, 1024, 1, 1, 1, 4096,
                         1024, 1024, 1024, 1, 1, 1, 1};
    MPI_Aint disp2[22];




    // process spectra here
    int ierr;
    ierr = MPI_Init(&argc, &argv);
    ierr = MPI_Comm_rank(MPI_COMM_WORLD, &my_id);
    ierr = MPI_Comm_size(MPI_COMM_WORLD, &num_procs);

    // allocate arrays
    spectrum *spectra = (spectrum *)calloc(N_spectra, sizeof(spectrum));
    if (!spectra) {
        printf("Error allocating memory for spectra array!\n");
        exit(1);
    }
    results *results1 = (results *)calloc(N_spectra, sizeof(results));
    if (!spectra) {
        printf("Error allocating memory for results1 array!\n");
        exit(1);
    }
    results *results2 = (results *)calloc(N_spectra, sizeof(results));
    if (!spectra) {
        printf("Error allocating memory for results2 array!\n");
        exit(1);
    }

    // now create item, item1, and ptm
    //PTM ptm[3];
    Item item = NULL;
    Item item1 = NULL;

    // commit MPI_datatypes
    disp1[0] = (char *)&spectra[0].scan - (char *)&spectra[0];
    disp1[1] = (char *)&spectra[0].scanNum - (char *)&spectra[0];
    disp1[2] = (char *)&spectra[0].charge - (char *)&spectra[0];
    disp1[3] = (char *)&spectra[0].retTime - (char *)&spectra[0];
    disp1[4] = (char *)&spectra[0].precMass - (char *)&spectra[0];
    disp1[5] = (char *)&spectra[0].fragMass - (char *)&spectra[0];
    disp1[6] = (char *)&spectra[0].fragInt- (char *)&spectra[0];
    MPI_Type_create_struct(7, blocklen1, disp1, type1, &spectrum_type);
    MPI_Type_commit(&spectrum_type);

    disp2[0] = (char *)&results1[0].Total - (char *)&results1[0];
    disp2[1] = (char *)&results1[0].Matched - (char *)&results1[0];
    disp2[2] = (char *)&results1[0].mod1_probs - (char *)&results1[0];
    disp2[3] = (char *)&results1[0].mod2_probs - (char *)&results1[0];
    disp2[4] = (char *)&results1[0].mod3_probs - (char *)&results1[0];
    disp2[5] = (char *)&results1[0].Fragments - (char *)&results1[0];
    disp2[6] = (char *)&results1[0].Masses - (char *)&results1[0];
    disp2[7] = (char *)&results1[0].Scan - (char *)&results1[0];
    disp2[8] = (char *)&results1[0].PrecScan - (char *)&results1[0];
    disp2[9] = (char *)&results1[0].RetTime - (char *)&results1[0];
    disp2[10] = (char *)&results1[0].Sequence - (char *)&results1[0];
    disp2[11] = (char *)&results1[0].Charge - (char *)&results1[0];
    disp2[12] = (char *)&results1[0].PrecMass - (char *)&results1[0];
    disp2[13] = (char *)&results1[0].Score - (char *)&results1[0];
    disp2[14] = (char *)&results1[0].Proteins - (char *)&results1[0];
    disp2[15] = (char *)&results1[0].mod1 - (char *)&results1[0];
    disp2[16] = (char *)&results1[0].mod2 - (char *)&results1[0];
    disp2[17] = (char *)&results1[0].mod3 - (char *)&results1[0];
    disp2[18] = (char *)&results1[0].nMod - (char *)&results1[0];
    disp2[19] = (char *)&results1[0].Missed - (char *)&results1[0];
    disp2[20] = (char *)&results1[0].Decoy - (char *)&results1[0];
    disp2[21] = (char *)&results1[0].Contam - (char *)&results1[0];

    MPI_Type_create_struct(22, blocklen2, disp2, type2, &results_type);
    MPI_Type_commit(&results_type);

    root_process = 0;

    // allocate memory for item and item 1
    item = malloc(sizeof(*item));  // This might need to go to scorer_mod.c and be passed as argument.
    if (!item) {
        printf("Error allocating memory for item!\n");
        exit(1);
    }

    // for debugging
    //printf("Created item in thread %d address is %x\n", omp_get_thread_num(), &item);

    item1 = malloc(sizeof(*item1)); // This might need to go to scorer_mod.c and be passed as argument.
    if (!item1) {
        printf("Error allocating memory for item!\n");
        exit(1);
    }

    ptm = (PTM *) malloc(3 * sizeof(PTM));
    if (!ptm) {
        printf("Error allocating memory for ptm array!\n");
        exit(1);
    }

    //sqlite3 *db; // needs to be global
    int rc;
    sqlite3_stmt *ppStmt;
    rc = sqlite3_open(argv[2], &db);
    if(rc){
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return(1);
    }

    // copy to in memory database
    // now need to copy some data to an in-memory db that will be used in eval_obj()
    sqlite3 *db1;
    sqlite3_backup *pBackup;


    rc = sqlite3_open(":memory:", &db1); // need to write error handling code later
    pBackup = sqlite3_backup_init(db1, "main", db, "main");
    rc = sqlite3_backup_step(pBackup, -1);
    if (rc == SQLITE_DONE) {
        printf("Finished copying to in-memory database in process %d\n", my_id);
    }
    else {
        fprintf(stderr, "Can't copy to in memory database: %s\n", sqlite3_errmsg(db1));
        sqlite3_close(db1);
        return(1);
    }
    (void)sqlite3_backup_finish(pBackup);


    // update 27.09.2021: implementing load balancing
    // will have to use scatterv and gatherv
    avg_spectra_per_process = N_spectra / num_procs;
    int n_extra = N_spectra % num_procs;
    int k = 0;
    int send_count[num_procs];
    int recv_count = 0;
    int displ[num_procs];
    for (int i = 0; i < num_procs; i++) {
        if (i < n_extra) send_count[i] = avg_spectra_per_process + 1;
        else send_count[i] = avg_spectra_per_process;
        displ[i] = k;
        k = k + send_count[i];
    }
    recv_count = send_count[my_id];

    for (int t = 0; t < N_spectra; t++) {
        results1[t].Score = 0;
        results2[t].Score = 0;
        strcpy(results2[t].Fragments, "");
        strcpy(results1[t].Fragments, "");
        strcpy(results1[t].Masses, "");
        strcpy(results2[t].Masses, "");
        strcpy(results1[t].mod1_probs, "");
        strcpy(results2[t].mod1_probs, "");
        strcpy(results1[t].mod2_probs, "");
        strcpy(results2[t].mod2_probs, "");
        strcpy(results1[t].mod3_probs, "");
        strcpy(results2[t].mod3_probs, "");

    }

    if (my_id == root_process) {


        char fasta[5][2048]; // up to 5 fasta files can be used
        int maxMod = 0;

        int ct1 = 0;




        /*for (int t = 0; t < N_spectra; t++) {
            results1[t].Score = 0;
            results2[t].Score = 0;
            strcpy(results2[t].Fragments, "");
            strcpy(results1[t].Fragments, "");
            strcpy(results1[t].Masses, "");
            strcpy(results2[t].Masses, "");
            strcpy(results1[t].mod1_probs, "");
            strcpy(results2[t].mod1_probs, "");
            strcpy(results1[t].mod2_probs, "");
            strcpy(results2[t].mod2_probs, "");
            strcpy(results1[t].mod3_probs, "");
            strcpy(results2[t].mod3_probs, "");

        }*/

        // File pointer to read config info.
        FILE *cnfg;
        if ((cnfg = fopen(argv[3], "r")) == NULL) {
            printf("Error opening config file for reading.\n");
            exit(1);
        }

        // Parse config file
        int fasta_cntr = parse_params(argv[3], &precTol, &tol, fasta, &maxMod);

        // for debugging
        printf("precTol = %d\n", precTol);
        printf("tol = %lf\n", tol);
        printf("maxMod = %d\n", maxMod);
        printf("FASTA files are:\n");
        for (int j = 0; j < fasta_cntr; j++) printf("%s\n", fasta[j]);

        MPI_Bcast(&precTol, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
        MPI_Bcast(&tol, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);


        FILE *mms_ptr;
        // Read data struct by struct, search and write results to file.
        if ((mms_ptr = fopen(argv[1], "rb")) == NULL) {
            printf("Error opening binary file for reading.\n");
            exit(1);
        }
        char resFile[128] = {};
        strcat(resFile, argv[1]);
        strcat(resFile, ".txt");

        if ((res = fopen(resFile, "w")) == NULL) {
            printf("Error opening results file for writing.\n");
            exit(1);
        }

        fprintf(res, "Total\tMatched"); // Need matched and total ion numbers (18.06.2020).
        for (int ctr = 0; ctr < 3; ctr++) fprintf(res, "\tmod%d probs", ctr + 1); // later should put results in data struct perhaps
        fprintf(res, "\tFragments\tMasses\tScan\tPrecScan\tRetTime\tSequence\tCharge\tPrecMass\tScore\tProteins");
        for (int ctr = 0; ctr < 3; ctr++) fprintf(res, "\tmod%d", ctr + 1);
        fprintf(res, "\tnMod\tMissed\tDecoy\tContam\n");

        // Update 16.02.2022: will count number of spectra and increment N_spectra
        /*while (fread(&spec1, sizeof(spectrum), 1, mms_ptr) == 1) {
            N_spectra++;
        }
        // will not do it for now as it will require major refactoring
        */
        for (int j = 0; j < N_spectra; j++) {
            // this should be only done by master
            fseek(mms_ptr, sizeof(spectrum) * j, SEEK_SET);
            fread(&spectra[j], sizeof(spectrum), 1, mms_ptr);

            /*printf("Prec mass is %lf\n", spectra[j].precMass);
            printf("Charge is %d\n", spectra[j].charge);
            printf("fragMass[10] is %lf\n", spectra[j].fragMass[10]);*/


        }


        // scatterv the spectra to all processes
        MPI_Scatterv(&spectra[0], send_count, displ, spectrum_type, &spectra[0], recv_count, spectrum_type, 0, MPI_COMM_WORLD);

        // for debugging
        /*for (int i = 0; i < recv_count; i++) {
            printf("precMass[%d] at process %d = %lf\n", i, my_id, spectra[i].precMass);
            printf("charge[%d] at process %d = %d\n", i, my_id, spectra[i].charge);
            printf("fragMass[%d] at process %d = %lf\n", i, my_id, spectra[i].fragMass[10]);
        }*/
        printf("Root will process the first %d spectra\n", send_count[0]);

        for (int w = 0; w < send_count[0]; w++) {
            //printf("Prec mass is %lf\n", spectra[w].precMass);
            scorer(spectra[w], results1, results2, w, db1, item, item1, ptm, precTol, tol);
            //printf("total at process %d is %d\n", my_id, results1[w].Total);
        }


        // receive data from slaves
        MPI_Gatherv(&results1[0], recv_count, results_type, &results1[0], send_count, displ, results_type, 0, MPI_COMM_WORLD);
        MPI_Gatherv(&results2[0], recv_count, results_type, &results2[0], send_count, displ, results_type, 0, MPI_COMM_WORLD);

        /*for (int w = 0; w < recv_count; w++) {
            printf("total at process %d is %d\n", my_id, results1[w].Total);
        }*/

        // ok, it is working in the master thread, now make it work with slaves

        for (int i = 0; i < N_spectra; i++) {
            fprintf(res, "%d\t%d\t%s\t%s\t%s\t%s\t%s\t%d\t%d\t%lf\t%s\t%d\t%lf\t%lf\t%s\t%s\t%s\t%s\t%d\t%d\t%d\t%d\n",\
        results1[i].Total, results1[i].Matched, results1[i].mod1_probs, results1[i].mod2_probs, \
        results1[i].mod3_probs, results1[i].Fragments, results1[i].Masses, results1[i].Scan, results1[i].PrecScan, \
        results1[i].RetTime, results1[i].Sequence, results1[i].Charge, results1[i].PrecMass, \
        results1[i].Score, results1[i].Proteins, results1[i].mod1, results1[i].mod2, results1[i].mod3, \
        results1[i].nMod, results1[i].Missed, results1[i].Decoy, results1[i].Contam);

            fprintf(res, "%d\t%d\t%s\t%s\t%s\t%s\t%s\t%d\t%d\t%lf\t%s\t%d\t%lf\t%lf\t%s\t%s\t%s\t%s\t%d\t%d\t%d\t%d\n",\
        results2[i].Total, results2[i].Matched, results2[i].mod1_probs, results2[i].mod2_probs, \
        results2[i].mod3_probs, results2[i].Fragments, results2[i].Masses, results2[i].Scan, results2[i].PrecScan, \
        results2[i].RetTime, results2[i].Sequence, results2[i].Charge, results2[i].PrecMass, \
        results2[i].Score, results2[i].Proteins, results2[i].mod1, results2[i].mod2, results2[i].mod3, \
        results2[i].nMod, results2[i].Missed, results2[i].Decoy, results2[i].Contam);

        }

        fclose(mms_ptr);
        fclose(cnfg);
        fclose(res);


    }

    else {

        MPI_Bcast(&precTol, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
        MPI_Bcast(&tol, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);

        MPI_Scatterv(&spectra[0], send_count, displ, spectrum_type, &spectra[0], recv_count, spectrum_type, 0, MPI_COMM_WORLD);

        // for debugging
        /*for (int i = 0; i < recv_count; i++) {
            printf("precMass[%d] at process %d = %lf\n", i, my_id, spectra[i].precMass);
            printf("charge[%d] at process %d = %d\n", i, my_id, spectra[i].charge);
            printf("fragMass[%d] at process %d = %lf\n", i, my_id, spectra[i].fragMass[10]);
        }*/

        // initialize the results arrays
        /*for (int t = 0; t < N_spectra; t++) {
            results1[t].Score = 0;
            results2[t].Score = 0;
            strcpy(results2[t].Fragments, "");
            strcpy(results1[t].Fragments, "");
            strcpy(results1[t].Masses, "");
            strcpy(results2[t].Masses, "");
            strcpy(results1[t].mod1_probs, "");
            strcpy(results2[t].mod1_probs, "");
            strcpy(results1[t].mod2_probs, "");
            strcpy(results2[t].mod2_probs, "");
            strcpy(results1[t].mod3_probs, "");
            strcpy(results2[t].mod3_probs, "");

        }*/


        for (int w = 0; w < recv_count; w++) {
            scorer(spectra[w], results1, results2, w, db1, item, item1, ptm, precTol, tol);
            //printf("total at process %d is %d\n", my_id, results1[w].Total);
        }

        // for debuging
        /*for (int w = 0; w < recv_count; w++) {
            printf("total at process %d is %d\n", my_id, results1[w].Total);
        }*/


        MPI_Gatherv(&results1[0], recv_count, results_type, &results1[0], send_count, displ, results_type, 0, MPI_COMM_WORLD);
        MPI_Gatherv(&results2[0], recv_count, results_type, &results2[0], send_count, displ, results_type, 0, MPI_COMM_WORLD);
    }

    sqlite3_close(db);
    sqlite3_close(db1);

    free(item);
    free(item1);
    free(ptm);
    free(spectra);
    free(results1);
    free(results2);

    // finalize
    ierr = MPI_Finalize();





    //printf("Processed %d MS/MS spectra.\n", ct1);

    return 0;
}

