/*
 * Creates a database of PTM combinations
 * for now it does not handle overlapping
 * specificities. Will implement this in the future
 *
 * Author: Metodi V. Metodiev
 *
 * All rights reserved.
 * Ravna, Bulgaria, 15.08.2021
 *
 * 24.02.2024: wil change it because it is error prone now. Will use realloc
 * to allocate momory for data. 
 *
 * Compilation:
 * gcc -Wall -g modDB_2024.c -o modDB_2024
 *
 * Run:
 * ./modDB_2024 unimod_tables_minimal.txt mod_db_min.db 
 *
 * */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include "sqlite3.h"

typedef struct {
    char full_name[2048];
    double mono_mass;
    char specificity[256];
    char comment[1024];
} mod_comb;

int main(int argc, char **argv) {

    //int n_mod = atoi(argv[2]); // Parse number of modifications in data file.
    char modStr[2048];
    char *token;

    // File pointer to read  data.
    FILE *cnfg;
    if ((cnfg = fopen(argv[1], "r")) == NULL) {
        printf("Error opening config file for reading.\n");
        exit(1);
    }

    mod_comb *data = malloc(sizeof(*data));
    if (!data) {
        printf("Error allocating memory for mod_comb array!\n");
        exit(1);
    }

    int i = 0;
    // Read modifications into mod_comb array from cnfg file.
    while (fgets(modStr, sizeof(modStr), cnfg) != NULL) {
        token = strtok(modStr, "\t");
        strcpy(data[i].full_name, token);
        token = strtok(NULL, "\t");
        data[i].mono_mass = atof(token);
        token = strtok(NULL, "\t");
        strcpy(data[i].specificity, token);
        //token = strtok(NULL, "\n");
        //strcpy(data[i].comment, token);
        //sscanf("%s\t%lf\t%s\t%s",data[i].full_name, &(data[i].mono_mass), data[i].specificity, data[i].comment );
        // cannot use sscanf because of the blanks in names and comments
        i++;

	mod_comb *tmp = realloc(data, (i + 1)*sizeof(*data));
	if (!tmp) {
            printf("Error reallocating memory for mod_comb array!\n");
            exit(1);
        }
	data = tmp;
    }

    printf("Read %d modification\n", i);

    // Open file for writing
    FILE *res;
    char resFile[128] = {};
    strcat(resFile, argv[1]);
    strcat(resFile, ".tsv");

    if ((res = fopen(resFile, "w")) == NULL) {
        printf("Error opening results file for writing.\n");
        exit(1);
    }
    // Read modifications into mod_comb array from cnfg file.
    /*while (fgets(modStr, sizeof(modStr), cnfg) != NULL) {
        token = strtok(modStr, "\t");
        strcpy(data[i].full_name, token);
        token = strtok(NULL, "\t");
        data[i].mono_mass = atof(token);
        token = strtok(NULL, "\t");
        strcpy(data[i].specificity, token);
        //token = strtok(NULL, "\n");
        //strcpy(data[i].comment, token);
        //sscanf("%s\t%lf\t%s\t%s",data[i].full_name, &(data[i].mono_mass), data[i].specificity, data[i].comment );
        // cannot use sscanf because of the blanks in names and comments
        i++;
    }

    printf("Read %d modification\n", i);*/

    // Open file for writing
    //FILE *res;
    //int mod1_count = 0;
    //int mod2_count = 0;
    //int mod3_count = 0;

    /*
     * test new loops for non-ovelapping specificity
     *
     * let
     * data[0].specificity = "*K"
     * data[1].specificity = "M"
     * data[2].specificity = "STY"
     * data[3].specificity = "KS"
     *
     * for (r = 0 to 3)
     *     print data[1] to file
     *     for (j = r to 3)
     *         if j == r print data[r] and data[j]
     *         else
     *             test if overlap with data[1] - no so print data[0],data[1]
     *         for (k = j to 3)
     *             if r == j == k print data[r] data[j] and data[k]
     *             else if r == j != k
     *                 test if overlap with j (or r) - no so print accordingly
     *             else
     *                 test if overlap with j and print accordingly
     *
     *
     */
    int test_specificity = 0;
    for (int r = 0; r < i; r++) {
        // Print data[i] to file
        fprintf(res, "%lf\t%lf\t\t\t%s\t\t\t%s\t\t\t1\t1\t0\t0\n", data[r].mono_mass, data[r].mono_mass, data[r].full_name, data[r].specificity);
        for (int j = r; j < i; j++) {
            // print data[i] + data[j]
            if (j == r) fprintf(res, "%lf\t%lf\t\t\t%s\t\t\t%s\t\t\t2\t2\t0\t0\n", data[r].mono_mass + data[j].mono_mass, data[r].mono_mass, data[r].full_name, data[r].specificity);
            else {
                for (int t = 0; t < strlen(data[r].specificity); t++) {
                    if (strchr(data[j].specificity, data[r].specificity[t])) {
                        test_specificity++;
                        break;
                    }
                }
                if (test_specificity > 0) {
                    test_specificity = 0;
                    continue;
                }
                else fprintf(res, "%lf\t%lf\t%lf\t\t%s\t%s\t\t%s\t%s\t\t2\t1\t1\t0\n", data[r].mono_mass + data[j].mono_mass, data[r].mono_mass, data[j].mono_mass, data[r].full_name, data[j].full_name, data[r].specificity, data[j].specificity);

            }

            for (int k = j; k < i; k++) {
                // print data[i] + data[j] + data[k]
                if (k == r && j == r) fprintf(res, "%lf\t%lf\t\t\t%s\t\t\t%s\t\t\t3\t3\t0\t0\n", data[r].mono_mass + data[r].mono_mass + data[r].mono_mass, data[r].mono_mass, data[r].full_name, data[r].specificity);
                else if (j == r && j != k) {
                    for (int t = 0; t < strlen(data[j].specificity); t++) {
                        if (strchr(data[k].specificity, data[j].specificity[t])) {
                            test_specificity++;
                            break;
                        }
                    }
                    if (test_specificity > 0) {
                        test_specificity = 0;
                        continue;
                    }
                    else {
                        fprintf(res, "%lf\t%lf\t%lf\t\t%s\t%s\t\t%s\t%s\t\t3\t2\t1\t0\n", data[r].mono_mass + data[j].mono_mass + data[k].mono_mass, data[r].mono_mass, data[k].mono_mass, data[r].full_name, data[k].full_name, data[r].specificity, data[k].specificity);
                    }
                }
                else  {
                    for (int t = 0; t < strlen(data[j].specificity); t++) {
                        if (strchr(data[k].specificity, data[j].specificity[t])) {
                            test_specificity++;
                            break;
                        }


                    }
                    for (int t = 0; t < strlen(data[r].specificity); t++) {
                        if (strchr(data[k].specificity, data[r].specificity[t])) {
                            test_specificity++;
                            break;
                        }
                    }
                    if (test_specificity > 0) {
                        test_specificity = 0;
                        continue;
                    }
                    else fprintf(res, "%lf\t%lf\t%lf\t%lf\t%s\t%s\t%s\t%s\t%s\t%s\t3\t1\t1\t1\n", data[r].mono_mass + data[j].mono_mass + data[k].mono_mass, data[r].mono_mass, data[j].mono_mass, data[k].mono_mass, data[r].full_name, data[j].full_name, data[k].full_name, data[r].specificity, data[j].specificity, data[k].specificity);
                }

            }


        }

    }

    free(data);
    fclose(res);
    fclose(cnfg);

    // Now create a sqlite3 db and a table mod_comb.
    char str[1024];
    sprintf(str, "sqlite3 %s 'create table if not exists mod_comb(Delta_mass double, Mod1_mass double, Mod2_mass double, Mod3_mass double, Mod1 text, Mod2 text, Mod3 text, Mod1_specificity text, Mod2_specificity text, Mod3_specificity text, N_mod integer, mod1_count integer, mod2_count integer, mod3_count integer);' '.exit'", argv[2]);
    system(str);
    // Now load the csv file into the table mod_comb
    sprintf(str, "sqlite3 %s '.separator \"\\t\"' '.import %s mod_comb' '.exit'", argv[2], resFile);
    //printf("%s\n", str);
    system(str);

    // Finally, index the database by mass.
    sprintf(str, "sqlite3 %s 'create index if not exists delta_mass on mod_comb(Delta_mass, Mod1, Mod2, Mod3);' '.exit'", argv[2]);
    system(str);


    return 0;

}

