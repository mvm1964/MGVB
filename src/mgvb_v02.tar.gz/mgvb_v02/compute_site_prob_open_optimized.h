#ifndef COMPUTE_SITE_PROB_OPEN_H
#define COMPUTE_SITE_PROB_OPEN_H

//void bayesNet(int, int, mpfr_t*);
//int comb_mN(int, int);
int get_n(char*, int);
int get_m(char*, int);
void model_spec(int, int n, int, int*, int [][n], int, int*);
int test_compat(int*, Item, int, int, int);
void compute_site_prob_open_optimized(char*, int, int, char*, Item*, int);
#endif
