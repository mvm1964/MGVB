/*
  ModDB: creates sqlite3 database of combinations of 
  PTMs for searching delta masses from open MS/MS search results

  Metodi V. Metodiev
  04.07.2020

  Algorithm and usage (might change) notes:

  1. Uses the filtered unimod data file unimod_ptm.txt containing
     tab-delimited columns containing the name of the modification
     ("full_name"), monoisotopic mass ("mono_mass").
  2. Receives as argument the number of modificatoins to combine.
  3. Reads the text file line by line and parses the fields into an 
     array of struct of type mod_comb. No need for dynamic memory reallocation
     as we know the size of the array (argv[2]). Will allocate in a single malloc statement.
  4. A recursive function (it si an nested loops now) than combines elements of the array (with repetition) and 
     saves it in a csv file with columns for the delta mass
     and the full names of the 3 PTMs that were combined in separate columns Mod1, Mod2, Mod3.
  5. Loads the csv file into a sqlite table.
  6. Indexes the table by the delta mass.


  Update 05.08.2021: starting implementation of scorer_open
  1. Need to change mod_comb to include fields for the individual modifications: mod1, mod2, mod3 and their masses: mass1
     mass2 mass3. 
  2. First the unimod file is parsed line by line into the mod_comb array (it is actually single mod array).
  3. The array contains delta mass, site specificity string, name. These should be included in the database.
  4. ptm array elements are combied with repetition and combinations are writen to file containing:
     - ful name
     - delta mass
     -   

  Compilation:
  gcc -Wall -g modDB_2022.c -o modDB_2022
  
  Usage:
  ./modDB_2022 unimod_text_file number_of_mods db_file_name

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include "sqlite3.h"

typedef struct {
    char full_name[2048];
    double mono_mass;
    char specificity[256];
    char comment[1024];
} mod_comb;

int main(int argc, char **argv) {

    int n_mod = atoi(argv[2]); // Parse number of modifications in data file.
    char modStr[2048];
    char *token;
 
    // File pointer to read  data.
    FILE *cnfg;
    if ((cnfg = fopen(argv[1], "r")) == NULL) {
        printf("Error opening config file for reading.\n");
        exit(1);
    }

    mod_comb *data = (mod_comb *)malloc(n_mod*sizeof(mod_comb));
    if (!data) {
        printf("Error allocating memory for mod_comb array!\n");
        exit(1);
    }    
    
    int i = 0;

    // Read modifications into mod_comb array from cnfg file.
    while (fgets(modStr, sizeof(modStr), cnfg) != NULL) {
        token = strtok(modStr, "\t");
        strcpy(data[i].full_name, token);
        token = strtok(NULL, "\t");
        data[i].mono_mass = atof(token);
        token = strtok(NULL, "\t");
        strcpy(data[i].specificity, token);
        //token = strtok(NULL, "\n");
        //strcpy(data[i].comment, token);
        //sscanf("%s\t%lf\t%s\t%s",data[i].full_name, &(data[i].mono_mass), data[i].specificity, data[i].comment );
        // cannot use sscanf because of the blanks in names and comments
        i++;
    }

    printf("Read %d modification\n", i);

    // Open file for writing
    FILE *res;
    char resFile[128] = {};
    strcat(resFile, argv[1]);
    strcat(resFile, ".tsv");

    if ((res = fopen(resFile, "w")) == NULL) {
        printf("Error opening results file for writing.\n");
        exit(1);
    }    

    /* Generate combinations and save to file
    
      1. Print mod_comb[i].
      2. Create mod_comb[i] duplicate, print it, combine it with all others and print.
      3. Print mod_comb[i] triplicate.
      4. Call a recursive comb_kN function with k = 2 (could be nested loops and not a recursion).
      5. Call it with k = 3 (or see above).

   
      1,2,3,4
  
      i = 0
          1
          j = 0
              1+1
              k = 0
                  1+1+1
              k = 1
                  1+1+2
              k = 2
                  1+1+3
              k = 3
                  1+1+4
          j = 1
              1+2
              k = 1
                  1+2+2
              k = 2
                  1+2+3
              k = 3
                  1+2+4
          j = 2
              1+3
              k = 2
                  1+3+3
              k = 3
                  1+3+4
 

          j = 3
              1+4
              k = 3
                  1+4+4

      i = 1
          2
          j = 1
              2+2
              k = 1
                  2+2+2
              k = 2
                  2+2+3
              k = 3
                  2+2+4
          j = 2
              2+3
              k = 2
                  2+3+3
              k = 3
                  2+3+4
          j = 3
              2+4
              k = 3
                  2+4+4
      i = 2
          3
          j = 2
              3+3
              k = 2
                  3+3+3
              k = 3
                  3+3+4
          j = 3
              3+4
              k = 3
                  3+4+4
      i = 3
          4
          j = 3
              4+4
              k = 3
                  4+4+4       
              
     */        

    //fprintf(res, "Delta_mass,Mod1_mass,Mod2_mass,Mod3_mass,Mod1,Mod2,Mod3,Mod1_specificity,Mod2_specificity,Mod3_specificity,N_mod\n");

    /*
       Update 31.01.2022: since combinations with overlapping sepcificity need more work on scorer algo, will modify the code to exclude them.
    */
    int overlap_test = 1;
    for (int i = 0; i < n_mod; i++) {
        // Print data[i] to file
        fprintf(res, "%lf\t%lf\t\t\t%s\t\t\t%s\t\t\t1\n", data[i].mono_mass, data[i].mono_mass, data[i].full_name, data[i].specificity);
        
        for (int j = i; j < n_mod; j++) {
            // print data[i] + data[j]
            // Update 31.01.2022: test if overlapping
            if (i != j) { // need to refactor to not do these extra tests
                for (int w = 0; w < strlen(data[i].specificity); w++) {
                    if (strchr(data[j].specificity, data[i].specificity[w])) overlap_test = 0;
                }
            }
            if (overlap_test == 1) fprintf(res, "%lf\t%lf\t%lf\t\t%s\t%s\t\t%s\t%s\t\t2\n", data[i].mono_mass + data[j].mono_mass, data[i].mono_mass, data[j].mono_mass, data[i].full_name, data[j].full_name, data[i].specificity, data[j].specificity);
            overlap_test = 1;
            for (int k = j; k < n_mod; k++) {
                // print data[i] + data[j] + data[k]
                // Update 31.01.2022: test if overlapping
                if (k != j) {
                    for (int w = 0; w < strlen(data[i].specificity); w++) {
                        if (strchr(data[j].specificity, data[i].specificity[w]) || strchr(data[k].specificity, data[i].specificity[w])) overlap_test = 0;
                    }
                    for (int w = 0; w < strlen(data[j].specificity); w++) {
                        if (strchr(data[k].specificity, data[j].specificity[w])) overlap_test = 0;
                    }
                }
                if (k != i) {
                    for (int w = 0; w < strlen(data[i].specificity); w++) {
                        if (strchr(data[k].specificity, data[i].specificity[w])) overlap_test = 0;
                    }
                }
                if (overlap_test == 1) fprintf(res, "%lf\t%lf\t%lf\t%lf\t%s\t%s\t%s\t%s\t%s\t%s\t3\n", data[i].mono_mass + data[j].mono_mass + data[k].mono_mass, data[i].mono_mass, data[j].mono_mass, data[k].mono_mass, data[i].full_name, data[j].full_name, data[k].full_name, data[i].specificity, data[j].specificity, data[k].specificity);
                overlap_test = 1;
            }
            overlap_test = 1;
        }
        overlap_test = 1;
    }

    // Now create a sqlite3 db and a table mod_comb.
    char str[1024];
    sprintf(str, "sqlite3 %s 'create table if not exists mod_comb(Delta_mass double, Mod1_mass double, Mod2_mass double, Mod3_mass double, Mod1 text, Mod2 text, Mod3 text, Mod1_specificity text, Mod2_specificity text, Mod3_specificity text, N_mod integer);' '.exit'", argv[3]);
    system(str);

    // Now load the csv file into the table mod_comb
    sprintf(str, "sqlite3 %s '.separator \"\\t\"' '.import %s mod_comb' '.exit'", argv[3], resFile);
    //printf("%s\n", str);
    system(str);
 
    // Finally, index the database by mass.
    sprintf(str, "sqlite3 %s 'create index if not exists delta_mass on mod_comb(Delta_mass);' '.exit'", argv[3]);
    system(str);

    free(data);
    fclose(res);
    fclose(cnfg);
    return 0;

}
