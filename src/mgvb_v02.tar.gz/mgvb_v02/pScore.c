#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sqlite3.h"
#include <math.h>
#include <gmp.h>
#include <mpfr.h>

// calculates p-score
double get_Pscore (int n2, int n4, double q1) {   // very importnt: q1 should be double otherwise does not work
    // Variables for computing binomial coefficient and probabilities
    double res123 = 0;

    mpf_t p;
    mpf_t p1;
    mpz_t comb;
    mpf_t prob1;
    mpf_t prob2;
    mpf_t prob;
    mpf_t comb1;
    mpfr_t score;
    mpz_init_set_ui(comb, 0);
    mpf_init_set_d(prob1, 0);
    mpf_init_set_d(prob2, 0);
    mpf_init_set_d(prob, 0);

    mpf_init_set_d(p, q1/(100));
    mpf_init_set_d(p1, 1-q1/(100));
    mpf_init_set_d(comb1, 0);
    mpfr_init(score);
    mpfr_set_d(score, 0, MPFR_RNDZ);
    mpfr_t cdf;
    mpfr_init_set_d(cdf, 0, MPFR_RNDZ);

    if (n2 > 0 && n2 < n4){
        for (int i = n2; i <= n4; i++) {
            mpf_pow_ui(prob1, p, i);
            mpf_pow_ui(prob2, p1, n4-i);
            mpf_mul(prob, prob1, prob2);
            mpz_bin_uiui(comb, n4, i);
            mpf_set_z(comb1, comb);
            mpf_mul(prob, prob, comb1);
            mpfr_set_f(score, prob, MPFR_RNDZ);
            mpfr_add(cdf, cdf, score, MPFR_RNDZ);
        }

        mpfr_log10(cdf, cdf, MPFR_RNDZ);
        res123 = -10*mpfr_get_d(cdf, MPFR_RNDZ);
        // for debuging
        //printf("n2, n4, q1, sore: %d, %d, %lf, %lf\n", n2, n4, q1, res123);
    }

    else if (n2 > 0 && n2 >= n4)  {
        mpf_pow_ui(prob1, p, n4);
        mpfr_set_f(score, prob1, MPFR_RNDZ);
        mpfr_log10(score, score, MPFR_RNDZ);
        res123 = -10*mpfr_get_d(score, MPFR_RNDZ);
    }
    else res123 = 0;

    // free variables
    mpz_clear(comb);
    mpf_clear(p);
    mpf_clear(p1);
    mpf_clear(prob1);
    mpf_clear(prob2);
    mpf_clear(prob);
    mpf_clear(comb1);
    mpfr_clear(score);
    mpfr_clear(cdf);

    // for debuging
    //printf("n2, n4, q1, sore: %d, %d, %d, %lf\n", n2, n4, q1, res123);
    return res123;
}

int main(int argc, char **argv) {

    printf("P score = %lf\n", get_Pscore(atof(argv[1]), atof(argv[2]), atof(argv[3])));
    return 0;

}
