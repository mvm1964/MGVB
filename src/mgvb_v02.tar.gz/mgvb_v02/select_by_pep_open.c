/* Recursive function, which selects proteins from protein_groups
   based on the protein score.
   This is based on the R script Bayesian_optimisation.R

   Algorithm:

   1. Read protein_groups into an array of structs of protein_groups type
   2. Read the proteins table into another array of struct of protein type
   2. Startting from first element of the protein_groups array:
   3. Split the name field and generate a prot_list array with the individual 
      protein IDs.
   4. For each of the protein Ids, search in proteins array and find the score
      Select the ID with max(score) this is the proteinto use from this protein_group
   5. Go throught the remaining elements of the protein_groups array and test if
      names contains the selected protein ID. If yes, remove this element from the array
      and add the corresponding value of count to the protein count
   6. Save the protein id, contam, decoy  and its accumulated count to a 
      new struct array 
   7. Recur with the new 
   
   26.08.2020
   Notes on implementation
   Will implement protein_groups as linked list to be able to process it efficiently
   Will sort proteins array of struct by id to be able to search it efficiently

   Update 09.09.2020: now working. Takes 13-15s to process and export protein_counts.csv.
   Need to incorporate the SQL script in the main function 

   Update 14.09.2020: now it calls the SQL script and does complete post-processing. The 
   only things remaining is to fix binary search and possibly add a Bayesian optimisation
   function. Now it is valgrind checked.

   Update 13.07.2021: should modify the code to not depend on specific types and number
   of modifications. This can be done as follows:

   1. Modify code to import the data into a "scan" table without creating it in advance. This
      will automativcally create the necessary columns.
   2. Remove the first line from sql_statement.sql. It is no longer necessary to delete the first row.
   3. Now, should do one of the following 2 possible things:
      - either create an additional column that contains the total number of modifications for each peptide
      - or write a function to count them using information from the config file 
   
   Compile like this:
   gcc -g -Wall -pthread select_by_prob_2022.c -o select_by_prob_2022 pepMass.c sqlite3.c -ldl

   it is important to use local copy of sqlite3 because it gives errors otherwise. -ldl at the end
   works but not in the middle.

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "sqlite3.h"
#include <libgen.h>
#include "pepMass.h"

#define numMod 3

FILE *protein_counts;

typedef struct PROTEIN_GROUPS *protein_groups; 
struct PROTEIN_GROUPS {
    char names[2048];
    int count;
    int contam;
    int decoy;
    protein_groups next;
};

typedef struct {
    int id;
    int contam;
    int decoy;
    double score;
} proteins;

int match_names(int prot, char *names) {
    char delim[] = ",";
    char *ptr = strtok(names, delim);
    while (ptr != NULL) {
        if (atoi(ptr) == prot) {
            // for debugging
            //printf("matched %s\n", ptr);
            return 1;
        }
        ptr = strtok(NULL, delim);
    } 
    return 0;
}

// Binary search for protein
double get_score(int prot, proteins *Proteins, int n_prot) {
    
    // following C book
    int low, mid, high;
    low = 0;
    high = n_prot - 1;

    while (low <= high) {
        mid = (low + high)/2;
        if (prot < Proteins[mid].id) high = mid -1;
        else if (prot > Proteins[mid].id) low = mid + 1;
        else return Proteins[mid].score;

    }
    return -1;
    
    /*
    // for debigging
    if (n_prot - 1 == start) return 0;

    int mid_point = (start + (n_prot - 1))/2;
    
    // for debugging
    //printf("mid_point id is %d\n", Proteins[mid_point].id);
    
    if ((Proteins + mid_point)->id == prot) return (Proteins + mid_point)->score;
    else if ((Proteins + mid_point)->id > prot) return get_score(prot, Proteins, start, mid_point - 1);
    else return get_score(prot, Proteins, mid_point + 1, n_prot);
    */
    /*    
    for (int i = 0; i < n_prot; i++) {
        if (Proteins[i].id == prot) {

            // for debugging
            //printf("%lf\n", Proteins[i].score);

            return Proteins[i].score;
        }
    } 
    return 0;
    */
}

/* Given a reference (pointer to pointer) to the head of a list 
   and, inserts a new node on the front of the list. */
void push(protein_groups *head_ref, int count, int contam, int decoy, char *names) { 
    protein_groups new_node = (protein_groups)malloc(sizeof(*new_node)); 
    if (new_node == NULL) {
        printf("Cannot allocate protein_groups node!\n");
        exit(1);
    }
    new_node->count = count;
    new_node->contam = contam;
    new_node->decoy = decoy; 
    strcpy(new_node->names, names);
    new_node->next = (*head_ref); 
    (*head_ref)    = new_node;

    // for debugging
    //printf("added %s with contam %d\n", names, contam); 
} 

/* Given a reference (pointer to pointer) to the head of a list 
   and a key, deletes the first occurrence of key in linked list 

   Update 29.08.2020: need to delete all occurrences
   Need to write a function to test if protein is in the list:
   it should read names, split them to individual protein IDs 
   so it takes two arguments: the protein to search from and names

*/
void deleteNode(protein_groups *head_ref, int key, int *count) { 
    // Store head node 
    protein_groups temp = *head_ref, prev; 
    
    // If head node itself holds the key to be deleted 
    // need to split the names strings as integers and compare to keys
    // strtok changes the strings!!! so need to copy to a temp_names
    char temp_names[2048];
    strcpy(temp_names, temp->names);
    if (temp->next != NULL && match_names(key, temp_names) == 1) { 
        *head_ref = temp->next;   // Changed head 
        *count += temp->count;    // add counts
        // for debugging
        //printf("count = %d\n", *count);

        free(temp);
        //deleteNode(head_ref, key, count);
        // free old head
        //temp = *head_ref; 
        //return; no, we want to delete all ocurrences 
        return deleteNode(head_ref, key, count); 
    } 
    
    
    // Search for the key to be deleted, keep track of the 
    // previous node as we need to change 'prev->next' 
    while (temp->next != NULL) {  // §  Q111: misterious code written by Vasko
        if (match_names(key, temp_names) == 0) {
            prev = temp; 
            temp = prev->next;
            strcpy(temp_names, temp->names);
        } 
        else {
            (*count) += temp->count;

            // for debugging
            //printf("count = %d\n", *count);

            prev->next = temp->next;
            free(temp);
            temp = prev->next;
            strcpy(temp_names, temp->names);
        }
    

    
    } 
  
    // If key was not present in linked list 
    //if (temp == NULL) return; 
  
    // Unlink the node from linked list 
    //prev->next = temp->next; 
    
    //free(temp);  // Free memory 
} 

// Compar function for qsort
int compar (const void *a, const void *b) {
   double l =  ((proteins *)a)->id;
   double r =  ((proteins *)b)->id;
   return (l - r);
}

// This is the recursive function (see R script for details
void process_prot_groups(protein_groups *prot_groups, proteins *Proteins, int start, int prot_count) {

     /* for debugging
     protein_groups temp_t = *prot_groups;
     for (int i = 0; i < 10; i++) {
         printf("protein groups are %s\n", temp_t->names);
         temp_t = temp_t->next;
     }*/

    if ((*prot_groups)->next == NULL) return; // to break recurrence need to test the next!

    int spec_count = 0; // this is wrong as it doubles the count for first element (*prot_groups)->count;
    
    int prot = 0;
    int tmp_prot = 0;
    double score = 0;
    double tmp_score = 0;
    char names[2048];
    strcpy(names, (*prot_groups)->names);

    // Split names
    char delim[] = ",";
    
    // for debugging
    //printf("protein groups is %s\n", names);    
    //printf("count is %d\n", (*prot_groups)->count);
    
    char *ptr = strtok(names, delim);
    while (ptr != NULL) {
        tmp_prot = atoi(ptr);        
        
        // for debugging
        //printf("Searching for %d\n", tmp_prot);

        // now search the protein and copy its score to score
        tmp_score = get_score(tmp_prot, Proteins, prot_count); // to be implemented tomorrow 1st of Sept 2020

        if (score < tmp_score) {
            score = tmp_score;
            prot = tmp_prot;
        }
        ptr = strtok(NULL, delim);
    }
    int contam = (*prot_groups)->contam;
    int decoy = (*prot_groups)->decoy;
    // Now search the linked list prot_groups with the prot id and delete all nodes that match summing their counts
    deleteNode(prot_groups, prot, &spec_count);

    // Write first protein to protein_counts file
    fprintf(protein_counts, "%d\t%d\t%d\t%d\t%lf\n", prot, spec_count, contam, decoy, score);
        
    // Recur with protein_groups[1]
    return process_prot_groups(prot_groups, Proteins, start, prot_count);    

    //return;
}

// computes pep
int compute_PEP(sqlite3 *db, char *cond) {

    char sql_inst[4096];

    // compute means and sd for forward sequences
    double m_s_f, m_l_f, sd_s_f, sd_l_f, cov_f, cov_r;
    sprintf(sql_inst, "select avg(Score_1), avg(length(Sequence)), \
                    sqrt(AVG((Score_1 - 50)*(Score_1 - 50)) - AVG(Score_1 - 50)*AVG(Score_1 - 50)), \
                    sqrt(AVG((length(Sequence) - 12)*(length(Sequence) - 12)) - AVG(length(Sequence) - 12)*AVG(length(Sequence) - 12)), \
                    AVG((Score_1 - 50)*(length(Sequence) - 12)) - AVG(Score_1 - 50)*AVG(length(Sequence) - 12) \
                    from reference.merged_aggregated where Decoy = 0 and %s;", cond);

    // debug
    //printf("%s\n", sql_inst);
    sqlite3_stmt *ppStmt;
    int rc;

    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    while ((rc = sqlite3_step(ppStmt)) != 101) {
        if (rc == 100) {
            m_s_f = sqlite3_column_double(ppStmt, 0);
            m_l_f = sqlite3_column_double(ppStmt, 1);
            sd_s_f = sqlite3_column_double(ppStmt, 2);
            sd_l_f = sqlite3_column_double(ppStmt, 3);
            cov_f = sqlite3_column_double(ppStmt, 4);
        }
    }
    sqlite3_finalize(ppStmt);

   // compute means and sd for reverse sequences
    double m_s_r, m_l_r, sd_s_r, sd_l_r;
    sprintf(sql_inst, "select avg(Score_1), avg(length(Sequence)), \
                    sqrt(AVG((Score_1 - 50)*(Score_1 - 50)) - AVG(Score_1 - 50)*AVG(Score_1 - 50)), \
                    sqrt(AVG((length(Sequence) - 12)*(length(Sequence) - 12)) - AVG(length(Sequence) - 12)*AVG(length(Sequence) - 12)), \
                    AVG((Score_1 - 50)*(length(Sequence) - 12)) - AVG(Score_1 - 50)*AVG(length(Sequence) - 12)\
                    from reference.merged_aggregated where Decoy = 1 and %s;", cond);
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    while ((rc = sqlite3_step(ppStmt)) != 101) {
        if (rc == 100) {
            m_s_r = sqlite3_column_double(ppStmt, 0);
            m_l_r = sqlite3_column_double(ppStmt, 1);
            sd_s_r = sqlite3_column_double(ppStmt, 2);
            sd_l_r = sqlite3_column_double(ppStmt, 3);
            cov_r = sqlite3_column_double(ppStmt, 4);
        }

    }
    sqlite3_finalize(ppStmt);
    double rho_f = cov_f/(sd_s_f*sd_l_f);
    double rho_r = cov_r/(sd_s_r*sd_l_r);

    // need to test if rho is nan
    if (isnan(rho_r)) rho_r = 0;
    if (isnan(rho_f)) rho_f = 0;

    sprintf(sql_inst, "UPDATE aggregated SET PEP = (exp(-(power(Score_1 - %lf, 2)/(2*power(%lf, 2)*(1 - %lf*%lf)) - (2*%lf*(Score_1 - %lf)*(length(Sequence) - %lf)/(2*%lf*%lf*(1 - %lf*%lf))) + power(length(Sequence) - %lf, 2)/(2*power(%lf, 2)*(1 - %lf*%lf))))/(2*%lf*%lf*(sqrt(1 - %lf*%lf)))) / \
                    ((exp(-(power(Score_1 - %lf, 2)/(2*power(%lf, 2)*(1 - %lf*%lf)) - (2*%lf*(Score_1 - %lf)*(length(Sequence) - %lf)/(2*%lf*%lf*(1 - %lf*%lf))) + power(length(Sequence) - %lf, 2)/(2*power(%lf, 2)*(1 - %lf*%lf))))/(2*%lf*%lf*(sqrt(1 - %lf*%lf)))) + (exp(-(power(Score_1 - %lf, 2)/(2*power(%lf, 2)*(1 - %lf*%lf)) - (2*%lf*(Score_1 - %lf)*(length(Sequence) - %lf)/(2*%lf*%lf*(1 - %lf*%lf))) + power(length(Sequence) - %lf, 2)/(2*power(%lf, 2)*(1 - %lf*%lf))))/(2*%lf*%lf*(sqrt(1 - %lf*%lf))))) where %s;",
                    m_s_r, sd_s_r, rho_r, rho_r, rho_r, m_s_r, m_l_r, sd_s_r, sd_l_r, rho_r, rho_r, m_l_r,
                    sd_l_r, rho_r, rho_r, sd_s_r, sd_l_r, rho_r, rho_r,
                    m_s_r, sd_s_r, rho_r, rho_r, rho_r, m_s_r, m_l_r, sd_s_r, sd_l_r, rho_r, rho_r, m_l_r,
                    sd_l_r, rho_r, rho_r, sd_s_r, sd_l_r, rho_r, rho_r,
                    m_s_f, sd_s_f, rho_f, rho_f, rho_f, m_s_f, m_l_f, sd_s_f, sd_l_f, rho_f, rho_f, m_l_f,
                    sd_l_f, rho_f, rho_f, sd_s_f, sd_l_f, rho_f, rho_f, cond);

    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    if (rc) {
        printf("Prepare code is %d\n", rc);
        printf("Prepared instruction is %s\n", sql_inst);
        exit(1);
    }
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);
    return rc;
}


int main(int argc, char **argv) {
    
    /*  Receives name of database, which is the datafile name as argument
        then reads protein_groups table and populates linked list
        then reads proteins table into an array
        then sorts the array
        then searches the linked list and generates protein_counts table
    */ 
    
    // get the dir name (don't forget to free)
    char *dirName = dirname(argv[1]);
    /*FILE *cnfg;
    // open config file for reading
    if ((cnfg = fopen(argv[2], "r")) == NULL) {
        printf("Error openning config file!\n");
        exit(1);
    }*/

    /* Create ptm array and populate it from config file.
    PTM *ptm = malloc(sizeof(*ptm));
    if (!ptm) {
        printf("Error allocating memory for ptm array!\n");
        exit(1);
    }*/

    //char *token;
    //char str[2048];
    int i = numMod;

    // Read modifications into ptm array from cnfg file.
    /*while (fgets(str, sizeof(str), cnfg) != NULL) {

        // Change code to read from new type config file
        if (strstr(str, "_varMod")) {
            PTM *tmp = realloc(ptm, (1 + i)*sizeof(PTM));
            if (!tmp) {
                printf("Error reallocating memory for ptm array!\n");
                free(ptm);
                exit(1);
            }
            ptm = tmp;

            sscanf(str, "_varMod\t%s\t%lf\t%s", ptm[i].name, &ptm[i].delta_mass, ptm[i].site);
            i++;
        }
    }*/


    // variables for linked list
    char names[2048];
    int decoy;
    int contam;
    int count;
    int id;
    double score;
    int prot_count;
    protein_groups prot_groups = NULL;

    // create database and various tables
    char sql_inst[4096];
    char databaseName[2048] = {}; // very important to initialize like this. Otherwise garbage in the name breaks the program
    strcat(databaseName, argv[1]);
    strcat(databaseName, ".db");
    
    /*
    sprintf(sql_inst, "sqlite3 %s 'CREATE TABLE IF NOT EXISTS scans(Total INTEGER, Matched INTEGER, \"Phospho probs\" NUMERIC,\
        \"M_Ox probs\" NUMERIC,\
        \"acetyl_N probs\" NUMERIC,\
        Scan INTEGER,\
        PrecScan INTEGER,\
        RetTime NUMERIC,\
        Sequence TEXT,\
        Charge INTEGER,\
        PrecMass NUMERIC,\
        Score NUMERIC,\
        Proteins TEXT,\
        Phospho INTEGER,\
        M_Ox INTEGER,\
        acetyl_N INTEGER,\
        Missed INTEGER,\
        Decoy INTEGER,\
        Contam INTEGER\
        );' '.exit'", databaseName);
    */
    //system(sql_inst); no longer needed

    /*
      Update 12.07.2021: need to modify the statement to account for any modifications. This is very important.
      Do I need the previous: if I import the file, it should automatically create the columns.
    */
    
    //printf("Created table scans.\n");

    // update 10.09.2021: will replace dot commands as in toSQL.c
    sprintf(sql_inst, "CREATE TABLE IF NOT EXISTS scans(Total INTEGER, Matched INTEGER");
    char str3[2048];
    int j = 0;
    while (j < i) {
        sprintf(str3, ", mod%d_probs TEXT", j);
        strcat(sql_inst, str3);
        j++;
    }    
    strcat(sql_inst, ", Fragments TEXT, Masses TEXT, Scan INTEGER, PrecScan INTEGER, RetTime NUMERIC, Sequence TEXT, Charge INTEGER, PrecMass NUMERIC, Score NUMERIC, Proteins TEXT");
    j = 0;
    while (j < i) {
        sprintf(str3, ", mod%d TEXT", j);
        strcat(sql_inst, str3);
        j++;
    } 
     strcat(sql_inst, ", nMod INTEGER, Missed INTEGER, Decoy INTEGER, Contam INTEGER, Seq_count INTEGER, score_threshold NUMERIC);");

    // for debugging
    printf("%s\n", sql_inst);

    //sprintf(sql_inst, "sqlite3 %s '.separator \"\\t\"' '.import %s scans' '.exit'", databaseName, argv[1]);
    //system(sql_inst);

    // Open sqlite database
    sqlite3 *db;
    sqlite3_stmt *ppStmt;
    int rc;
    rc = sqlite3_open(databaseName, &db);
    if(rc){
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return(1);
    }

    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);
    FILE *d_fl;
    // open data file for reading
    if ((d_fl = fopen(argv[1], "r")) == NULL) {
        printf("Error opening data file!\n");
        exit(1);
    }
    
    strcpy(sql_inst, "insert into scans values(?, ?");
    j = 0;
    while (j < i) {
        strcat(sql_inst, ", ?");
        j++;
    }
    strcat(sql_inst,", ?, ?, ?, ?, ?, ?, ?, ?, ?, ?");
    j = 0;
    while (j < i) {
        strcat(sql_inst, ", ?");
        j++;
    }
    strcat(sql_inst, ", ?, ?, ?, ?, ?, ?)");
    // for debugging
    printf("%s\n", sql_inst);
    
    if (sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, NULL)) {
        printf("Error executing sql statement\n");
        sqlite3_close(db);
        exit(-1);
    } 

    char tokens[16 + 2*i][2048];
    char data_str[4096];
    sqlite3_exec(db, "BEGIN TRANSACTION", NULL, NULL, NULL);
    while (fgets(data_str, sizeof(data_str), d_fl) != NULL) {
        char *token = strtok(data_str, "\t");
        int t = 0;
        while (token != NULL) {
            strcpy(tokens[t++], token);
            token = strtok(NULL, "\t");
        }
        sqlite3_bind_int(ppStmt, 1, atoi(tokens[0]));
        sqlite3_bind_int(ppStmt, 2, atoi(tokens[1]));
        for (int w = 0; w < i; w++) {
            sqlite3_bind_text(ppStmt, 3 + w, tokens[2 + w], -1, NULL);
        }
        sqlite3_bind_text(ppStmt, 3 + i, tokens[2 + i], -1, NULL);
        sqlite3_bind_text(ppStmt, 4 + i, tokens[3 + i], -1, NULL);
        sqlite3_bind_int(ppStmt, 5 + i, atoi(tokens[4 + i]));
        sqlite3_bind_int(ppStmt, 6 + i, atoi(tokens[5 + i]));
        sqlite3_bind_double(ppStmt, 7 + i, atof(tokens[6 + i]));
        sqlite3_bind_text(ppStmt, 8 + i, tokens[7 + i], -1, NULL);
        sqlite3_bind_int(ppStmt, 9 + i, atoi(tokens[8 + i])); 
        sqlite3_bind_double(ppStmt, 10 + i, atof(tokens[9 + i]));
        sqlite3_bind_double(ppStmt, 11 + i, atof(tokens[10 + i]));
        sqlite3_bind_text(ppStmt, 12 + i, tokens[11 + i], -1, NULL);
        for (int w = 0; w < i; w++) {
            sqlite3_bind_text(ppStmt, 13 + i + w, tokens[12 + i + w], -1, NULL);
        }
        sqlite3_bind_int(ppStmt, 13 + i + i, atoi(tokens[12 + i + i])); 
        sqlite3_bind_int(ppStmt, 14 + i + i, atoi(tokens[13 + i + i]));
        sqlite3_bind_int(ppStmt, 15 + i + i, atoi(tokens[14 + i + i]));       
        sqlite3_bind_int(ppStmt, 16 + i + i, atoi(tokens[15 + i + i]));
        sqlite3_bind_int(ppStmt, 17 + i + i, atoi(tokens[16 + i + i]));
        sqlite3_bind_double(ppStmt, 18 + i + i, atof(tokens[17 + i + i]));

        sqlite3_step(ppStmt);
        sqlite3_reset(ppStmt);
    }
    sqlite3_finalize(ppStmt);
    sqlite3_exec(db, "COMMIT TRANSACTION", NULL, NULL, NULL);

    sqlite3_exec(db, "delete from scans where rowid = 1", NULL, NULL, NULL); 

   // need to read the config file and populate an array of ptm names
    printf("Imported %s into scans.\n", argv[1]);

    
    // update 01.09.2021: need to modify to not rely on external sql file
    
    //sprintf(sql_inst, "sqlite3 %s < sql_statement.sql", databaseName);
    //system(sql_inst);


    // put replacement for sql_statement.sql here
    sprintf(sql_inst, "ALTER TABLE scans ADD Score_1 NUMERIC;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    // for debugging
    printf("Altered table scans.\n");    

    //sprintf(sql_inst, "UPDATE scans SET new_score = (Score/(1 + (nMod + Missed)/7.5)); -- + PrecMass*0.012;");
    sprintf(sql_inst, "UPDATE scans SET Score_1 = Score;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    // for debugging
    printf("Updated table scans with Score_1.\n");

    sprintf(sql_inst, "CREATE TABLE IF NOT EXISTS aggregated AS SELECT *, rowid AS row_id from scans GROUP BY Scan HAVING Score_1 = max(Score_1);");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    // for debugging
    printf("Created table aggregated.\n");

    sprintf(sql_inst, "create table aggregated_2nd AS SELECT *, rowid AS row_id from scans WHERE scans.rowid NOT IN (select row_id from aggregated) GROUP BY Scan HAVING Score_1 = max(Score_1);"); 
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    // for debugging
    printf("Created table aggregated_2nd.\n");

    sprintf(sql_inst, "ALTER TABLE aggregated ADD next_max_score NUMERIC;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    // for debugging
    printf("Altered aggregated adding next_max_score.\n");
    
    sprintf(sql_inst, "create index scan on aggregated(Scan, Score_1);");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    sprintf(sql_inst, "create index scan_2nd on aggregated_2nd(Scan, Score_1);");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    sprintf(sql_inst, "UPDATE aggregated SET next_max_score = (select Score_1 from aggregated_2nd where Scan = aggregated.Scan);");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    sprintf(sql_inst, "UPDATE aggregated SET next_max_score = CASE WHEN next_max_score IS NOT NULL THEN next_max_score ELSE 0 END;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    // for debugging
    printf("Updated aggregated setting next_max_score.\n");

    sprintf(sql_inst, "ALTER TABLE aggregated ADD score_diff NUMERIC;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    sprintf(sql_inst, "UPDATE aggregated SET score_diff = Score_1 - next_max_score;"); 
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    sqlite3_exec(db, "delete from aggregated WHERE (Score < score_threshold)", NULL, NULL, NULL);

    // now will attach the reference db to get statistics for Gassienn kernel
    sprintf(sql_inst, "attach database 'merged_db.db' as reference;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    sprintf(sql_inst, "ALTER TABLE aggregated ADD PEP NUMERIC;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);
    int rc1 = 0;
    // compute PEP for charge = 2
    rc1 = compute_PEP(db, "nMod = 0 and Missed = 0 and Charge = 2");
    rc1 = compute_PEP(db, "nMod = 0 and Missed = 1 and Charge = 2");
    rc1 = compute_PEP(db, "nMod = 0 and Missed > 1 and Charge = 2");

    rc1 = compute_PEP(db, "nMod = 1 and Missed = 0 and Charge = 2");
    rc1 = compute_PEP(db, "nMod = 1 and Missed = 1 and Charge = 2");
    rc1 = compute_PEP(db, "nMod = 1 and Missed > 1 and Charge = 2");

    rc1 = compute_PEP(db, "nMod = 2 and Missed = 0 and Charge = 2");
    rc1 = compute_PEP(db, "nMod = 2 and Missed = 1 and Charge = 2");
    rc1 = compute_PEP(db, "nMod = 2 and Missed > 1 and Charge = 2");

    rc1 = compute_PEP(db, "nMod > 2 and Missed = 0 and Charge = 2");
    rc1 = compute_PEP(db, "nMod > 2 and Missed = 1 and Charge = 2");
    rc1 = compute_PEP(db, "nMod > 2 and Missed > 1 and Charge = 2");

    // now charge > 2
    rc1 = compute_PEP(db, "nMod = 0 and Missed = 0 and Charge != 2");
    rc1 = compute_PEP(db, "nMod = 0 and Missed = 1 and Charge != 2");
    rc1 = compute_PEP(db, "nMod = 0 and Missed > 1 and Charge != 2");

    rc1 = compute_PEP(db, "nMod = 1 and Missed = 0 and Charge != 2");
    rc1 = compute_PEP(db, "nMod = 1 and Missed = 1 and Charge != 2");
    rc1 = compute_PEP(db, "nMod = 1 and Missed > 1 and Charge != 2");

    rc1 = compute_PEP(db, "nMod = 2 and Missed = 0 and Charge != 2");
    rc1 = compute_PEP(db, "nMod = 2 and Missed = 1 and Charge != 2");
    rc1 = compute_PEP(db, "nMod = 2 and Missed > 1 and Charge != 2");

    rc1 = compute_PEP(db, "nMod > 2 and Missed = 0 and Charge != 2");
    rc1 = compute_PEP(db, "nMod > 2 and Missed = 1 and Charge != 2");
    rc1 = compute_PEP(db, "nMod > 2 and Missed > 1 and Charge != 2");

    sprintf(sql_inst, "CREATE TABLE IF NOT EXISTS sig AS SELECT *, sum(Decoy) OVER (ORDER BY PEP ASC) sumDecoy FROM aggregated;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    if(rc){
        fprintf(stderr, "Can't prepare statement to create table sig: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return(1);
    }
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    sprintf(sql_inst, "CREATE TABLE IF NOT EXISTS sig1 AS SELECT *, row_number() OVER (ORDER BY PEP ASC) rowNumb FROM sig;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    if(rc){
        fprintf(stderr, "Can't prepare statement to create table sig1: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return(1);
    }
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    sprintf(sql_inst, "CREATE TABLE IF NOT EXISTS sig_scans AS SELECT * FROM sig1 WHERE sumDecoy <= 0.01*(rowNumb - sumDecoy);");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    if(rc){
        fprintf(stderr, "Can't prepare statement to create table sig_scans: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return(1);
    }
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    sprintf(sql_inst, "DROP TABLE sig;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    sprintf(sql_inst, "DROP TABLE sig1;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    sprintf(sql_inst, "CREATE TABLE IF NOT EXISTS protein_groups AS SELECT Proteins, count(*) AS Count, Contam, Decoy FROM sig_scans GROUP BY Proteins ORDER BY Count ASC;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    sprintf(sql_inst, "CREATE TABLE IF NOT EXISTS peptides AS SELECT Sequence, Score, Proteins, Contam, Decoy FROM sig_scans GROUP BY Sequence HAVING Score = MAX(Score);");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    sprintf(sql_inst, "ALTER TABLE peptides ADD n_prot INTEGER;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    sprintf(sql_inst, "UPDATE peptides SET n_prot = (WITH split(word, str) AS (SELECT '', Proteins || ',' UNION ALL SELECT substr(str, 0, instr(str, ',')), substr(str, instr(str, ',')+1) FROM split WHERE str!='') SELECT count(*) FROM split WHERE word!='');");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    // for debugging
    printf("Updated peptides setting n_prot.\n");

    sprintf(sql_inst, "CREATE TABLE IF NOT EXISTS unnested AS WITH RECURSIVE unnest(Sequence, Protein, etc, Score, Contam, Decoy, n_prot) AS (SELECT Sequence, '', Proteins || ',', Score, Contam, Decoy, n_prot FROM peptides WHERE Sequence <> '' UNION ALL SELECT Sequence, SUBSTR(etc, 0, INSTR(etc, ',')), SUBSTR(etc, INSTR(etc, ',')+1), Score, Contam, Decoy, n_prot FROM unnest WHERE etc <> '') SELECT Sequence, Protein, Score, Contam, Decoy, n_prot FROM unnest WHERE Protein <> '' ORDER BY Sequence ASC, Protein ASC;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    // for debugging
    printf("Created unnested.\n");

    sprintf(sql_inst, "CREATE TABLE IF NOT EXISTS proteins AS SELECT Protein, max(Contam) AS Contam, max(Decoy) AS Decoy, sum(Score/n_prot) AS protScore FROM unnested GROUP BY Protein;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);
 
    // for debugging
    printf("Created proteins.\n");

    // end of replacement

    sprintf(sql_inst, "select * from protein_groups;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    while ((rc = sqlite3_step(ppStmt)) != 101) {
        if (rc == 100) {
            strcpy(names, (char *)sqlite3_column_text(ppStmt, 0));
            
            // for debugging
            //printf("%s\n", names);  

            count = sqlite3_column_int(ppStmt, 1);
            contam = sqlite3_column_int(ppStmt, 2);
            decoy = sqlite3_column_int(ppStmt, 3);
            push(&prot_groups, count, contam, decoy, names);            
        }
    }
    sqlite3_finalize(ppStmt);

    // Get proteins count
    sprintf(sql_inst, "select count(*) from proteins;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    while ((rc = sqlite3_step(ppStmt)) != 101) {
        if (rc == 100) {
            prot_count = sqlite3_column_int(ppStmt, 0);
        }
    }
    sqlite3_finalize(ppStmt);
    
    //proteins Proteins[prot_count]; // this is blowing the stack so will replace it with dynamic allocation
    proteins *Proteins = (proteins *)calloc(prot_count, sizeof(proteins));
    if (Proteins == NULL) {
        printf("Cannot allocate Proteins array\n");
        exit(1);
    }
    // populate Proteins array
    sprintf(sql_inst, "select * from proteins;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);

    int prot_cnt = 0;
    char pr_str[1024];
    while ((rc = sqlite3_step(ppStmt)) != 101) {
        if (rc == 100) {
            strcpy(pr_str, (char *)sqlite3_column_text(ppStmt, 0));
            id = atoi(pr_str);
            contam = sqlite3_column_int(ppStmt, 1);
            decoy = sqlite3_column_int(ppStmt, 2);
            score = sqlite3_column_double(ppStmt, 3);
            Proteins[prot_cnt].id = id;
            Proteins[prot_cnt].contam = contam;
            Proteins[prot_cnt].decoy = decoy;
            Proteins[prot_cnt].score = score;
            prot_cnt++;
        }
    }
    sqlite3_finalize(ppStmt);    
    
    // Sort Proteins array by id
    qsort(Proteins, prot_cnt, sizeof(proteins), compar);

    // for debugging
    //for (int i = 0; i < prot_cnt; i++) printf("%d\n", Proteins[i].id);
    //return 0; 

    // Open results file for writing.
    char resFile[256] = {};
    strcat(resFile, argv[1]);
    strcat(resFile, ".protein_counts.txt");    
    if ((protein_counts = fopen(resFile, "w")) == NULL) {
        printf("Error opening results file for writing.\n");
        exit(1);
    }

    //fprintf(protein_counts, "Proteins\tCount\tContam\tDecoy\tScore\tGene\tFasta header\n");
    
    /* for debugging
    protein_groups temp_t = prot_groups;
    for (int i = 0; i < 10; i++) {
        printf("protein groups are %s\n", temp_t->names);
        temp_t = temp_t->next;
    }*/
     
    // Now go through the prot_groups list. Split names and search in loop as in the R script
    process_prot_groups(&prot_groups, Proteins, 0, prot_count);
    fclose(protein_counts);
    free(Proteins);
    free(prot_groups);
 
    /* for debugging
    //char test1[1600];
    sqlite3_close(db);
    return 0;
    */ 

    // Will do this later
    // now import protein_counts in db, add Gene and Description columns and export to csv file
    // create the table
    sprintf(sql_inst, "create table if not exists protein_counts(Proteins int, Count int, Contam int, Decoy int, Score double);");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    /*for debugging
    //char test1[1600];
    sqlite3_close(db);
    return 0;
    */
    
    // import file need to use system commands as . commands are not part of sqlite3 C API
    /*
    sprintf(sql_inst,  ".separator \t");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    rc = sqlite3_reset(ppStmt);
    sprintf(sql_inst,  ".import ./test_results.db.protein_counts.txt protein_counts");
    rc = sqlite3_step(ppStmt);
    rc = sqlite3_reset(ppStmt);
    */

    // update 10.09.2021: will replace the dot command
    //sprintf(sql_inst, "sqlite3 %s '.separator \"\\t\"' '.import %s protein_counts' '.exit'", databaseName, resFile);
    //system(sql_inst);
    if (sqlite3_prepare_v2(db, "insert into protein_counts values(?, ?, ?, ?, ?)", -1, &ppStmt, NULL)) {
        printf("Error executing sql statement\n");
        sqlite3_close(db);
        exit(-1);
    }
    //char tokens[15][1000];
    sqlite3_exec(db, "BEGIN TRANSACTION", NULL, NULL, NULL);

    //char data_str[2048];
    if ((protein_counts = fopen(resFile, "r")) == NULL) {
        printf("Error opening results file for reading.\n");
        exit(1);
    }

    while (fgets(data_str, sizeof(data_str), protein_counts) != NULL) {
        char *token = strtok(data_str, "\t");
        //prot_id = atoi(token);
        int i = 0;
        while (token != NULL) {
            //printf("%s\n", token);
            strcpy(tokens[i++], token);
            token = strtok(NULL, "\t");
        }

        sqlite3_bind_int(ppStmt, 1, atoi(tokens[0]));
        sqlite3_bind_int(ppStmt, 2, atoi(tokens[1]));
        sqlite3_bind_int(ppStmt, 3, atoi(tokens[2]));
        sqlite3_bind_int(ppStmt, 4, atoi(tokens[3]));
        sqlite3_bind_double(ppStmt, 5, atoi(tokens[4]));
        sqlite3_step(ppStmt);
        sqlite3_reset(ppStmt);
    }

    sqlite3_finalize(ppStmt);
    sqlite3_exec(db, "COMMIT TRANSACTION", NULL, NULL, NULL);

    //char str_stm[1024];
    //sprintf(str_stm, "sqlite3 %s '.separator \"\\t\"' '.import ./test_results.db.protein_counts.txt protein_counts' '.exit'", argv[1]);
    //system(str_stm);
    
    // create Gene and description columns
    sprintf(sql_inst,  "alter table protein_counts add Gene text;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    /*for debugging
    //char test1[1600];
    sqlite3_close(db);
    return 0;
    */

    sprintf(sql_inst,  "alter table protein_counts add Description text;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    // attach main database
    sprintf(sql_inst,  "attach '%s/sequences.db' as testDB;", dirName);
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    // update Gene and Description columns
    sprintf(sql_inst, "update protein_counts set Gene = (select gene from testDB.proteins where Proteins = testDB.proteins.prot_id);");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt); 
     
    sprintf(sql_inst, "update protein_counts set Description = (select header from testDB.proteins where Proteins = testDB.proteins.prot_id);");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    // Update 05.08.2021: implementing fdr filter for proteins
    sprintf(sql_inst, "CREATE TABLE IF NOT EXISTS sig AS SELECT *, sum(Decoy) OVER (ORDER BY score DESC) sumDecoy FROM protein_counts;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    sprintf(sql_inst, "CREATE TABLE IF NOT EXISTS sig1 AS SELECT *, row_number() OVER (ORDER BY score DESC) rowNumb FROM sig;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    sprintf(sql_inst, "CREATE TABLE IF NOT EXISTS sig_proteins AS SELECT * FROM sig1 WHERE sumDecoy <= 0.01*(rowNumb - sumDecoy);");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    sprintf(sql_inst, "DROP TABLE sig;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);
    sprintf(sql_inst, "DROP TABLE sig1;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    // write to tsv
    sprintf(sql_inst, "select * from sig_proteins;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    
    FILE *res;
    char res_txt[1024];
    strcpy(res_txt, argv[1]);
    strcat(res_txt, ".sig_prot_counts.txt");
    if ((res = fopen(res_txt, "w")) == NULL) {
        printf("Error opening results file for writing.\n");
        exit(1);
    }
    fprintf(res, "Proteins\tCounts\tContam\tDecoy\tScore\tGene\tDescription\n");

    while ((rc = sqlite3_step(ppStmt)) != 101) {
        if (rc == 100) {
            fprintf(res, "%d\t%d\t%d\t%d\t%lf\t%s\t%s\n", sqlite3_column_int(ppStmt, 0), sqlite3_column_int(ppStmt, 1), sqlite3_column_int(ppStmt, 2), sqlite3_column_int(ppStmt, 3), sqlite3_column_double(ppStmt, 4), sqlite3_column_text(ppStmt, 5), sqlite3_column_text(ppStmt, 6));
        }
        else {
            printf("Error executing sql statement: %d.\n", rc);
            exit(1);
        }
    }

    


    //sprintf(sql_inst, "sqlite3 %s '.header on' '.mode csv' '.output %s.protein_counts.csv' 'select * from sig_proteins;' '.exit'", databaseName, argv[1]);
    //system(sql_inst);
    /*
    sprintf(sql_inst, ".header on");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    rc = sqlite3_reset(ppStmt);

    sprintf(sql_inst, ".mode csv");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    rc = sqlite3_reset(ppStmt);

    sprintf(sql_inst, ".output protein_counts.csv");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    rc = sqlite3_reset(ppStmt);

    sprintf(sql_inst, "select * from protein_counts;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    rc = sqlite3_reset(ppStmt);
    */

    //sprintf(str_stm, "sqlite3 %s '.separator \"\\t\"' '.import ./test_results.db.protein_counts.txt protein_counts' '.exit'", argv[1]);
    //system(str_stm);
    //sprintf(str_stm, "sqlite3 %s '.header on' '.mode csv' '.output protein_counts.csv' 'select * from protein_counts;' '.exit'", argv[1]);
    //system(str_stm);
   
    sqlite3_finalize(ppStmt);
    sqlite3_close(db);     
    //free(dirName);

    //char test1[1600]; // larger than this and it gives fragfault. something is weird with the stack
    //sprintf(test1, "sqlite3 %s '.separator \"\\t\"' '.import ./test_results.db.protein_counts.txt protein_counts' '.exit'", argv[1]);


    //free(ptm);
    //fclose(cnfg);
    fclose(protein_counts);
    fclose(d_fl);
    fclose(res);
    return 0;

}   

