/*
*  Wrapper program for the MGVB suite
*  Metodi V. Metodiev
*  University of Essex, UK
*  July 2021
*
*  Usage: ./mgvb_new config.rms
*  It does the following:
*
*  1. Reads config.rms and parses various parameter values
*  2. Consolidates all protein_counts tables into a single table. Possibly
*     consolidates peptides and sig_scan tables to produce msms.txt and 
*     peptides.txt
*
*  Update 17.03.2022: it is too slow. Will make indexes to speedup joins
*/ 

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "sqlite3.h"

typedef struct {
    char name[2048];
    char experiment[2048];
} RawFile;	

int main (int argc, char **argv) {

    FILE *cnfg;
    FILE *res;
    char res_txt[1024];
    char str[2048];
    char sql_inst[8192];

    RawFile *raw_files = malloc(sizeof(RawFile));
    if (!raw_files) {
        printf("Error allocating memory for raw files array!\n");
        exit(1);
    }
    
    if ((cnfg = fopen(argv[1], "r")) == NULL) {
        printf("Error openning config file!\n");
        exit(1);
    } 

    int i = 0;
    while (fgets(str, sizeof(str), cnfg) != NULL) {

        // Change code to read from new type config file
        if (strstr(str, "_rawFile")) {
            RawFile *tmp = realloc(raw_files, (1 + i)*sizeof(RawFile));
            if (!tmp) {
                printf("Error reallocating memory for raw files array!\n");
                free(raw_files);
                exit(1);
            }
            raw_files = tmp;

            sscanf(str, "_rawFile\t%s\t%s", raw_files[i].name, raw_files[i].experiment);

            i++;
        }
    }

    // Now import protein counts files to sqlite db, consolidate and export a single protein_groups file

    // Open sqlite database
    sqlite3 *db;
    sqlite3_stmt *ppStmt;
    int rc;
    char tokens[7][2048];
    char data_str[4096];

    rc = sqlite3_open("results.db", &db);
    if(rc){
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        exit(1);
    }
    FILE *d_fl;
    for (int j = 0; j < i; j++) {
        // open results file for reading
	if ((d_fl = fopen(strcat(raw_files[j].name, ".ms2.mms.txt.sig_prot_counts.txt"), "r")) == NULL) {
            printf("Error opening data file!\n");
            exit(1);
        }
        sprintf(sql_inst, "CREATE TABLE IF NOT EXISTS %s(Proteins INTEGER, Counts INTEGER, Contam INTEGER, Decoy INTEGER, Score NUMERIC, Gene TEXT, Description TEXT)",raw_files[j].experiment);
	rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
        if(rc){
            fprintf(stderr, "Can't prepare sqlite statement: %s\n", sqlite3_errmsg(db));
            sqlite3_close(db);
            exit(1);
        }
	rc = sqlite3_step(ppStmt);
        sqlite3_finalize(ppStmt);
	sprintf(sql_inst, "insert into %s values(?, ?, ?, ?, ?, ?, ?)", raw_files[j].experiment);
	if (sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, NULL)) {
            printf("Error preparing sql statement\n");
            sqlite3_close(db);
            exit(-1);
        }
        sqlite3_exec(db, "BEGIN TRANSACTION", NULL, NULL, NULL);
	while (fgets(data_str, sizeof(data_str), d_fl) != NULL) {
            int t = 0;
	    char *token = strtok(data_str, "\t");
	    while (token != NULL) {
                strcpy(tokens[t++], token);
                token = strtok(NULL, "\t");
            }

            // need to remove \n from Description
	    tokens[6][strlen(tokens[6]) - 1] = 0;

    	    sqlite3_bind_int(ppStmt, 1, atoi(tokens[0]));
	    sqlite3_bind_int(ppStmt, 2, atoi(tokens[1]));
            sqlite3_bind_int(ppStmt, 3, atoi(tokens[2]));
	    sqlite3_bind_int(ppStmt, 4, atoi(tokens[3]));
	    sqlite3_bind_double(ppStmt, 5, atof(tokens[4]));
	    sqlite3_bind_text(ppStmt, 6, tokens[5], -1, NULL);
	    sqlite3_bind_text(ppStmt, 7, tokens[6], -1, NULL);
	    sqlite3_step(ppStmt);
            sqlite3_reset(ppStmt);   
	}
        sqlite3_finalize(ppStmt);
        sqlite3_exec(db, "COMMIT TRANSACTION", NULL, NULL, NULL);
        sprintf(sql_inst, "delete from %s where rowid = 1", raw_files[j].experiment);
        sqlite3_exec(db, sql_inst, NULL, NULL, NULL);
        fclose(d_fl);	
    }

    // Now use left joins to consolidate results and export a single table
    printf("Preparing consolidated spectral counts data...\n");
    sprintf(sql_inst, "Create table proteins(Proteins int, Description text, Gene text, Contam int, Decoy int)");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    if(rc){
        fprintf(stderr, "Can't prepare statement for consoldated table: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        exit(1);
    }
    rc = sqlite3_step(ppStmt);
    /*if(rc){
        fprintf(stderr, "Can't step through statement for consoldated table: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return(1);
    }*/
    sqlite3_finalize(ppStmt);

    // for debugging
    //exit(1);

    // first get a table of all proteins
    for (int j = 0; j < i; j++) {
        sprintf(sql_inst, "Create table tmp as select Proteins, Description, Gene, Contam, Decoy from proteins union all select Proteins, Description, Gene, Contam, Decoy from %s", raw_files[j].experiment);

	// for debugging
	//printf("%s\n", sql_inst);

	sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
	/*if(rc){
            fprintf(stderr, "Can't prepare statement for tmp table: %s\n", sqlite3_errmsg(db));
            sqlite3_close(db);
            exit(1);
        }*/

        sqlite3_step(ppStmt);
        sqlite3_finalize(ppStmt);
	sprintf(sql_inst, "drop table proteins;");
	sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
        sqlite3_step(ppStmt);
        sqlite3_finalize(ppStmt);
	sprintf(sql_inst, "create table proteins as select * from tmp");
	sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
        sqlite3_step(ppStmt);
        sqlite3_finalize(ppStmt);
	sprintf(sql_inst, "drop table tmp;");
        sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
        sqlite3_step(ppStmt);
        sqlite3_finalize(ppStmt);
    }

    // for debugging
    //exit(1);

    // select distinct
    sprintf(sql_inst, "create table tmp as select distinct * from proteins");
    sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);
    sprintf(sql_inst, "drop table proteins");
    sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);
    
    //exit(1);

    if (i > 1) {
        for (int j = 0; j < i; j++) {
            sprintf(sql_inst, "Create table report as select * from tmp left join (select Proteins, Counts as %s from %s) using(Proteins)", raw_files[j].experiment, raw_files[j].experiment);
	    sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
            sqlite3_step(ppStmt);
            sqlite3_finalize(ppStmt);
            sprintf(sql_inst, "drop table tmp");
            sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
            sqlite3_step(ppStmt);
            sqlite3_finalize(ppStmt);
	    sprintf(sql_inst, "create table tmp as select * from report");
            sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
            sqlite3_step(ppStmt);
            sqlite3_finalize(ppStmt);
	    sprintf(sql_inst, "drop table report");
            sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
            sqlite3_step(ppStmt);
            sqlite3_finalize(ppStmt);
	}
        
        sprintf(sql_inst, "create table report as select * from tmp");
        sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
        sqlite3_step(ppStmt);
        sqlite3_finalize(ppStmt);
	sprintf(sql_inst, "drop table tmp");
        sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
        sqlite3_step(ppStmt);
        sqlite3_finalize(ppStmt);
        
        // for debugging
	//exit(1);

	// now export to file
        
        //char res_txt[1024];	
	strcpy(res_txt, "consolidated_results.txt");
	if ((res = fopen(res_txt, "w")) == NULL) {
            printf("Error opening results file for writing.\n");
            exit(1);
        }
	fprintf(res, "Proteins\tDescription\tGene\tContam\tDecoy");
	for (int j = 0; j < i; j++) fprintf(res, "\t%s", raw_files[j].experiment);
	fprintf(res, "\n");
	sprintf(sql_inst, "select * from report;");
        rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
	while ((rc = sqlite3_step(ppStmt)) != 101) {
            if (rc == 100) {
                fprintf(res, "%d\t%s\t%s\t%d\t%d", sqlite3_column_int(ppStmt, 0), sqlite3_column_text(ppStmt, 1), sqlite3_column_text(ppStmt, 2), sqlite3_column_int(ppStmt, 3), sqlite3_column_int(ppStmt, 4));
	        for (int j = 0; j < i; j++) fprintf(res, "\t%d", sqlite3_column_int(ppStmt, 5 + j));
                fprintf(res, "\n");
            }
            else {
                printf("Error executing sql statement: %d.\n", rc);
                exit(1);
            }
	}    
   
    }

    else printf("Only a single sample was analysed!\n");
    	    
    sqlite3_close(db); 
    free(raw_files);
    fclose(cnfg);
    fclose(res);
    return 0;
     
} 

