/*
 * Extracts spectra from mms file and saves them to mms file
 * Takes spectrum number as input from a list in input file
 * 
 * Author: Metodi V. Metodiev
 *
 * All rights reserved.
 * Ravna, Bulgaria, 15.08.2021


   Algorithm:

   Receives name of mms file as argv[1], name of output file as argv[2]
   and scan numenrsof spectra to be extracted as argv[3] and more.
   
   
 */



#include <stdio.h>
#include <stdlib.h>
#include "pepMass.h"

int main(int argc, char **argv) {

    FILE *mms_ptr;
    FILE *res;

    spectrum spec;

    if ((mms_ptr = fopen(argv[1], "rb")) == NULL) {
        printf("Error opening binary file for reading.\n");
        exit(1);
    }

    if ((res = fopen(argv[2], "wb")) == NULL) {
        printf("Error opening binary file for writing.\n");
        exit(1);
    }

    for (int i = 3; i < argc; i++) {
        fseek(mms_ptr, sizeof(spectrum)*(atoi(argv[i]) - 1), SEEK_SET);
        fread(&spec, sizeof(spectrum), 1, mms_ptr);
        printf("Precursor mass for scan %d is %lf\n", i, spec.precMass);
        printf("Charge is %d\n", spec.charge);
        fwrite(&spec, sizeof(spectrum), 1, res);
    }
    fclose(mms_ptr);
    fclose(res);

    return 0;
}
