#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "arraySearch2023.h"

// Test for arraySearch functions

int main(int argc, char **argv) {

    FILE *mod_pep_file;
    FILE *pep_file;

    if ((mod_pep_file = fopen(argv[1], "r")) == NULL) {
        printf("Error opening mod_pep file!");
        exit(1);
    }
    
    mod_pep *mod_pep_array = NULL;
    pep_info *pep_array = NULL;

    int n_ptm = atoi(argv[4]);
    int n_pep = count_lines(mod_pep_file);
    
    fclose(mod_pep_file);
    if ((mod_pep_file = fopen(argv[1], "r")) == NULL) {
        printf("Error opening mod_pep file!");
        exit(1);
    }

    if ((pep_file = fopen("peptides.db", "r")) == NULL) {
        printf("Error opening mod_pep file!");
        exit(1);
    }

    // proper way of allocating 2d array (from https://stackoverflow.com/questions/36890624/malloc-a-2d-array-in-ci)
    int (*mods)[n_ptm];
    mods = malloc(sizeof(int[n_pep][n_ptm])); 

    // allocate seaquences and prot_id arrays
    char **sequences = malloc(n_pep*sizeof(*sequences));
    if (!sequences) {
        printf("Cannot allocate sequences!\n");
	exit(1);
    }
    char **prot_id = malloc(n_pep*sizeof(*prot_id));
    if (!prot_id) {
        printf("Cannot allocate sequences!\n");
        exit(1);
    }

    for (int j = 0; j < n_pep; j++) {
        sequences[j] = malloc(1024*sizeof(char));
        if (!sequences[j]) {
            printf("Cannot allocate sequences element %d!\n", j);
            exit(1);
        }
	prot_id[j] = malloc(4096*sizeof(char));
        if (!prot_id[j]) {
            printf("Cannot allocate prot_id element %d!\n", j);
            exit(1);
        }
    }

    // make mod_pep and pep arrays
    int res = make_arrays(mod_pep_file, pep_file, n_ptm, n_pep, mods, &mod_pep_array, &pep_array, sequences, prot_id);
    printf("Created %d mod_pep records\n", res);

    // test 2d array allocation
    /*int (*mods1)[3];
    mods1 = malloc(sizeof(int[3068][3]));
    for (int i = 0; i < 3068; i++) {
        for (int j = 0; j < 3; j ++) {
            mods1[i][j] = 0;
	}
    }*/

    /*
    for (int i = 0; i < n_pep; i++) {
        printf("seq = %s, mass = %lf\n", mod_pep_array[i].sequence, mod_pep_array[i].mass);

    }*/
    
    double target_mass = atof(argv[2]);
    double tol = atof(argv[3]);
        
    // debug
    //exit(1);
    
    int ind =  find_min_match(mod_pep_array, 0, n_pep - 1, tol, target_mass); 
    
    // debug
    printf("ind = %d\n", ind);
    //exit(1);
    
    if (ind >= 0) {
        while (mod_pep_array[ind].mass <= target_mass + tol) {
            printf("Found sequence %s with mass %lf, ptms: %d, %d, %d\n", 
			    sequences[mod_pep_array[ind].pep_id - 1], 
			    mod_pep_array[ind].mass, mods[ind][0], 
			    mods[ind][1], mods[ind][2]);
	    ind++;
		       	
        }
    }
    // test search    
    fclose(mod_pep_file);
    fclose(pep_file);
    free(mod_pep_array);
    free(pep_array);
    free(mods);
    for (int j = 0; j < n_pep; j++) {
        free(sequences[j]);
	free(prot_id[j]);
    }    
    free(sequences);
    free(prot_id);

    return 0;
}

