#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "sqlite3.h"
#include <libgen.h>
//#include "pepMass.h"

// computes pep
int compute_PEP(sqlite3 *db, char *cond) {
    
    // debug
    printf("Conttions are %s\n", cond);
   
    char sql_inst[4096];
    sqlite3_stmt *ppStmt;
    int rc;
    
    // compute means and sd for forward sequences
    double m_s_f, m_l_f, sd_s_f, sd_l_f;;
    sprintf(sql_inst, "select avg(Score), avg(length(Sequence)), \
                   sqrt(AVG(Score*Score) - AVG(Score)*AVG(Score)), \
                   sqrt(AVG(length(Sequence)*length(Sequence)) - \
                           AVG(length(Sequence))*AVG(length(Sequence))) \
                   from aggregated where Decoy = 0 and %s;", cond);

    // debug
    printf("%s\n", sql_inst);

    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    while ((rc = sqlite3_step(ppStmt)) != 101) {
        if (rc == 100) {
            m_s_f = sqlite3_column_double(ppStmt, 0);
            m_l_f = sqlite3_column_double(ppStmt, 1);
            sd_s_f = sqlite3_column_double(ppStmt, 2);
            sd_l_f = sqlite3_column_double(ppStmt, 3);
        }
    }
    sqlite3_finalize(ppStmt);   
   
    // debug
    printf("%lf, %lf, %lf, %lf\n", m_s_f, m_l_f, sd_s_f, sd_l_f);

    // compute means and sd for reverse sequences
    double m_s_r, m_l_r, sd_s_r, sd_l_r;
    sprintf(sql_inst, "select avg(Score), avg(length(Sequence)), sqrt(AVG(Score*Score) - AVG(Score)*AVG(Score)), \
		    sqrt(AVG(length(Sequence)*length(Sequence)) - \
			    AVG(length(Sequence))*AVG(length(Sequence))) from aggregated where Decoy = 1 and %s;", cond);
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    while ((rc = sqlite3_step(ppStmt)) != 101) {
        if (rc == 100) {
            m_s_r = sqlite3_column_double(ppStmt, 0);
            m_l_r = sqlite3_column_double(ppStmt, 1);
            sd_s_r = sqlite3_column_double(ppStmt, 2);
            sd_l_r = sqlite3_column_double(ppStmt, 3);
        }
    }
    sqlite3_finalize(ppStmt);

    // debug
    printf("%lf, %lf, %lf, %lf\n", m_s_r, m_l_r, sd_s_r, sd_l_r);


    sprintf(sql_inst, "UPDATE aggregated SET PEP = 0.5*(exp(-( (power(Score - %lf, 2))/(2*power(%lf, 2))) + ((power(length(Sequence) - %lf, 2))/(2*power(%lf, 2))) )) / ((exp(-( (power(Score - %lf, 2))/(2*power(%lf, 2))) + ((power(length(Sequence) - %lf, 2))/(2*power(%lf, 2))) )) + exp(-( (power(Score - %lf, 2))/(2*power(%lf, 2))) + ((power(length(Sequence) - %lf, 2))/(2*power(%lf, 2)))) )  where %s;", m_s_r, sd_s_r, m_l_r, sd_l_r, m_s_r, sd_s_r, m_l_r, sd_l_r, m_s_f, sd_s_f, m_l_f, sd_l_f, cond);

    
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    if (rc) {
	printf("Prepare code is %d\n", rc);
	printf("Prepared instruction is %s\n", sql_inst);
	exit(1);
    }
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);
    return rc;
}

int main(int argc, char **argv) {
    

    char db_name[2048] = {}; // very important to initialize like this. Otherwise garbage in the name breaks the program
    strcat(db_name, argv[1]);
    
    //debug
    printf("Will process %s\n", db_name);

    // Open sqlite database
    sqlite3 *db;
    int rc;
    rc = sqlite3_open(db_name, &db);
    if(rc){
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return(1);
    }

    char sql_inst[4096];
    sqlite3_stmt *ppStmt;

    sprintf(sql_inst, "ALTER TABLE aggregated ADD PEP NUMERIC;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);
    rc = sqlite3_step(ppStmt);
    sqlite3_finalize(ppStmt);

    // Compute PEP and add it to the aggregated table in db
    int rc1;
    rc1 = compute_PEP(db, "nMod = 0 and Missed = 0");
    rc1 = compute_PEP(db, "nMod = 0 and Missed = 1");
    rc1 = compute_PEP(db, "nMod = 0 and Missed > 1");

    rc1 = compute_PEP(db, "nMod = 1 and Missed = 0");
    rc1 = compute_PEP(db, "nMod = 1 and Missed = 1");
    rc1 = compute_PEP(db, "nMod = 1 and Missed > 1");

    rc1 = compute_PEP(db, "nMod = 2 and Missed = 0");
    rc1 = compute_PEP(db, "nMod = 2 and Missed = 1");
    rc1 = compute_PEP(db, "nMod = 2 and Missed > 1");

    rc1 = compute_PEP(db, "nMod > 2 and Missed = 0");
    rc1 = compute_PEP(db, "nMod > 2 and Missed = 1");
    rc1 = compute_PEP(db, "nMod > 2 and Missed > 1");
    
    printf("%d\n", rc1);    

    sqlite3_close(db);
    return 0;
}

