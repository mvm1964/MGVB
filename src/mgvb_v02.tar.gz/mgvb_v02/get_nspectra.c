/*
 * Counts the numebr of spectra in a mms file
 * and outputs number of spectra
*/

#include <stdio.h>
#include <stdlib.h>
#include "pepMass.h"


int main(int arc, char **argv) {
    FILE *mms_ptr;
    spectrum spec1;
    int N_spectra = 0;

    // Read data struct by struct, search and write results to file.
    if ((mms_ptr = fopen(argv[1], "rb")) == NULL) {
        printf("Error opening binary file for reading.\n");
        exit(1);
    }

    while (fread(&spec1, sizeof(spectrum), 1, mms_ptr) == 1) {
        N_spectra++;
    } 
    printf("%d\n", N_spectra);

    fclose(mms_ptr);
    return 0;     
}
