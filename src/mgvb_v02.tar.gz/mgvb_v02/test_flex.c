#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int maxnum;
    int count;
    int array[];
} *Item;

Item grow_array(Item array) {
    int new_max = array->maxnum + 1;
    Item tmp = realloc(array, sizeof(*array) + new_max*sizeof(int)); 
    array = tmp;
    array->maxnum = new_max;
    return(array);
}

void print_array(Item array) {
    for (int i = 0; i < array->count; i++) printf("%d\n", array->array[i]);
}

int main() {
    Item item = NULL;
    item = malloc(sizeof(*item) + 2*sizeof(int));
    item->maxnum = 2;
    item->count = 0;
    item->array[0] = 1;
    item->array[1] = 2;
    item->count = 2;
    print_array(item);
    item = grow_array(item);
    item->array[2] = 3;
    item->count = 3;
    print_array(item);
    
    for (int i = 0; i < 4; i++) {
        item = grow_array(item);
	item->array[item->count] = 24;
        item->count += 1;
	printf("Printing array for i = %d\n", i);
	print_array(item);
    }
    
    free(item);
    return 0;
}
