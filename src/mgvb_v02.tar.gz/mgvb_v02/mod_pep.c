/*
  Combinations of multiset: for generating masses of modified peptides
  modified from http://www.martinbroadhurst.com/combinations-of-a-multiset.html

  Algorithm for generating the peptides (more or less done and working).:
  1. Reads from conf file and parses modification structs (to binary file if needed). Each struct has
     a name ("Phos", "Cys_Cam" etc.); a mass, and a site string.).
  2. For each peptide sequence generates all combinations of the multiset that represents the modified 
     residues: if we have GHLTVCTYMR for the modified peptide GHLpTVcamCTpYoxMR we have {0,0,1,2}. We 
     define phospho as 0, Cys_CAM as 1 and M_Ox as 2 and the combinations are given in lexicographic order.
  3. For each combinationon write a separate peptide entry in the db containing counts for each type of modi
     fication.
  NB. For efficent processing, we can do away with the structs and just have 3 arrays representing the modifications.
  NB. Should incorporate in the digest program eventually.
  
  Update 27.06.2019
  Instead of incorporating into the digester program it seems it would be better to work on the SQLite table of unique
  peptides (produced by toSQL). So something like this could be done:
  for each peptide sequence in the SQLite peptides table call the modifications function and generate the modified peptides
  but without saving all the overhead info on header, gene names etc. Instead only keep track of the peptide rowid from the 
  peptides table. Save the new modified masses together with the peptide rowid and number of each type of modification in a
  new SQLite table called modifications with a schema something like: rowid, mass, mod1, mod2, mod3...
  Then search for modified and unmodified peptides using the modifications and peptides tables. Or, include the unmodified
  peptide in the modifications table (0s for mod1, mod2 etc.) and use only modifications table for search.
  
  Update 28.06.2019
  The idea from yesterday seems to be working. Able to generate mod_pep for human db. Figured out how to implement N-term 
  acetylation: in the digester program, instead of removing N-term M should replace it with a special symbol (* could do it)
  then in the config file should define it as N-term_Acetyl with sites *. 
  The mass of the * should be added as 0 in the pepMass.c (might not be necessary though, as it is a switch statement that 
  returns 0 as default)..

  
  Algorithm for searching (to be implemented in July).
  For each modified peptide: generate all possible permutations and compute score. Select top score as candidate.
  Permutations appply to corresponding sites. Probably should do something like this:
  1. Read the peptide from db together with the modification counts. Store in a struct.
  2. Scan the sequence and determine the indices of all potential modification sites. Could be a separate array for 
     each modification. 
  3. Use the index array to generate the permutations:    
     for the example we have above: phos.ind[] = {3,6,7}, cam.ind[] = {5}, ox.ind[] = {8}. Since we have 2 phos and each 
     of the other two modifications are present we have the following possible permutations for phos,cam,ox represented as 
     matrix with rows for each peptide to be scored. Each row consists of 3 arrays with the corresponding indices. The matrix 
     can probably be generated with 3 loops. The first goes to combinations of possible 2 phos and for each starts a second loop 
     that will generate possible combinations of cam (if more than 1 there) and then for each of those will start an innermost 
     loop for the third modification and so on. The innermost loop will call the function which will generate y and b fragments and 
     compute the score.   

     phos  cam  ox
     3,6   5    8
     3,7   5    8
     6,7   5    8

  Potential combinatorial explosion: the matrix will be much larger if cam and ox have more than 1 possible residues. 
  Fragment generation could be by 2 loops. The first goes through the rows one by one (or this is the innermost loop
  described above). The second, nested in the first, goes through the sequence and for each index checks if it is in the corresponding 
  phos, cam or ox arrays for this row. The generation could possibly be implemente wwithin the function that generates y ions. 
  Something like: if (i in phos) add 79.9663 etc.

  Update 17.08.2020: Need to make it to read from config.rms, not modifications.txt. Should also take fixed modifications
  and generate peptides accordingly.

  Also, should compile with sqlite3.c and local sqlite3.h so systmes that do not have sqlite3 can run the app
*/

#include <stdio.h>
#include <libgen.h>
#include <string.h>
#include <stdlib.h>
#include "sqlite3.h"
#include "pepMass.h"

/* This is now declared in pepMass.h
typedef struct ptm {
    char name[1024];
    double delta_mass;
    char site[16];
} PTM;
*/
 
unsigned int next_multiset_combination(const unsigned int *multiset, unsigned int *ar, size_t n, unsigned int k) {
    unsigned int finished = 0;
    unsigned int changed = 0;
    unsigned int i;
    for (i = k - 1; !finished && !changed; i--) {
        if (ar[i] < multiset[i + (n - k)]) {
            /* Find the successor */
            unsigned int j;
            for (j = 0; multiset[j] <= ar[i]; j++);
            /* Replace this element with it */
            ar[i] = multiset[j];
            if (i < k - 1) {
                /* Make the elements after it the same as this part of the multiset */
                unsigned int l;
                for (l = i + 1, j = j + 1; l < k; l++, j++) {
                    ar[l] = multiset[j];
                }
            }
            changed = 1;
        }
        finished = i == 0;
    }
    if (!changed) {
        /* Reset to first combination */
        for (i = 0; i < k; i++) {
            ar[i] = multiset[i];
        }
    }
    return changed;
}

// Computes extra mass according to modifications but need to account for fixed mods as well. Will have to change
static double get_mass(const unsigned int *ar, size_t len, PTM *ptm, int n_mod) {
    double mass = 0;
    for (int i = 0; i < len; i++) mass = mass + ptm[ar[i]].delta_mass;
    return mass;
}

double get_fixed_mass(char *seq, PTM *ptm, int fixed_i) {
    double mass = 0;
    for (int i = 0; i < fixed_i; i++) {
        for (int j = 0; j < strlen(seq); j++) {
            if (strchr(ptm[i].site, seq[j]) != NULL) mass += ptm[i].delta_mass;
        }
    }
    return mass;
}

int compare (const void *p1, const void *p2) {
        unsigned int *a = (unsigned int *)p1;
        unsigned int *b = (unsigned int *)p2;
        return (*a - *b);
}

int main(int argc, char **argv) {

    if (argc < 3) {
        printf("You need to give peptide sequence to be analysed>\n");
        return 0;
    }

    // create fileStr and path for mod_pep files
    char fileStr[2048];
    char *dirName = dirname(argv[2]);
    sprintf(fileStr, "%s/mod_pep.txt", dirName);

    // Open sqlite database.
    sqlite3 *db;
    int rc;
    rc = sqlite3_open(argv[1], &db);
    if(rc){
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return(1);
    }
    
    FILE *cnfg;
    FILE *results;
    char str[1024];
    int i = 0;
    int fixed_i = 0;
    //char *token;
    sqlite3_stmt *ppStmt;
    char sql_inst[1024];

    // Create ptm array and populate it from config file.
    PTM *ptm = malloc(sizeof(*ptm));
    if (!ptm) {
        printf("Error allocating memory for ptm array!\n");
        exit(1);
    }

    PTM *ptm_fixed = malloc(sizeof(*ptm_fixed));
    if (!ptm_fixed) {
        printf("Error allocating memory for ptm array!\n");
        exit(1);
    }

    if ((cnfg = fopen(argv[2], "r")) == NULL) {
        printf("Error openning config file!\n");
        exit(1);
    }    

    if ((results = fopen(fileStr, "w")) == NULL) {
        printf("Error openning file for writing!\n");
        exit(1);
    }
    
    /*
    while (fgets(str, sizeof(str), cnfg) != NULL) {
        PTM *tmp = realloc(ptm, (1 + i)*sizeof(PTM));
        if (!tmp) {
            printf("Error reallocating memory for ptm array!\n");
            free(ptm);
            exit(1);
        }
        ptm = tmp;
        token = strtok(str, "\t");
        strcpy(ptm[i].name, token);
        token = strtok(NULL, "\t");
        ptm[i].delta_mass = atof(token);
        token = strtok(NULL, "\t");
        strcpy(ptm[i].site, token);
        //strtok(NULL, "\t");
        i++;
    }
    */


    // Read modifications into ptm array from cnfg file.
    while (fgets(str, sizeof(str), cnfg) != NULL) {

        // Change code to read from new type config file
        if (strstr(str, "_varMod")) {
            PTM *tmp = realloc(ptm, (1 + i)*sizeof(PTM));
            if (!tmp) {
                printf("Error reallocating memory for ptm array!\n");
                free(ptm);
                exit(1);
            }
            ptm = tmp;

            sscanf(str, "_varMod\t%s\t%lf\t%s", ptm[i].name, &ptm[i].delta_mass, ptm[i].site);
            i++;
        }

        else if (strstr(str, "_fixedMod")) {
            PTM *tmp_fixed = realloc(ptm_fixed, (1 + fixed_i)*sizeof(PTM));
            if (!tmp_fixed) {
                printf("Error reallocating memory for ptm array!\n");
                free(ptm_fixed);
                exit(1);
            }
            ptm_fixed = tmp_fixed;

            sscanf(str, "_fixedMod\t%s\t%lf\t%s", ptm_fixed[fixed_i].name, &ptm_fixed[fixed_i].delta_mass, ptm_fixed[fixed_i].site);
            fixed_i++;
       
        } 
        /*
        token = strtok(modStr, "\t");
        strcpy(ptm[i].name, token);
        token = strtok(NULL, "\t");
        ptm[i].delta_mass = atof(token);
        token = strtok(NULL, "\t");
        strcpy(ptm[i].site, token);
        //strtok(NULL, "\t");
        */
        //i++;
    }


    printf("Will search for %d variable modifications.\n", i);
    for (int r = 0; r < i; r++) {
        printf("%s\t%lf\t%s\n", ptm[r].name, ptm[r].delta_mass, ptm[r].site);
    }
    printf("\n");

    printf("Will search for %d fixed modifications.\n", fixed_i);
    for (int r = 0; r < fixed_i; r++) {
        printf("%s\t%lf\t%s\n", ptm_fixed[r].name, ptm_fixed[r].delta_mass, ptm_fixed[r].site);
    }
    printf("\n");

    char seq[1024];
    
    /* For testing only
    printf("Please enter a sequence to test\n");
    scanf("%s", seq);
    printf("Mass is %lf\n", pepMass(seq) + Pr + get_fixed_mass(seq, ptm_fixed, fixed_i));
    fclose(cnfg);
    fclose(results);
    sqlite3_close(db);
    free(ptm);
    free(ptm_fixed);
    return 0;    
    */

    /*Prepare sql statement*/
    sprintf(sql_inst, "select rowid, sequence from peptides;");
    rc = sqlite3_prepare_v2(db, sql_inst, -1, &ppStmt, 0);

    /*Start loop here to get all peptides from db and generate mod_pep for each*/
    while ((rc = sqlite3_step(ppStmt)) != 101) {
        if (rc == 100) {

            // Read the sequence and populate multiset.
            int rowid = sqlite3_column_int(ppStmt, 0);
            strcpy(seq, (char *)sqlite3_column_text(ppStmt, 1));
            //int decoy = sqlite3_column_int(ppStmt, 2);
            //int contam = sqlite3_column_int(ppStmt, 3);

            // Write unmodified peptide to results. Update 18.08.2020: should account for fixed mods
            double fixed_extra_mass = get_fixed_mass(seq, ptm_fixed, fixed_i);
            fprintf(results, "%d\t%lf", rowid, pepMass(seq) + fixed_extra_mass + Pr); 
            for (int r = 0; r < i; r++) fprintf(results, "\t%d", 0);
            fprintf(results, "\n");

            int y = 0;
            for (int r = 0; r < i; r++) {    
                for (int p = 0; p < strlen(seq); p++) {
                    if (strchr(ptm[r].site, seq[p]) != NULL) {
                        //multiset[p] = 0;
                        y++;
                    }  
                    else continue; 
                }
            }
            //if (y == 0) return 0;
            //printf("y is %d\n", y);
            unsigned int multiset[y];
            unsigned int n = sizeof(multiset) / sizeof(unsigned int);
            y = 0;
            for (int p = 0; p < strlen(seq); p++) {
                for (int r = 0; r < i; r++) {
                    if (strchr(ptm[r].site, seq[p]) != NULL) {
                        multiset[y] = r;
                        y++;
                    }
                    else continue;
                }
            }
            //for (int p = 0; p < y; p++) printf("%d\n", multiset[p]);
            qsort(multiset, n, sizeof(unsigned int), compare);
            //for (int p = 0; p < y; p++) printf("%d\n", multiset[p]);
    
            //int phos_mod, cys_CAM_mod, M_Ox_mod;
            int counts[i];
            for (int ctr = 1; ctr <= n; ctr++){ 
                unsigned int numbers[ctr];
                for (int j = 0; j < ctr; j++) numbers[j] = multiset[j];
                do {
                    for (int r = 0; r < i; r++) counts[r] = 0;
                    for (int m = 0; m < ctr; m++){
                        for (int r = 0; r < i; r++) {
                            if (numbers[m] == r) {
                                counts[r]++;
                                break;
                            }
                        }
                    }
                    fprintf(results, "%d\t%lf", rowid, pepMass(seq) + Pr + get_mass(numbers, ctr, ptm, i));
                    for (int r = 0; r < i; r++) fprintf(results, "\t%d", counts[r]); 
                    fprintf(results, "\n");
                } while (next_multiset_combination(multiset, numbers, n, ctr));
            }
        }
        else {
            printf("Error executing sql statement: %d.\n", rc);
            exit(1);
        }        
    }
    sqlite3_finalize(ppStmt);
    fclose(cnfg);
    fclose(results);
    sqlite3_close(db);
    //free(dirName);
    free(ptm);
    free(ptm_fixed);
    return 0;
}


