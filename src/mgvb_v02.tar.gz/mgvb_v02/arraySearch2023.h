#ifndef ARRAYSEARCH2023_H
#define ARRAYSEARCH2023_H


// Struct to hold mod_pep data.
typedef struct Mod_Pep {
    int pep_id;
    double mass;
} mod_pep;

// Struct to hold mod_pep data.
typedef struct Pep_info {
    int missed;
    int decoy;
    int contam;
} pep_info;

// Count lines
int count_lines(FILE*);

// Import mod_pep from file and put it into sorted array in memory
int make_arrays(FILE*, FILE*, int n_ptm, int, int, int mods[][n_ptm], 
		mod_pep**, pep_info**, char**, char**);

// Search array, return index of the smallest element matching criteria
int find_min_match(mod_pep*, int, int, double, double);

#endif
