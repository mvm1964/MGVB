#include "mass_recalibration.c"

int main(int argc, char **argv) {

    double res[4];
    for (int i = 0; i < 4; i++) {
        res[i] = 0;
    }

    mass_recalibration(3, argv[1], res, atof(argv[2]), atoi(argv[3]));

    printf("Fitted model: %lf, %lf, %lf, %lf\n", res[0], res[1], res[2], res[3]);

    return 0;
}

