/* 
 * Efficient sorted array search algorithm
 *
 * Author: Metodi V. Metodiev
 * Ravna, Bulgaria, 20.12.2023
 *
 * Given two sorted array, find the elments of array 2 that are within 
 * +/- tolerance of the elements of array 1.
 *
 * In this particular case I am using it to match LC-MS/MS spectra to 
 * peptide sequences. The elements of array 1 are the masses from the spectrum.
 * Array 2 holds the peptide fragment masses.
 *
 * Spectra will be sorted in order of precursor mass (array 1) and will be matched 
 * to an array of peptide masses (array 2). A version of th einterval_search function
 * will be used to return all precursors matching the search interval. 
 *
 * Should refactor to put xcorr in a separate file and be able to call it from here. 
 *
 * It os also worth considering using this instead of Sqlite. This will work like this:
 *
 * 1. Each thread will collect spectra from mms file into an array os structs sorted
 *    by precursor mass.
 * 2. A sorted mod_pep struct array will be kept in memory by each thread. These structs
 *    will have mass (by which they are sorted), pep_id, sequence, ptm array as fields.
 *    It will be perhaps easiest to have separate arrays instead of a struct.
 * 3. Search will go as for xcorr: start with the smallest mass in the mod_pep array
 *    and search until the first mass matching query is found, selelct until the last one
 *    matching is found and keep the index of the next mod_pep element to start with it 
 *    the search for the next spectrum in the sorted spec array.
 *    NB: to speadup the first search, I can implement a binary search step at the beginning. 
 *  
 *    27.12.2023: Will actually implement the second idea firts to relace Sqlite for precursor 
 *    searches.
 *
 *    29.12.2023: So far so good. It all worked at small scale but when tried on ceres, could 
 *    not allocate memory for the arrays. Now going back to "normalised" arrays implementation.
 *    Will keep in pep_mod only the pep_id and mass. Will put in a separate peptides array
 *    sequence, and prot_id, missed, decoy and contam. The trick is, peptides array is sorted
 *    by design and pep_id from mod_pep corresponds to the index of peptides. Should only remember
 *    that the index starts at 1, not 0!
 */

#include <math.h>
#include <stdio.h>
#include "arraySearch.h"
#include <stdlib.h>
#include <string.h>

// count lines
int count_lines(FILE* file) {
    char buf[65536];
    int counter = 0;
    for(;;) {
    
        size_t res = fread(buf, 1, 65536, file);
        if (ferror(file))
            return -1;

        int i;
        for(i = 0; i < res; i++)
            if (buf[i] == '\n')
                counter++;

        if (feof(file))
            break;
    }

    return counter;
}

// Import mod_pep_array and mods from file and put them into arrays in memory
int make_mod_pep(FILE *mod_pep_file, int cols, int rows, int mods[rows][cols], mod_pep **mod_pep_array) {
    // read file, allocate array, and populate array
    // first determine the number of records in the file
    char mod_pep_Str[2048];
    /*
    // create mods 2d array
    *mods = malloc(sizeof(int[N_mod_pep][n_ptm]));
    if (!(*mods)) {
        printf("Cannot allocate memory for mods!\n");
        exit(1);
    }
    */

    // allocate mod_pep array
    *mod_pep_array = malloc(rows*sizeof(mod_pep));
    char *pch;
    if (!(*mod_pep_array)) {
        printf("Cannot allocate memory for mod_pep_array!\n");
	exit(1);
    }
    // read the file and populate the 2 arrays
    int ctr = 0;
    while (fgets(mod_pep_Str, sizeof(mod_pep_Str), mod_pep_file) != NULL) {
	
	// debug 
	//printf("%s\n", mod_pep_Str);

        pch = strtok(mod_pep_Str, "\t");
        (*mod_pep_array)[ctr].pep_id = atoi(pch);  	    
        pch = strtok(NULL, "\t");
	(*mod_pep_array)[ctr].mass = atof(pch);
	
	for (int j = 0; j < cols; j++) {

            // debug
            //printf("pch is %s\n", pch);

            pch = strtok (NULL, "\t");
            mods[ctr][j] = atoi(pch);
        }
	
	pch = strtok(NULL, "\t");
        strcpy((*mod_pep_array)[ctr].sequence, pch);
	pch = strtok(NULL, "\t");
        strcpy((*mod_pep_array)[ctr].prot_id, pch);
        pch = strtok(NULL, "\t");
	(*mod_pep_array)[ctr].missed = atoi(pch);
        pch = strtok(NULL, "\t");
	(*mod_pep_array)[ctr].decoy = atoi(pch);
        pch = strtok (NULL, "\t");
	(*mod_pep_array)[ctr].contam = atoi(pch);

        // debug
	/*printf("%d, %lf, %s\n", (*mod_pep_array)[ctr].pep_id, 
			(*mod_pep_array)[ctr].mass, 
			(*mod_pep_array)[ctr].sequence);
        */
        
	//printf("ctr is %d\n", ctr);
        
        // debug
	//if (ctr == 2) return ctr;

        ctr++;	
    }

    // debug: test arrays
    /*for (int i = 0; i < 5; i++) {
        printf("%s, %lf\n", mod_pep_array[i].sequence, mod_pep_array[i].mass);
    }*/

    return ctr;
}

// Search array, return index of the smallest element matching criteria
int find_min_match(mod_pep *arr, int start, int end, double tol, double target) {
    if (start >= end) return -1;
    int mid = start + (end - start + 1)/2;
    //printf("Mid is %d\n", mid);
    int ind = 0;
    int index = 0;
    if (arr[mid].mass > target + tol) return find_min_match(arr, 0, mid - 1, tol, target);
    else if  (arr[mid].mass < target - tol) return find_min_match(arr, mid + 1, end, tol, target);
    else {
        ind = mid;
	while (arr[ind].mass >= target - tol) {
            index = ind;
	    ind--;
        }
        return index;            
    }
}

/*
 * Once we find the first element xcorr is called in a while loop
 */

// lets test with a separate test file
