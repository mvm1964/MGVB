#ifndef BST_OPEN_H
#define BST_OPEN_H

// Struct to hold bst link.
typedef struct STnode *link;
struct STnode {
    Item item;
    link l;
    link r;
    int N;
};

// Declare head and z as extern.
extern link head, z; 
extern int comb_index;

#pragma omp threadprivate(head, z, comb_index)

// Functions to build bst.
/*
  Update 17.08.2021: will refactor some functions to enable parallel processing
  head and z need to be passed through the argument list of bst, comb_kN and some 
  otheer functions so openMP can work
  Will make the folloing changes:
  1. Add head and z links to the argument lists of bst, comb_kN, mid_xcorr, STinit,
     STcount, STsearch, STsearch_ins,  STsearch, int_STsearch, STinsert, SearchR_ins  
  2. Change scorer_open and scorer_new_2021 to include head and z as parameters
     of callback and xcorr
*/
void bst(int*, char*, int, Item, Item, mod_ind*, int); 
void mid_xcor(mod_ind[], int*, char*, char*, int, Item, Item);
void comb_kN(mod_ind[], int*, int*, int, int, char*, int, int, int, char*, int, Item, Item);
link NEW(Item, link, link, int);
void STinit();
int STcount();
Item searchR(link, Key);
Item searchR_ins(link, Key, char*, char*);
Item STsearch(Key);
Item STsearch_ins(Key, char*, char*);
Item int_searchR(link, double, double);
Item int_STsearch(double, double);
link insertR(link, Item);

void STinsert(Item);
void STprint(link);
void STto_array(link, Item*, int*);
int rangeSelect( link, double, double);
void STdestroy(link);
void bst_y(link, Item, int, int, Item);
void bst_b(link, Item, int, int, Item);

// Update 15.07.2020: new function added to bst.c
int interval_search(link, double, double, Item**, int*, double*, int, int, double, int*, int*, double*, int*, int*, int*, int, int*, int*, int*);

// Update 12.09.2022: new functions added to bst.c
int nh3_loss(double*, int, char*, double, double, double*, int*, link);
int h2o_loss(double*, int, char*, double, double, double*, int*, link);
int phos_nloss(double*, int, char*, double, double, double*, char*, int*, int, link);
#endif
