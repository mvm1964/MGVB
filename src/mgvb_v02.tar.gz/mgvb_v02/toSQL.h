#ifndef TOSQL_H
#define TOSQL_H

int toSQL_proteins(sqlite3*, char*);
int toSQL_peptides(sqlite3*, char*);
int toSQL_mod_pep(sqlite3*, char*, char*);
#endif 
