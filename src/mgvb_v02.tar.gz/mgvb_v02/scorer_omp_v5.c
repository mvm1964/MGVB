/*
  Minimal MS/MS search engine in C 
  Usage: scorer_2020 <mms file> <db file> <config file> <maxMod>
  Metodi V. Metodiev, 2019, UK     

  Compilation:
  gcc -g -Wall scorer_mod_2020.c -o scorer_mod_2020_linux -lgmp -lmpfr -lsqlite3 pepMass.c Item.c bst.c

  Update 12 July 2019: starting impementation of modified peptide search.

  Algorithm notes:
  1. Uses pointers to mod_ind and ptm arrays as in comb_kN_new.c.
  2. Retrieves modifications info, peptide and protein IDs and sequence from pep_mod table.
  3. For each predicted fragment ion generate acceptable combinations of
     masses derived from modified sequences. Acceptable means all combinations that satisfy
     the limits set by counts[]. Cognate y and b ions are considered in this proces. For 
     example a doubly phosphorylated peptide with a sequence GESPQSPSPR cannot have a unmodified
     y5 and beyond ions and also cannot have unmodified b ions beyond b6. On the other hand, the 
     peptide can produce singly and doubly phosphorylated y5 fragments and so on. 
     This could be done by calling a function similar to comb_kN_new.c with fragment sequence and
     mod info, It will generate modified fragments masses list, which can be used for scoring.
     For exampe:
         Let sequence of peptide is GESPQSPSPR and it is doubly phosphorylated.
         Consider the SPSPR fragment (which is y5). Acceptable modifications are:
            1 and 2 phosphorylations—0 is not acceptable as there is only one modifiable
            residue in the cognate b6 peptide..    
  4. Computes score based on ALL possible modified fragment masses INCLUDED.
     Thus it covers mixturs of peptide precursor ions modified on alternative sites.
  5. For a selected set of hits generates all combinations of uniquely modified sequences
     and computes corresponding individual scores.
  6. Uses the individual scores to calculate localisation probabilities. 
     
  Update 01.08.2020: starting the implementation of decoy searches within the scorer program. Instead
  of puting decoy sequnces in the sqlite tabes, scorer will generate the reverse sequences on the fly 
  and seqrch against the MS/MS peaks.
  Update 03.08.2020: On the fly analysis of reverse decoy peptide sequences generates high scoring sequences
  and does not work for filtering. Possibly this is only vaid for modified peptides but still, need to switch 
  bck to using reversed whole-protein sequences and implement this in the digestor program.  

  Update 15.08.2020: starting the parser function that should read from the config file and parse

  - precTol
  - tol
  - FASTA files
  - maxMod
  - Variable modifications
  - Fixed modifications

  Will use fgets() as in parseMS
   
  28.09.2022: will implement intensity scoring and phospho neutral loss to improve fdr
  will go like this: sum up the intensity of all peaks matched to theoretical ions. Will record the 
  intensities in the item_array, items should have a field intensity. 
  No, simples is to define a variable, success and assign it a value of 1 interval_search is
  successful or 0 if not. Then add frint[i]*success to a variabe xcr_match.

  08.10.2022: major refactoring. Instead of results1 and 2 will pass only a single results struct to xcor.
  Then in call back will use it to populate results1 and results2

  8.11.2022: starting major refactoring:
  n2_array will hold the matched fragments for each combination with no neutral losses considered
  n3_array will hold the matched fragments with neutral losses considered
  n4_array will hold total expected fragments with no neutral losses considered
  n5_array will hold total with neutral losses considered.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sqlite3.h"
#include <math.h>
#include <gmp.h>
#include <mpfr.h>
#include "pepMass.h"
#include "item_open.h"
#include "bst_open.h"
#include "compute_site_prob_optimized.h"
#include <omp.h>
#include "parse_spectrum.h"

/* update 02.09.2021: will optimize performance by 
   1. reduce writes to file
   2. move db to memory
   for 1 will make results structs similar to scorer_open_mpi but simpler 
   
   03.09.2021: after much work it does not speed up when only top and next best are saved to file.
   Will now try moving db to memory
*/

/*
typedef struct Results {
    double score;
    char data[4096];
} results;
*/

// This function reverses strings (copied it from the web).
/*char *strrev(char *str) {
      char *p1, *p2;

      if (! str || ! *str)
            return str;
      for (p1 = str, p2 = str + strlen(str) - 1; p2 > p1; ++p1, --p2)
      {
            *p1 ^= *p2;
            *p2 ^= *p1;
            *p1 ^= *p2;
      }
      return str;
}*/


// calculates p-score
double get_Pscore (int n2, int n4, double q1) {   // very importnt: q1 should be double otherwise does not work
    // Variables for computing binomial coefficient and probabilities
    double res123 = 0;

    mpf_t p;
    mpf_t p1;
    mpz_t comb;
    mpf_t prob1;
    mpf_t prob2;
    mpf_t prob;
    mpf_t comb1;
    mpfr_t score;
    mpz_init_set_ui(comb, 0);
    mpf_init_set_d(prob1, 0);
    mpf_init_set_d(prob2, 0);
    mpf_init_set_d(prob, 0);

    mpf_init_set_d(p, q1/(100));
    mpf_init_set_d(p1, 1-q1/(100));
    mpf_init_set_d(comb1, 0);
    mpfr_init(score);
    mpfr_set_d(score, 0, MPFR_RNDZ);
    mpfr_t cdf;
    mpfr_init_set_d(cdf, 0, MPFR_RNDZ);

    if (n2 > 0 && n2 < n4){
        for (int i = n2; i <= n4; i++) {
            mpf_pow_ui(prob1, p, i);
            mpf_pow_ui(prob2, p1, n4-i);
            mpf_mul(prob, prob1, prob2);
            mpz_bin_uiui(comb, n4, i);
            mpf_set_z(comb1, comb);
            mpf_mul(prob, prob, comb1);
            mpfr_set_f(score, prob, MPFR_RNDZ);
            mpfr_add(cdf, cdf, score, MPFR_RNDZ);
        }

	mpfr_log10(cdf, cdf, MPFR_RNDZ);
        res123 = -10*mpfr_get_d(cdf, MPFR_RNDZ);
        // for debuging
        //printf("n2, n4, q1, sore: %d, %d, %lf, %lf\n", n2, n4, q1, res123);
    }

    else if (n2 > 0 && n2 >= n4)  {
        mpf_pow_ui(prob1, p, n4);
        mpfr_set_f(score, prob1, MPFR_RNDZ);
        mpfr_log10(score, score, MPFR_RNDZ);
        res123 = -10*mpfr_get_d(score, MPFR_RNDZ);
    }
    else res123 = 0;

    // free variables
    mpz_clear(comb);
    mpf_clear(p);
    mpf_clear(p1);
    mpf_clear(prob1);
    mpf_clear(prob2);
    mpf_clear(prob);
    mpf_clear(comb1);
    mpfr_clear(score);
    mpfr_clear(cdf);

    // for debuging
    //printf("n2, n4, q1, sore: %d, %d, %d, %lf\n", n2, n4, q1, res123);
    return res123;
}


// Parser function for parsing run parameters
int parse_params(char *config_file, int *prTol, double *frTol, char fasta[5][2048], int *maxMod, double *q_start, double *q_max, int *n_losses) {

    FILE *cnfg;
    char str[1028];
    int fasta_ctr = 0;
    //int ptm_ctr = 0;

    // Open config file for reading
    if ((cnfg = fopen(config_file, "r")) == NULL) {
        printf("Error opening config file!");
        exit(1);
    }     

    // Read the config file line by line and parse it.
    while (fgets(str, sizeof(str), cnfg) != NULL) {
        if (strstr(str, "_precTol")) {
            sscanf(str, "_precTol\t%d", prTol);
        }
        else if (strstr(str, "_tol")) {
            sscanf(str, "_tol\t%lf", frTol);
        }
        /*else if (strstr(str, "_q")) {
            sscanf(str, "_q\t%d", fr_q);
        }
        else if (strstr(str, "_maxSize")) {
            sscanf(str, "_maxSize\t%d", fr_maxSize);
        }*/
        else if (strstr(str, "_fasta")) {
            sscanf(str, "_fasta\t%s", fasta[fasta_ctr]); // fasta should be crated in main with sufficient size
            fasta_ctr++;
        }
        else if (strstr(str, "_maxMod")) {
            sscanf(str, "_maxMod\t%d", maxMod);
        }
	else if (strstr(str, "_qmax")) {
            sscanf(str, "_qmax\t%lf", q_max);
        }
        else if (strstr(str, "_qstart")) {
            sscanf(str, "_qstart\t%lf", q_start);
        }
        else if (strstr(str, "_nLosses")) {
            sscanf(str, "_nLosses\t%d", n_losses);
        }

        /* Having second thought about ptm. No need to rewrite so much code. 
           will just modify the code in main and other functions that read ptm
        */
    }
    fclose(cnfg);
    return fasta_ctr;
} 

// A file pointer for the results. Declared here so it can be used by many functions.
FILE *res;
int precTol = 10;
double tol = 0.6;
double q_max = 7.0;
double q_start = 1.0;
int n_losses = 0;

/* A function to compute xcorr.
   
   Now it considers modifications (see update above). It should do something like:

   If there are modification:

   1. For each fragMass: look in the sequence and mod info and decide what masses
      to compare to the spectral data. Should generate combinations, test
      if corresponding masses match spectral peaks and update the counter.
      Combinations: 
      - First, for each type of modification determine the total number of modifiable 
        residues (N[], should be an array of size i).
      - For a specific y fragment determine the number of modifiable residues of given 
        type (n1[j]).
      - Let the required number for a modification be n (from the data returned from mod-pep query).
      - Now:
            if (n1[j] = 0) no modifications for this fragment;
            else if (N[j] - n1[j] < n) combine from n - (N[j] - n1)[j] to n1[j];
            else combine from 0 to n1[j];
            cognate fragment masses are computed as usual: 
                pepMass - fragMass + Pr + Pr;  
   2. Keep account of what peptide is top scorer.

   If top scorer is modified peptide:

   3. Estimate localisation probabilities for the top scorer.
  
   If top scorer is unmodified proceed as previously.

   Update 09.09.2019

      It might be simpler to go to individual combinations as geenrated by comb_kN.c and
      then sum up the matches to allow for isoforms. Given that com_kN is already implemented
      this will speed up development and will also allow easier computation of individual scores for
      isoforms.

      to do this we will need code that uses  
   
   Update May 2020: now we use a bst function which generates a search tree for all possible combinations
   of modifications positions and corresponding y and b fragments. scorer_mod now needs to use this tree to
   check each spectrum peak for matching and output the corresponding data to a file. It also needs to use the
   Bayesian network function to compute site probabilities.


   Update 02.08.2021: need to refactor xcorr and calback to be able to only write results rows with score > of certain limit

*/
double xcorr(char *seq, double *frmz, double *frint, int charge, double prec, int n, int *counts, int numMod, Item item, Item item1, mod_ind *mod, results *xcr_results, char *str3, double q1) {
    int n1 = strlen(seq);
    int n2 = 0; // for counting matched masses
    int n3 = 0; // for counting only y and b fragments 06.10.2022
    int n5 = 2*n1 - 2; // for alternative scoring 06.10.2022
    double xcr = 0;
    double xcr_match = 0;
    int succs = 0;
    double res123 = 0;
    double alt_res123 = 0;
    
    /* Update 15.07.2020: create item_array and n_item vars. Should not forget to free(item_array) 
       because interval_search() realloc memory to it.
    */
    Item *item_array = NULL; //(Item *)malloc(0);
    int n_item = 0;


    // Update 19.07.2021: p should be a function of fragment mass tolerance and the number of peaks in the spectrum
    bst(counts, seq, n, item, item1, mod, numMod);
    int max_match = 0;
    int *n2_array = malloc(sizeof(int)*comb_index);
    int *n3_array = malloc(sizeof(int)*comb_index);
    int *n4_array = malloc(sizeof(int)*comb_index);
    int *n5_array = malloc(sizeof(int)*comb_index);
    for (int i = 0; i < comb_index; i++) {
        n2_array[i] = 0;
	n3_array[i] = 0;
        n4_array[i] = n5;
	n5_array[i] = n5;
    }

    int n4 = 2*n1 - 2;
    int y_fr[n1];
    int b_fr[n1];
    for (int i = 0; i < n1; i++) {
        y_fr[i] = 0;
	b_fr[i] = 0;
    }

    // Now use the tree to search for matches to the spectrum masses. Should account 
    // for doubly charged fragments if precursor charge > 2. 
    for (int i = 0; i < n; i++) {
        //if (frmz[i] == 0 || frint[i] == 0) continue;

        xcr = xcr + frint[i];

	succs = interval_search(head, frmz[i] - tol, frmz[i] + tol, &item_array, &n_item, frmz, 
			i, 0, tol, y_fr, b_fr, frint, &n2, &n4, n2_array, numMod, n3_array, n4_array, n5_array);
        if (charge > 2){
            succs = interval_search(head, (frmz[i]*2 - Pr) - tol, (frmz[i]*2 - Pr) + tol, &item_array, &n_item, frmz, i, 
			    1, tol, y_fr, b_fr, frint, &n2, &n4, n2_array, numMod, n3_array, n4_array, n5_array);
        }
    }


    // 29.09.2022: now calculate intensity coverage
    for (int i = 0; i < n_item; i++) {
        xcr_match += item_array[i]->intensity;
    }

    // 8.11.2022: need to calculate score for each combination because both, n2 and n4 are different
    // and should put this calculation in a separate function at last
    
    double max_score_n2 = 0;
    double max_score_n3 = 0;
    double tmp_score_n2 = 0;
    double tmp_score_n3 = 0;

    for (int i = 0; i < comb_index; i++) {
        tmp_score_n2 = get_Pscore(n2_array[i], n4_array[i], q1);
        tmp_score_n3 = get_Pscore(n3_array[i], n5_array[i], q1);
    
	if (tmp_score_n2 > max_score_n2) {
            max_score_n2 = tmp_score_n2;
	    n2 = n2_array[i];
            n4 = n4_array[i];
	}
	if (tmp_score_n3 > max_score_n3) {
            max_score_n3 = tmp_score_n3;
            n3 = n3_array[i];
            n5 = n5_array[i];
        }
    }
    
    alt_res123 = max_score_n3;
    res123 = max_score_n2;

    // 11.10.2022: only proper y and b matches will be considered for scoring to test if performance better
    if (alt_res123 > res123 && n_losses != 0) {
        res123 = alt_res123;
	n2 = n3;
	n4 = n5;
    }
    
    // now populate xcr_results
    if (res123 > xcr_results->score) {
	xcr_results->score = res123;
        if (n2 > 0) {
            strcpy(xcr_results->data, "");
            sprintf(str3, "%d\t%d\t%lf\t%lf\t", n4, n2, xcr_match/xcr, q1);
            strcat(xcr_results->data, str3);
            for (int ctr = 0; ctr < numMod; ctr++) {
                if (counts[ctr] == 0) strcat(xcr_results->data, "NA\t");
                else compute_site_prob_optimized(xcr_results, str3, ctr, counts[ctr], seq, item_array, n_item); // need to modify compute_site_prob to strcat
            }
        }
        for (int i = 0; i < n_item; i++) {
            sprintf(str3,"%s,", item_array[i]->fragType);
            strcat(xcr_results->data, str3);
        }
        //fprintf(res, "\t");
        for (int i = 0; i < n_item; i++) {
            sprintf(str3,"%lf,", *(item_array[i]->key));
            strcat(xcr_results->data, str3);
        }

        // free the item_array
        for (int i = 0; i < n_item; i++) {
            free(item_array[i]->key);
            free(item_array[i]);
        }
        free(item_array);
        STdestroy(head);
	free(n2_array);
	free(n3_array);
	free(n4_array);
	free(n5_array);
        return res123;

    }
    else {
        // free the item_array
        for (int i = 0; i < n_item; i++) {
            free(item_array[i]->key);
            free(item_array[i]);
        }
        free(item_array);
        STdestroy(head);
	free(n2_array);
	free(n3_array);
        free(n4_array);
	free(n5_array);
        return res123;
    }
}

/* Callback function for sqlite3
   Need to include matched and total ion numbers in the results. Will have to modify the function 
   to receive the score and the matched ion number as a pointer to array (18.07.2020).
*/
int callback(int rowid, int *counts, int i, char *seq, void *dt, char *proteins, Item item, Item item1, mod_ind *mod, link head, link z, int missed, int decoy, int contam, int nMod, results *results1, results *results2, char *str3) {
    //int i;

    // For debugging
    //for (int ctr = 0; ctr < i; ctr++) printf("%s is %d\n", ptm[ctr].name, ptm[ctr].count);

    //double q_max = q;
    spectrum *spec = (spectrum *) dt;
    results xcr_results;
    xcr_results.score = 0;
    strcpy(xcr_results.data, "");

    // update 07.10.2022: will start the implementation of varying q: for low res q 5, 6, and 7 will be tested
    // for high res q 8, 9, 10 will be tested
    // to do this will have to use the interval_fill and other functions from parseMS.c
    double max_score = 0;
    for (int q1 = q_start; q1 <= q_max; q1++) {
        // continue tomorrow: 08.10.2022
        spectrum spec1 = *(spec);
	for (int t = 0; t < spec1.actual_size; t++) {
            spec1.fragMass[t] = 0;
	    spec1.fragInt[t] = 0;
	}

        int wi[21];
        //for (int j = 1; j <= 21; j++) wi[j] = 0;
	for (int j = 0; j < 21; j++) wi[j] = 0;
        //int q1 = atoi(argv[1]);
        double mass;
        double intensity;
        int interval = 0;

        // now use the spec to create spectra with various q
        for (int t = 0; t < spec->actual_size; t++) {
            mass = spec->fragMass[t];
            intensity = spec->fragInt[t];
            // Fill intervals here.
            if (mass > 2000) interval = 21;
            else interval = ceil(mass/100);
            intervalFill(mass, intensity, &spec1, wi, interval, q1);
            wi[interval]++;
        }
        sort_masses(&spec1);
        remove_0(&spec1);
        double score = 0;
        if (strlen(seq) > 1) {
        //printf("Sequence is %s.\n", argv[0]);
            score = xcorr(seq, spec1.fragMass, spec1.fragInt, spec1.charge, spec1.precMass, spec1.actual_size, counts, i, item, item1, mod, &xcr_results, str3, q1);
        if (score > max_score) {
            max_score = score;
	}
        // For debugging
        /*printf("Score and q1 are %lf, %d\n", score, q1);
        for (int w = 0; w < spec1.actual_size; w++) {
            printf("%lf\t%lf\n", spec1.fragMass[w], spec1.fragInt[w]);
	}*/
            /*if (score > results1->score) {
                results1->score = score; 
                sprintf(str3, "\b \t%d\t%d\t%lf\t%s\t%d\t%lf\t%lf\t%s", spec->scan, spec->scanNum, spec->retTime, seq, spec->charge, spec->precMass, score, proteins);
                strcat(results1->data, str3);
                for (int ctr = 0; ctr < i; ctr++) {
                    sprintf(str3, "\t%d", counts[ctr]);
                    strcat(results1->data, str3);
                }
                sprintf(str3, "\t%d\t%d\t%d\t%d\n", nMod, missed, decoy, contam);
                strcat(results1->data, str3);
            }
            else if (score > results2->score) {
                results2->score = score;
                sprintf(str3, "\b \t%d\t%d\t%lf\t%s\t%d\t%lf\t%lf\t%s", spec->scan, spec->scanNum, spec->retTime, seq, spec->charge, spec->precMass, score, proteins);
                strcat(results2->data, str3);
                for (int ctr = 0; ctr < i; ctr++) {
                    sprintf(str3, "\t%d", counts[ctr]);
                    strcat(results2->data, str3);
                }
                sprintf(str3, "\t%d\t%d\t%d\t%d\n", nMod, missed, decoy, contam);
                strcat(results2->data, str3);
            }*/

        }
    }

    if (max_score > results1->score) {
        results1->score = max_score;

	strcpy(results1->data, xcr_results.data);
        sprintf(str3, "\b \t%d\t%d\t%lf\t%s\t%d\t%lf\t%lf\t%s", spec->scan, spec->scanNum, spec->retTime, seq, spec->charge, spec->precMass, max_score, proteins);
        strcat(results1->data, str3);
        for (int ctr = 0; ctr < i; ctr++) {
            sprintf(str3, "\t%d", counts[ctr]);
            strcat(results1->data, str3);
        }
        sprintf(str3, "\t%d\t%d\t%d\t%d\t", nMod, missed, decoy, contam);
        strcat(results1->data, str3);
    }
    else if (max_score > results2->score) {
        results2->score = max_score;
	strcpy(results2->data, xcr_results.data);
        sprintf(str3, "\b \t%d\t%d\t%lf\t%s\t%d\t%lf\t%lf\t%s", spec->scan, spec->scanNum, spec->retTime, seq, spec->charge, spec->precMass, max_score, proteins);
        strcat(results2->data, str3);
        for (int ctr = 0; ctr < i; ctr++) {
            sprintf(str3, "\t%d", counts[ctr]);
            strcat(results2->data, str3);
        }
        sprintf(str3, "\t%d\t%d\t%d\t%d\t", nMod, missed, decoy, contam);
        strcat(results2->data, str3);
    }

    // Update 01.08.2020: Decoy analysis. Will generate a reverse sequence and analyse it as above.
    // not working so going back to original. Decoy sequences are now in db
    /*char revSeq[strlen(seq)];
    char s[strlen(seq)];
    strcpy(revSeq, seq);
    revSeq[strlen(seq)-1] = '\0';
    strcpy(s, strrev(revSeq)); 
    strcat(s, seq + strlen(seq) - 1); // this adds the C-terminal K or R

    // Now proceed with analysis of reverse sequence
    score = 0;

    char decoy[2048] = "decoy_:";
    
    strcat(decoy, proteins);
    score = xcorr(s, spec->fragMass, spec->fragInt, spec->charge, spec->precMass, sizeof(spec->fragMass)/sizeof(double), counts, i, item, item1, mod);
    
    if (score > 0) {
        fprintf(res, "%d\t%d\t%lf\t%s\t%d\t%lf\t%lf\t%s", spec->scan, spec->scanNum, spec->retTime, s, spec->charge, spec->precMass, score, decoy);
        for (int ctr = 0; ctr < i; ctr++) fprintf(res, "\t%d", counts[ctr]);
        fprintf(res, "\n");
    }

 */
    return 0;
}

int main(int argc, char **argv){
/*
    // Create an array to hold y ion masses.
    double frags[strlen(argv[1])]; 
   
    // Populates the array.
    fragMass(argv[1], frags, strlen(argv[1])); 
 
    printf("Mass is %f\n", pepMass(argv[1]));
    for (int i = 1; i < strlen(argv[1]); i++) {
        printf("y%lu is %lf\n", strlen(argv[1]) - i, frags[i]);
    }
*/

    /* Declare variables for parsing config file.  
       as they are not global anymore. Variables are initialised with default values
    */
    /* Actually no need to declare some of them as they are declared in header files
    double precTol = 5;
    double tol = 0.5;
    int q = 5;
    int maxSize = 95;
    char fasta[5][2048]; // up to 5 fasta files can be used
    int maxMod = 0;
    */

    char fasta[5][2048]; // up to 5 fasta files can be used
    maxMod = 0;

    // declare and initialize results1 and results2
    results results1;
    results results2;
    results1.score = 0;
    strcpy(results1.data, "");
    results2.score = 0;
    strcpy(results2.data, "");
    char str3[4096];
    strcpy(str3, "");

    //int N_spectra = atoi(argv[4]);
    int N_spectra = 0;

    // this is to keep track of candidate sequences for the mascot-like scoring
    // has to be private
    int seq_count = 0;

    // Parse config file
    int fasta_cntr = parse_params(argv[3], &precTol, &tol, fasta, &maxMod, &q_start, &q_max, &n_losses);

    // Extract maxMod number
    //int maxMod = atoi(argv[4]);
    
    // Create item pointers and allocate memory.
    /*Item item = malloc(sizeof(*item));  // This might need to go to scorer_mod.c and be passed as argument.
    if (!item) {
        printf("Error allocating memory for item!\n");
        exit(1);
    }

    Item item1 = malloc(sizeof(*item1)); // This might need to go to scorer_mod.c and be passed as argument.
    if (!item1) {
        printf("Error allocating memory for item!\n");
        exit(1);
    }*/

    Item item = NULL;
    Item item1 = NULL;


    /*
    // Array to hold modifications indices. Will realloc when data comes from sqlite3 db.
    mod_ind *mod = malloc(sizeof(*mod));
    if (!mod) {
        printf("Error allocating memory for mod array!\n");
        exit(1);
    }
    */

    mod_ind *mod = NULL; // This works, definition with malloc does not.

    // File pointer to read config info.
    FILE *cnfg;
    if ((cnfg = fopen(argv[3], "r")) == NULL) {
        printf("Error opening config file for reading.\n");
        exit(1);
    }

    // Array to hold modification str.
    char modStr[1024];
    char seq[1024];
    char proteins[4096]; // Had to increase it to 4096 as it was giving error running on mac os.
    //char *token;
    int i = 0;

    // update 05.09.2021: all dynamically allocated arrays that are to be private should be converted to static
    // omp does not know how much memory to reserve for them and treats them as shared
    
    PTM *ptm_tmp = (PTM *)malloc(sizeof(PTM));
    if (!ptm_tmp) {
        printf("Error allocating memory for ptm array!\n");
        exit(1);
    }

    // Read modifications into ptm array from cnfg file.
    while (fgets(modStr, sizeof(modStr), cnfg) != NULL) {

        // Change code to read from new type config file
        if (strstr(modStr, "_varMod")) {
            PTM *tmp = realloc(ptm_tmp, (1 + i)*sizeof(PTM));
            if (!tmp) {
                printf("Error reallocating memory for ptm array!\n");
                free(ptm_tmp);
                exit(1);
            }
            ptm_tmp = tmp;

            sscanf(modStr, "_varMod\t%s\t%lf\t%s", ptm_tmp[i].name, &ptm_tmp[i].delta_mass, ptm_tmp[i].site);
            i++;
        } 
        
      
        /*
        token = strtok(modStr, "\t");
        strcpy(ptm[i].name, token);
        token = strtok(NULL, "\t");
        ptm[i].delta_mass = atof(token);
        token = strtok(NULL, "\t");
        strcpy(ptm[i].site, token);
        //strtok(NULL, "\t");
        */
        //i++;
    }

    
    
    // for debugging
    printf("precTol = %d\n", precTol);
    printf("tol = %lf\n", tol);
    printf("maxMod = %d\n", maxMod);
    printf("FASTA files are:\n");
    for (int j = 0; j < fasta_cntr; j++) printf("%s\n", fasta[j]);
    printf("Variable modifications are:\n");
    for (int j = 0; j < i; j++) printf("%s\t%lf\t%s\n", ptm_tmp[j].name, ptm_tmp[j].delta_mass, ptm_tmp[j].site);
    //return 0;

    // Create counts[i] array to hold number of modifications of each type..
    int counts[i];
    for (int w = 0; w < i; w++) counts[w] = 0;

    // Open sqlite database.
    sqlite3 *db;
    sqlite3_stmt *ppStmt;
    //char *zErrMsg = 0; // Not used.
    int rc;

    //printf("Finished copying to in-memory database\n");

    FILE *mms_ptr;
    double lower;
    double upper;
    //int ct = 0;
    int ct1 = 0;
    printf("Processing %s...\n", argv[1]);
    
    // Open results file for writing.
    char resFile[128] = {};
    strcat(resFile, argv[1]);
    strcat(resFile, ".txt");
    rc = sqlite3_open(argv[2], &db);
    if(rc){
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return(1);
    }
    
    // copy to in memory database
    // now need to copy some data to an in-memory db that will be used in eval_obj()
    sqlite3 *db1;
    sqlite3_backup *pBackup;

    rc = sqlite3_open(":memory:", &db1); // need to write error handling code later
    pBackup = sqlite3_backup_init(db1, "main", db, "main");
    (void)sqlite3_backup_step(pBackup, -1);
    (void)sqlite3_backup_finish(pBackup);
    printf("Finished copying to in-memory database\n");

    // Read data struct by struct, search and write results to file.
    if ((mms_ptr = fopen(argv[1], "rb")) == NULL) {
        printf("Error opening binary file for reading.\n");
        exit(1);
    }
    // update 06.09.2021: will count spectra to determine N_spectra here
    spectrum spec1;
    while (fread(&spec1, sizeof(spectrum), 1, mms_ptr) == 1) {
        N_spectra++;
    }

    if ((res = fopen(resFile, "w")) == NULL) {
        printf("Error opening results file for writing.\n");
        exit(1);
    }

    fprintf(res, "Total\tMatched\tIntensity_matched\tq"); // Need matched and total ion numbers (18.06.2020).
    for (int ctr = 0; ctr < i; ctr++) fprintf(res, "\t%s probs", ptm_tmp[ctr].name); // later should put results in data struct perhaps
    fprintf(res, "\tFragments\tScan\tPrecScan\tRetTime\tSequence\tCharge\tPrecMass\tScore\tProteins");
    for (int ctr = 0; ctr < i; ctr++) fprintf(res, "\t%s", ptm_tmp[ctr].name);
    fprintf(res, "\tnMod\tMissed\tDecoy\tContam\tn_seq\tscore_threshold\n");

    //spectrum spec1;
    char sql_inst[1024]; 
    int specNo;

    // starting omp parallelization
    // update 06.09.2021: will go back to for loop as tasks are hard to get to work
    
    #pragma omp parallel default(none) shared(ptm_tmp, mms_ptr, maxMod, precTol, tol, db1, i, res, N_spectra, ct1) private(specNo, spec1, sql_inst, lower, upper, counts, seq, ppStmt, rc, proteins, str3, item, item1, mod, seq_count) firstprivate(results1, results2)

    { 
    
    // need to malloc ptm, item and item1
    #pragma omp critical
    {
    // Create item pointers and allocate memory.
        item = malloc(sizeof(*item));  // This might need to go to scorer_mod.c and be passed as argument.
        if (!item) {
            printf("Error allocating memory for item!\n");
            exit(1);
        }

        // for debugging
        //printf("Created item in thread %d address is %p\n", omp_get_thread_num(), (void *)item);
 
        item1 = malloc(sizeof(*item1)); // This might need to go to scorer_mod.c and be passed as argument.
        if (!item1) {
            printf("Error allocating memory for item!\n");
            exit(1);
        }

        ptm = (PTM *) malloc(i*sizeof(PTM));
        if (!ptm) {
            printf("Error allocating memory for ptm array!\n");
            exit(1);
        }
        for (int j = 0; j < i; j++) {
            strcpy(ptm[j].name, ptm_tmp[j].name);
            strcpy(ptm[j].site, ptm_tmp[j].site);
            ptm[j].delta_mass = ptm_tmp[j].delta_mass;
        }
        // for debugging
        //printf("Created ptm in thread %d address is %p\n", omp_get_thread_num(), (void *)ptm);
        //printf("Name of ptm[0] is %s\n", ptm[0].name);
        //printf("delta mass of ptm[0] is %lf\n", ptm[0].delta_mass);

        /*mod = (mod_ind *)malloc(sizeof(*mod));
        if (!mod) {
            printf("Error allocating memory for mod array!\n");
            exit(1);
        }*/
        mod = NULL;
        //printf("Created mod array in thread %d address is %p\n", omp_get_thread_num(), (void *)mod);
        
    }


    #pragma omp for reduction(+:ct1)
        for (specNo = 0; specNo < N_spectra; specNo++) {
            #pragma omp critical
            {
                fseek(mms_ptr, sizeof(spectrum) * specNo, SEEK_SET);
                fread(&spec1, sizeof(spectrum), 1, mms_ptr);
            }
            lower = spec1.precMass - (precTol*spec1.precMass)/1000000;
            upper = spec1.precMass + (precTol*spec1.precMass)/1000000;
            sprintf(sql_inst, "select * from mod_pep left join peptides on mod_pep.pep_id=peptides.rowid where mod_pep.mass between %lf and %lf", lower, upper);
            //printf("Searching for %lf...\n", spec1.precMass); 
            rc = sqlite3_prepare_v2(db1, sql_inst, -1, &ppStmt, 0);

            while ((rc = sqlite3_step(ppStmt)) != 101) {
                if (rc == 100) {
                    int rowid = sqlite3_column_int(ppStmt, 0);
                    for (int ctr = 0; ctr < i; ctr++) counts[ctr] = sqlite3_column_int(ppStmt, ctr + 2);
                    for (int ctr = 0; ctr < i; ctr++) ptm[ctr].count = sqlite3_column_int(ppStmt, ctr + 2);
                    strcpy(seq, (char *)sqlite3_column_text(ppStmt, 2 + i));
                    strcpy(proteins, (char *)sqlite3_column_text(ppStmt, 4 + i));
                    int missed = sqlite3_column_int(ppStmt, 5 + i);
                    int decoy = sqlite3_column_int(ppStmt, 6 + i);
                    int contam = sqlite3_column_int(ppStmt, 7 + i);
                    int count_sum = 0;
                    for (int ctr = 0; ctr < i; ctr++) {
                        count_sum += counts[ctr];
                        //printf("%s is %d\n", ptm[ctr].name, ptm[ctr].count);
                    }
                    if (count_sum <= maxMod) { 
                        callback(rowid, counts, i, seq, &spec1, proteins, item, item1, mod, head, z, missed, decoy, contam, count_sum, &results1, &results2, str3);
                    }
		    seq_count++;
                }
                    
                else {
                    printf("Error executing sql statement: %d.\n", rc);
                    exit(1);
                }
                

            }
            //ct++;
            //ct1 += ct;
            ct1++;
            sqlite3_finalize(ppStmt);
           
	    // write results to file
            #pragma omp critical
            {
                fprintf(res, "%s", results1.data);
		if (strcmp(results1.data, "")) {
		    fprintf(res, "%d\t", seq_count);
                    fprintf(res, "%lf\n", -10*log10(0.01/seq_count));
		}
                fprintf(res, "%s", results2.data);
		if (strcmp(results2.data, "")) {
		    fprintf(res, "%d\t", seq_count);
                    fprintf(res, "%lf\n", -10*log10(0.01/seq_count));
		}
            }
            // set results.score to 0 and wipe clean data fiels
            results1.score = 0;
            results2.score = 0;
            strcpy(results1.data, ""); // necessary otherwise scans that do not have hits are replaced by previous scans data
            strcpy(results2.data, "");
	    seq_count = 0;
        }
        #pragma omp critical
        {
            free(ptm);
            free(item);
            free(item1);
            free(mod);
            mpfr_free_cache();
        }

    }

    /*
    #pragma omp for
    {
    while (fread(&spec1, sizeof(spectrum), 1, mms_ptr) == 1) {
        //printf("Number of fragments is %lu.\n", sizeof(spec1.fragMass)/sizeof(double));
        //for (int ctr = 0; ctr < 190; ctr++) printf("%lf\n", spec1.fragMass[ctr]);

        // for debugging
        //for (int i = 0; i < 190; i++) printf("%lf\t%lf\n", spec1.fragMass[i], spec1.fragInt[i]);
    #pragma omp task  
    {
        lower = spec1.precMass - (precTol*spec1.precMass)/1000000;
        upper = spec1.precMass + (precTol*spec1.precMass)/1000000;
        sprintf(sql_inst, "select * from mod_pep left join peptides on mod_pep.pep_id=peptides.rowid where mod_pep.mass between %lf and %lf", lower, upper);
        printf("Searching for %lf...\n", spec1.precMass); // For troubleshooting only 
        // Should use prepare/step instead of exec.
        // rc = sqlite3_exec(db, sql_inst, callback, &spec1, &zErrMsg);

        rc = sqlite3_prepare_v2(db1, sql_inst, -1, &ppStmt, 0);
        
        while ((rc = sqlite3_step(ppStmt)) != 101) {
            if (rc == 100) {

                 Read the sequence and modifications and call scoring function.
                   The columns that we need are:
                   0. Rowid (pept id), col 0;
                   1. Mass, col 1;
                   2. 2 to 2 + i - 1. Mod counts 0 to i - 1 (the number of elements in ptm array);
                   3. 2 + i. Sequence;
                         
                 
                int rowid = sqlite3_column_int(ppStmt, 0);
                //double mass = sqlite3_column_double(ppStmt, 1); // This will be needed later when we use delat mass.
                //int counts[i]; // This should only be created once outside the loop.
                for (int ctr = 0; ctr < i; ctr++) counts[ctr] = sqlite3_column_int(ppStmt, ctr + 2);
              
                // This made me spend a day with valgrind because ptm[].count were not updated.
                // Do I need counts—I can read the info from ptm.
                for (int ctr = 0; ctr < i; ctr++) ptm[ctr].count = sqlite3_column_int(ppStmt, ctr + 2);

                strcpy(seq, (char *)sqlite3_column_text(ppStmt, 2 + i));

                // For debuging only
                //printf("Sequence is %s\n", seq);

                // Need to parse the string to numbers later when summarising results. 
                strcpy(proteins, (char *)sqlite3_column_text(ppStmt, 4 + i));
                int missed = sqlite3_column_int(ppStmt, 5 + i);
                int decoy = sqlite3_column_int(ppStmt, 6 + i);
                int contam = sqlite3_column_int(ppStmt, 7 + i); 
                
                int count_sum = 0;
                for (int ctr = 0; ctr < i; ctr++) {
                    count_sum += counts[ctr];
                    //printf("%s is %d\n", ptm[ctr].name, ptm[ctr].count);
                }
                if (count_sum <= maxMod) { // Need to limit total number of modifications to be considered to avoid hanging the program.
                    callback(rowid, counts, i, seq, &spec1, proteins, item, item1, mod, head, z, missed, decoy, contam, count_sum, &results1, &results2, str3); // deleted ptm for debugging
                }
                //else printf("Peptide is not modified.\n"); // For debugging only 
                //callback(rowid, counts, i, seq, &spec1, proteins, item, item1, mod, head, z); // deleted ptm for debugging 
            }
            else {
                printf("Error executing sql statement: %d.\n", rc);
                exit(1);
            }            
        }


        ct++;
        sqlite3_finalize(ppStmt);

        // for debugging
        //printf("%s\n", results1.data);
        //printf("%s\n", results2.data);

        // write results to file
        #pragma omp critical
        {
            fprintf(res, "%s", results1.data);
            fprintf(res, "%s", results2.data);
        }
        // set results.score to 0 and wipe clean data fiels
        results1.score = 0;
        results2.score = 0; 
        strcpy(results1.data, ""); // necessary otherwise scans that do not have hits are replaced by previous scans data
        strcpy(results2.data, "");
    } // end of task part
    } // end of while loop
    } // end of single

    #pragma omp critical
    {
        free(ptm);
        free(item);
        free(item1);
    }


    } // end of parallel part
    */
    //sqlite3_finalize(ppStmt);



    sqlite3_close(db);
    sqlite3_close(db1);
    fclose(mms_ptr);
    fclose(cnfg);
    fclose(res);
    free(ptm_tmp);  
    //free(item);
    //free(item1);
    //free(mod); 
    //free(z);
    // Test with madeup data.
    //double frmz[] = {499.2,823.2,1272.4,331.16, 234.1, 216.1, 762.37, 1117.5};
    //double frint[] = {2500.0,3250.0, 3250.0, 10275.0, 315.0, 1225.0, 4500.0, 2000.0};
    //double prec = pepMass(argv[1]);
    //int n_fr = sizeof(frmz)/sizeof(frmz[0]);
    //double score = xcorr(argv[1], frmz, frint, prec, n_fr);
    //printf("Score for %s is %lf.\n", argv[1], score);
    printf("Processed %d MS/MS spectra.\n", ct1);
    //mpfr_free_cache(); // To prevent memory leaks

    //printf("maxMod = %d\n", maxMod);
    return 0;
}

