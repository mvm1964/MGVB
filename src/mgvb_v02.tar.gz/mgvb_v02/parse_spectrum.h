#ifndef PARSE_SPECTRUM
#define PARSE_SPECTRUM

// Struct to hold spectrum data.
/*typedef struct Spectrum {
    int scan;
    int scanNum;
    int charge;
    double retTime;
    double precMass;
    double fragMass[maxSize];
    double fragInt[maxSize];
    int actual_size;
} spectrum;*/

int intervalFill(double, double, spectrum*, int*, int, int);
void sort_masses(spectrum*);
void remove_0(spectrum*); 
#endif
