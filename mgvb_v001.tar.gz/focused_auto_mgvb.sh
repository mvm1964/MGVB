# Automates focussed open search
# takes the db file output from select_by_prob
# and the db1_min.db, containing mod_comb table
# and the mms file, all 2 in a clean new directory,
# then executes deep_seq to preparesequences.db 
# then takes mod_comb from db1_min.db and makes
# mod_comb in sequences.db. Then executes mpirun scorer_mpi
# $1 is number of cores to be used
# Will need to improve this but for now it works like this:
# 1. Run scorer_omp and select_by_prob on mms files
# 2. Create a new directory "focused"
# 3. Copy mms files and txt.db files to focused
# 4. Copy config.rms to focused and edit it to point to focused.fasta and 
#    make precTol 500
# 5. Copy db1_min.db to focused
# 6. cd to focused and execute this script
# Update 06.03.2022: will modify it to first do scorer_omp search and then focused


#!/usr/bin/bash
parallel_mgvb_auto.sh
mkdir focused
cp config_focused.rms ./focused/config.rms
cp *.txt.db ./focused/.
cp *.ms2.mms ./focused/.
sqlite3 db1_min.db "attach database \"sequences.db\" as db2; create table proteins as select * from db2.proteins; create index prot_id on proteins(prot_id);"

cp db1_min.db ./focused/.
cp merged_db.db ./focused/.
cd focused

file_arr1=(*.txt.db)
file_arr2=(*.ms2.mms)
for ((i=0; i < ${#file_arr1[@]} && i < ${#file_arr2[@]}; i++))
do
   deep_seq "${file_arr1[i]}" db1_min.db sequences.db proteins_from_fasta.txt peptides.txt
   nSpec=$(get_nspectra "${file_arr2[i]}")
   time mpirun -np $1 scorer_mpi_2024 "${file_arr2[i]}" sequences.db config.rms $nSpec > mpi.log
   rm "${file_arr1[i]}"
   select_by_pep_open "${file_arr2[i]}".txt config.rms
   rm sequences.db
done
