#!/bin/bash

# Digest proteins
digest_universal config.rms peptides.txt

# Import to sqlite3 database
toSQL sequences.db proteins_from_fasta.txt peptides.txt config.rms

# Extract raw files
echo *.raw | parallel -w 'time extractRaw $x'
 
# Parse to binary mms format
echo *.raw.ms2 | parallel -w -n 6 'time parseMS $x'

# Run scorer_omp on each mms file
# first search
echo *.raw.ms2.mms | parallel -w -n 6 'scorerLT_v2_O2 $x sequences.db config.rms 1'

# main search
echo *.raw.ms2.mms | parallel -w -n 6 'scorerLT_v2_O2 $x sequences.db config.rms 2'

# Select by PEP
#echo *.raw.ms2.mms.txt | parallel -w -n 6 'select_by_pep_2024_2 $x config.rms'

# create aggregated
echo *.raw.ms2.mms.txt | parallel -w -n 6 'create_aggregated $x config.rms'

# merge all aggregated tables
merge_aggregated config.rms

# select sig scans
echo *.raw.ms2.mms.txt.db | parallel -w -n 6 'select_sig_psms $x config.rms'

# wrap up
mgvb config.rms
