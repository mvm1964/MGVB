#!/bin/bash

# Digest proteins
digest_universal config.rms peptides.txt

# Import to sqlite3 database
toSQL sequences.db proteins_from_fasta.txt peptides.txt config.rms

# Extract raw files
for file in *.raw
do 
    time extractRaw $file 
done
 
# Parse to binary mms format

for file in *.raw.ms2
do 
    time parseMS $file
done

# Run scorer_omp on each mms file
# first search
for file in *.raw.ms2.mms
do 
    time scorerLT_O2 $file sequences.db config.rms 1 
done
# main search
for file in *.raw.ms2.mms
do
    time scorerLT_O2 $file sequences.db config.rms 2 
done

# Select by PEP

for file in *.raw.ms2.mms.txt
do 
    #select_by_pep_2024_2 $file config.rms
    create_aggregated $file config.rms
done

merge_aggregated config.rms

for file in *.raw.ms2.mms.txt.db
do
    #select_by_pep_2024_2 $file config.rms
    select_sig_psms $file config.rms
done

mgvb config.rms
